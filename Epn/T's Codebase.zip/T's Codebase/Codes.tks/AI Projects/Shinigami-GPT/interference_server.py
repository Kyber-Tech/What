# inference_server.py
import argparse
import logging
import torch
from flask import Flask, request, jsonify
from omegaconf import OmegaConf
from tokenizers import Tokenizer

# It's better to import from the package now
from shinigami_llm.model import LanguageModel

# --- Setup ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)

# --- Globals ---
app = Flask(__name__)
model = None
tokenizer = None
device = 'cuda' if torch.cuda.is_available() else 'cpu'
cfg = None

def load_model_and_tokenizer(ckpt_path):
    """Loads the fine-tuned model and tokenizer into memory."""
    global model, tokenizer, cfg
    log.info("Loading configuration...")
    # Hydra config is now the source of truth for model architecture
    base_cfg = OmegaConf.load("Shinigami-GPT/configs/config.yaml")
    model_cfg = OmegaConf.load(f"Shinigami-GPT/configs/model/{base_cfg.model.name}.yaml") # Adjust if needed
    cfg = OmegaConf.merge(base_cfg, {"model": model_cfg})
    
    log.info(f"Loading model from checkpoint: {ckpt_path}")
    model = LanguageModel(cfg.model)
    state_dict = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(state_dict)
    model = model.to(device).eval()
    log.info("Model loaded successfully.")

    log.info(f"Loading tokenizer from: {cfg.data.tokenizer_path}")
    tokenizer = Tokenizer.from_file(cfg.data.tokenizer_path)
    log.info("Tokenizer loaded successfully.")

@app.route('/generate', methods=['POST'])
@torch.no_grad()
def generate():
    """API endpoint to generate text from a prompt."""
    if not model or not tokenizer:
        return jsonify({"error": "Model not loaded"}), 500

    data = request.get_json()
    prompt = data.get('prompt', '')
    max_new_tokens = data.get('max_new_tokens', 150)
    temperature = data.get('temperature', 0.7)
    top_k = data.get('top_k', 100)

    prompt_ids = tokenizer.encode(prompt).ids
    context = torch.tensor([prompt_ids], dtype=torch.long, device=device)

    generated_tokens = []
    cur_token = context
    for _ in range(max_new_tokens):
        logits, _ = model(cur_token)
        logits = logits[:, -1, :] / temperature
        
        v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
        logits[logits < v[:, [-1]]] = -float('inf')
        
        probs = torch.nn.functional.softmax(logits, dim=-1)
        next_token = torch.multinomial(probs, num_samples=1)
        
        token_id = next_token.item()
        if token_id == tokenizer.token_to_id("[EOS]"):
            break
        
        generated_tokens.append(token_id)
        cur_token = next_token

    completion = tokenizer.decode(generated_tokens)
    return jsonify({"completion": completion})

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Inference server for Shinigami-GPT.")
    parser.add_argument('--ckpt_path', type=str, required=True, help='Path to the fine-tuned model checkpoint (.pt file).')
    parser.add_argument('--port', type=int, default=5001, help='Port to run the server on.')
    args = parser.parse_args()

    load_model_and_tokenizer(args.ckpt_path)
    log.info(f"Starting Flask server on port {args.port}...")
    app.run(host='0.0.0.0', port=args.port)