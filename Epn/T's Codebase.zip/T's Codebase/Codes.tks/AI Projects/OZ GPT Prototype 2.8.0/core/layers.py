import torch
import torch.nn as nn
from core.math import parallel_associative_scan_exact, bjorck_orthogonalization, log_space_discretization

class OZ_ManifoldLinear(nn.Module):
    def __init__(self, in_features: int, out_features: int, iters: int = 3):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(out_features, in_features))
        self.iters = iters
        nn.init.orthogonal_(self.weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        w_hat = bjorck_orthogonalization(self.weight, self.iters)
        return torch.nn.functional.linear(x, w_hat)

class OZ_LatentCompressionAttention(nn.Module):
    """
    Learnable Strided Compression (LSC) Attention for extreme context retrieval.
    """
    def __init__(self, d_model: int, n_head: int, compression_ratio: int = 64):
        super().__init__()
        self.n_head = n_head
        self.head_dim = d_model // n_head
        self.ratio = compression_ratio
        
        self.qkv = nn.Linear(d_model, d_model * 3, bias=False)
        self.o_proj = OZ_ManifoldLinear(d_model, d_model)
        
        self.compressor = nn.Conv1d(
            in_channels=d_model, 
            out_channels=d_model, 
            kernel_size=compression_ratio, 
            stride=compression_ratio,
            groups=8
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=-1)
        q = q.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        
        x_transposed = x.transpose(1, 2)
        mem_tokens = self.compressor(x_transposed).transpose(1, 2)
        
        m_k, m_v = self.qkv(mem_tokens).chunk(3, dim=-1)[1:]
        m_k = m_k.view(B, -1, self.n_head, self.head_dim).transpose(1, 2)
        m_v = m_v.view(B, -1, self.n_head, self.head_dim).transpose(1, 2)

        out = torch.nn.functional.scaled_dot_product_attention(q, m_k, m_v, is_causal=True)
        out = out.transpose(1, 2).contiguous().reshape(B, T, C)
        return self.o_proj(out)

class OZ_HierarchicalSSM(nn.Module):
    """
    Exact Inter-Segment Propagation (EISP) State Space Model.
    """
    def __init__(self, d_model: int, d_state: int, segment_size: int = 2048):
        super().__init__()
        self.d_state = d_state
        self.segment_size = segment_size
        self.A_log = nn.Parameter(torch.log(torch.arange(1, d_state + 1).float()))
        self.dt_proj = nn.Linear(d_model, d_state)
        self.in_proj = nn.Linear(d_model, d_state)
        self.out_proj = OZ_ManifoldLinear(d_state, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        dt = torch.nn.functional.softplus(self.dt_proj(x))
        B_vals = self.in_proj(x)
        
        A_bar, B_bar = log_space_discretization(self.A_log, dt, B_vals)
        
        num_segs = T // self.segment_size
        A_seg = A_bar.view(B, num_segs, self.segment_size, self.d_state)
        B_seg = B_bar.view(B, num_segs, self.segment_size, self.d_state)
        
        A_local_cum, h_local = parallel_associative_scan_exact(
            A_seg.view(-1, self.segment_size, self.d_state), 
            B_seg.view(-1, self.segment_size, self.d_state)
        )
        A_local_cum = A_local_cum.view(B, num_segs, self.segment_size, self.d_state)
        h_local = h_local.view(B, num_segs, self.segment_size, self.d_state)
        
        if num_segs > 1:
            seg_finals_A = A_local_cum[:, :, -1, :]
            seg_finals_B = h_local[:, :, -1, :]
            
            _, global_carry = parallel_associative_scan_exact(seg_finals_A, seg_finals_B)
            
            global_carry_shifted = torch.cat([torch.zeros_like(global_carry[:, :1, :]), global_carry[:, :-1, :]], dim=1)
            carry_broadcast = global_carry_shifted.unsqueeze(2)
            h_final = h_local + (A_local_cum * carry_broadcast)
        else:
            h_final = h_local
            
        return self.out_proj(h_final.view(B, T, self.d_state))