import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint
from core.layers import OZ_HierarchicalSSM, OZ_LatentCompressionAttention, OZ_ManifoldLinear

class OZ_Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.chunk_size = cfg.get('chunk_size', 4096)
        
        self.ln1 = nn.RMSNorm(cfg['d_model'], eps=1e-6)
        self.ssm = OZ_HierarchicalSSM(cfg['d_model'], cfg['d_state'], cfg['segment_size'])
        self.ln2 = nn.RMSNorm(cfg['d_model'], eps=1e-6)
        self.lca = OZ_LatentCompressionAttention(cfg['d_model'], cfg['n_head'], cfg['compression_ratio'])
        self.ln3 = nn.RMSNorm(cfg['d_model'], eps=1e-6)
        
        self.mlp = nn.Sequential(
            OZ_ManifoldLinear(cfg['d_model'], 4 * cfg['d_model']),
            nn.SiLU(),
            OZ_ManifoldLinear(4 * cfg['d_model'], cfg['d_model'])
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        def _compute(h: torch.Tensor) -> torch.Tensor:
            h = h + self.ssm(self.ln1(h))
            h = h + self.lca(self.ln2(h))
            
            ln3_h = self.ln3(h)
            mlp_out = torch.empty_like(ln3_h)
            
            T = ln3_h.size(1)
            for i in range(0, T, self.chunk_size):
                chunk = ln3_h[:, i:i+self.chunk_size, :]
                mlp_out[:, i:i+self.chunk_size, :] = self.mlp(chunk)
                
            h = h + mlp_out
            return h

        return checkpoint(_compute, x, use_reentrant=False)

class OZ_v290(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.embedding = nn.Embedding(cfg['vocab_size'], cfg['d_model'])
        self.blocks = nn.ModuleList([OZ_Block(cfg) for _ in range(cfg['n_layer'])])
        self.ln_f = nn.RMSNorm(cfg['d_model'], eps=1e-6)
        self.head = nn.Linear(cfg['d_model'], cfg['vocab_size'], bias=False)

    def forward(self, idx: torch.Tensor, targets: torch.Tensor = None):
        x = self.embedding(idx)
        for block in self.blocks:
            x = block(x)
        logits = self.head(self.ln_f(x))
        
        loss = None
        if targets is not None:
            loss = torch.nn.functional.cross_entropy(logits.view(-1, self.cfg['vocab_size']), targets.view(-1))
        return logits, loss