import torch
import math
from typing import Tuple

@torch.jit.script
def parallel_associative_scan_exact(A_elements: torch.Tensor, B_elements: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Parallel prefix sum that tracks both cumulative transition (A_star) and integrated state (B_star).
    """
    T = A_elements.size(1)
    num_steps = int(math.log2(T))
    A_star = A_elements.clone()
    B_star = B_elements.clone()
    
    for i in range(num_steps):
        step = 2**i
        A_curr = A_star[:, step:, :]
        B_curr = B_star[:, step:, :]
        A_prev = A_star[:, :-step, :]
        B_prev = B_star[:, :-step, :]
        
        A_star[:, step:, :] = A_curr * A_prev
        B_star[:, step:, :] = torch.addcmul(B_curr, A_curr, B_prev)
        
    return A_star, B_star

def bjorck_orthogonalization(w: torch.Tensor, iters: int = 3) -> torch.Tensor:
    """Enforces Stiefel isometry on projection matrices."""
    w = w / (torch.linalg.matrix_norm(w, ord=2) + 1e-6)
    for _ in range(iters):
        w_wt_w = w @ w.transpose(-2, -1) @ w
        w = 1.5 * w - 0.5 * w_wt_w
    return w

def log_space_discretization(A_log: torch.Tensor, dt: torch.Tensor, B: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """Numerically stable log-space SSM discretization."""
    A = -torch.exp(A_log)
    A_bar = torch.exp(A * dt)
    B_bar = ((A_bar - 1.0) / A) * B
    return A_bar, B_bar