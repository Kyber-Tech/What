#include "Cyrus.h"
#include <iostream>
#include <algorithm>
#include <random>
#include <cstring>
#include <fstream>
#include <sstream>
#include <cmath>

static const int pst_p[64] = {0,0,0,0,0,0,0,0, 5,10,10,-20,-20,10,10,5, 5,-5,-10,0,0,-10,-5,5, 0,0,0,20,20,0,0,0, 5,5,10,25,25,10,5,5, 10,10,20,30,30,20,10,10, 50,50,50,50,50,50,50,50, 0,0,0,0,0,0,0,0};
static const int pst_n[64] = {-50,-40,-30,-30,-30,-30,-40,-50, -40,-20,0,5,5,0,-20,-40, -30,5,10,15,15,10,5,-30, -30,0,15,20,20,15,0,-30, -30,5,15,20,20,15,5,-30, -30,0,10,15,15,10,0,-30, -40,-20,0,0,0,0,-20,-40, -50,-40,-30,-30,-30,-30,-40,-50};
static const int pst_b[64] = {-10,-10,-10,-10,-10,-10,-10,-10, -10,0,0,0,0,0,0,-10, -10,0,5,10,10,5,0,-10, -10,5,5,10,10,5,5,-10, -10,0,10,10,10,10,0,-10, -10,10,10,10,10,10,10,-10, -10,5,0,0,0,0,5,-10, -10,-10,-10,-10,-10,-10,-10,-10};
static const int pst_r[64] = {0,0,0,5,5,0,0,0, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, -5,0,0,0,0,0,0,-5, 5,10,10,10,10,10,10,5, 0,0,0,0,0,0,0,0};
static const int pst_q[64] = {-10,-10,-10,-5,-5,-10,-10,-10, -10,0,0,0,0,0,0,-10, -10,0,5,5,5,5,0,-10, -5,0,5,5,5,5,0,-5, 0,0,5,5,5,5,0,-5, -10,5,5,5,5,5,0,-10, -10,0,5,0,0,0,0,-10, -10,-10,-10,-5,-5,-10,-10,-10};
static const int pst_k[64] = {20,30,10,0,0,10,30,20, 20,20,0,0,0,0,20,20, -10,-20,-20,-20,-20,-20,-20,-10, -20,-30,-30,-40,-40,-30,-30,-20, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30, -30,-40,-40,-50,-50,-40,-40,-30};

uint64_t CyrusEngine::piece_keys[12][64];
uint64_t CyrusEngine::turn_key;
bool CyrusEngine::zobrist_initialized = false;

CyrusEngine::CyrusEngine() {
    load_fen("rnbkqbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBKQBNR w - - 0 1");
    num_threads = std::max(1u, std::thread::hardware_concurrency());
    tt = std::make_shared<SharedTT>();
    if (!zobrist_initialized) { init_zobrist(); zobrist_initialized = true; }
    load_book();
}

void CyrusEngine::init_zobrist() {
    std::mt19937_64 engine(0);
    std::uniform_int_distribution<uint64_t> dist;
    for (int i = 0; i < 12; ++i)
        for (int j = 0; j < 64; ++j)
            piece_keys[i][j] = dist(engine);
    turn_key = dist(engine);
}

uint64_t CyrusEngine::compute_zobrist_hash(const ThreadState& state) const {
    uint64_t h = 0;
    for (int sq = 0; sq < 64; ++sq) {
        char piece = state.board[sq];
        if (piece != '.') h ^= piece_keys[piece_map(piece)][sq];
    }
    if (state.current_turn == 'w') h ^= turn_key;
    return h;
}

int CyrusEngine::piece_map(char p) const {
    switch(p) {
        case 'p': return 0; case 'P': return 1;
        case 'n': return 2; case 'N': return 3;
        case 'b': return 4; case 'B': return 5;
        case 'r': return 6; case 'R': return 7;
        case 'q': return 8; case 'Q': return 9;
        case 'k': return 10; case 'K': return 11;
        default: return -1;
    }
}

void CyrusEngine::load_fen(const std::string& fen) {
    std::memset(board, '.', 64);
    int r = 0, c = 0;
    size_t i = 0;
    for (; i < fen.length() && fen[i] != ' '; ++i) {
        if (fen[i] == '/') { r++; c = 0; }
        else if (isdigit(fen[i])) { c += fen[i] - '0'; }
        else { board[r * 8 + c] = fen[i]; c++; }
    }
    if (i + 1 < fen.length()) current_turn = fen[i + 1];
    game_history.clear();
}

std::string CyrusEngine::get_fen() const {
    std::string fen = "";
    for (int r = 0; r < 8; ++r) {
        int empty = 0;
        for (int c = 0; c < 8; ++c) {
            char p = board[r * 8 + c];
            if (p == '.') empty++;
            else {
                if (empty > 0) { fen += std::to_string(empty); empty = 0; }
                fen += p;
            }
        }
        if (empty > 0) fen += std::to_string(empty);
        if (r < 7) fen += "/";
    }
    fen += " "; fen += current_turn; fen += " - - 0 1";
    return fen;
}

void CyrusEngine::print_board() const {
    std::cout << "\n  a b c d e f g h" << std::endl;
    std::cout << " +-----------------+" << std::endl;
    for (int r = 0; r < 8; ++r) {
        std::cout << 8 - r << "| ";
        for (int c = 0; c < 8; ++c) std::cout << board[r * 8 + c] << " ";
        std::cout << "|" << 8 - r << std::endl;
    }
    std::cout << " +-----------------+" << std::endl;
    std::cout << "  a b c d e f g h\n" << std::endl;
}

void CyrusEngine::stop_search() { time_up = true; }

Move CyrusEngine::find_best_move(int wtime, int btime, int movetime) {
    time_up = false;
    global_nodes = 0;
    
    if (movetime > 0) allocated_time_ms = movetime - 50;
    else allocated_time_ms = (current_turn == 'w' ? wtime : btime) / 30;
    if (allocated_time_ms < 50) allocated_time_ms = 50;

    ThreadState state;
    std::memcpy(state.board, board, 64);
    state.current_turn = current_turn;
    uint64_t hash = compute_zobrist_hash(state);

    if (opening_book.count(hash)) {
        Move best_book_move = {-1, -1};
        double best_score = -1.0;
        for (const auto& entry : opening_book[hash]) {
            if (entry.second.weight > best_score) {
                best_score = entry.second.weight;
                best_book_move = {entry.first >> 6, entry.first & 63};
            }
        }
        if (best_book_move.from != -1) {
            game_history.push_back({hash, best_book_move});
            return best_book_move;
        }
    }

    std::vector<std::thread> threads;
    std::vector<Move> best_moves(num_threads, {-1, -1});
    search_start_time = std::chrono::steady_clock::now();

    for (int i = 0; i < num_threads; ++i) {
        threads.emplace_back(&CyrusEngine::search_worker, this, i, current_turn, 64, std::ref(best_moves[i]));
    }

    while (!time_up) {
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - search_start_time).count() >= allocated_time_ms) {
            time_up = true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }

    for (auto& t : threads) if (t.joinable()) t.join();

    Move best = best_moves[0];
    if (best.from == -1) {
        auto all_legal = get_all_legal_moves(current_turn, true);
        if (!all_legal.empty()) best = all_legal[0];
    }
    
    game_history.push_back({hash, best});
    return best;
}

void CyrusEngine::search_worker(int thread_id, char turn, int max_depth, Move& out_best_move) {
    ThreadState state;
    std::memcpy(state.board, board, 64);
    state.current_turn = current_turn;
    state.current_hash = compute_zobrist_hash(state);
    state.thread_id = thread_id;
    std::memset(state.history_moves, 0, sizeof(state.history_moves));
    for(int i=0; i<128; ++i) { state.killer_moves[i][0] = {-1,-1}; state.killer_moves[i][1] = {-1,-1}; }
    for(int i=0; i<12; ++i) for(int j=0; j<64; ++j) state.counter_moves[i][j] = {-1,-1};

    int depth_offset = thread_id % 3; 
    int alpha = -999999;
    int beta = 999999;
    int prev_score = 0;

    for (int depth = 1 + depth_offset; depth <= max_depth; ++depth) {
        Move current_best = {-1, -1};
        
        // Aspiration Windows
        if (depth >= 3) {
            alpha = std::max(-999999, prev_score - 50);
            beta = std::min(999999, prev_score + 50);
        }

        while (true) {
            std::vector<Move> legal_moves;
            _generate_legal_moves(state, turn, false, legal_moves);

            Move tt_move = {-1, -1};
            size_t tt_idx = state.current_hash % SharedTT::SIZE;
            size_t lock_idx = state.current_hash % SharedTT::NUM_LOCKS;
            {
                std::lock_guard<std::mutex> lock(tt->locks[lock_idx]);
                if (tt->table[tt_idx].key == state.current_hash) tt_move = tt->table[tt_idx].best_move;
            }

            sort_moves(state, legal_moves, tt_move, 0, false, {-1,-1});
            bool first_move = true;
            int best_eval = (turn == 'w') ? -999999 : 999999;

            for (const auto& move : legal_moves) {
                char piece = state.board[move.from];
                char captured = state.board[move.to];
                make_move_internal(state, move);
                
                int eval;
                if (first_move) {
                    eval = minimax(state, depth - 1, alpha, beta, (turn == 'b'), false, 1);
                } else {
                    if (turn == 'w') {
                        eval = minimax(state, depth - 1, alpha, alpha + 1, (turn == 'b'), false, 1);
                        if (eval > alpha && eval < beta) eval = minimax(state, depth - 1, alpha, beta, (turn == 'b'), false, 1);
                    } else {
                        eval = minimax(state, depth - 1, beta - 1, beta, (turn == 'b'), false, 1);
                        if (eval > alpha && eval < beta) eval = minimax(state, depth - 1, alpha, beta, (turn == 'b'), false, 1);
                    }
                }
                
                unmake_move_internal(state, move, piece, captured);
                first_move = false;

                if (time_up) break;

                if (turn == 'w') {
                    if (eval > best_eval) { best_eval = eval; current_best = move; }
                    alpha = std::max(alpha, eval);
                } else {
                    if (eval < best_eval) { best_eval = eval; current_best = move; }
                    beta = std::min(beta, eval);
                }
            }

            if (time_up) break;
            
            // Aspiration Window Check
            if (best_eval <= alpha) { alpha = -999999; continue; }
            if (best_eval >= beta) { beta = 999999; continue; }
            
            prev_score = best_eval;
            break;
        }
        if (time_up) break;
        if (current_best.from != -1) out_best_move = current_best;
    }
}

int CyrusEngine::minimax(ThreadState& state, int depth, int alpha, int beta, bool maximizing_player, bool is_null_move, int ply) {
    if ((++state.local_nodes & 2047) == 0) {
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - search_start_time).count() >= allocated_time_ms) time_up = true;
    }
    if (time_up) return 0;

    uint64_t hash_key = state.current_hash;
    size_t tt_idx = hash_key % SharedTT::SIZE;
    size_t lock_idx = hash_key % SharedTT::NUM_LOCKS;
    
    Move tt_move = {-1, -1};
    {
        std::lock_guard<std::mutex> lock(tt->locks[lock_idx]);
        TT_Entry& entry = tt->table[tt_idx];
        if (entry.key == hash_key) {
            tt_move = entry.best_move;
            if (entry.depth >= depth) {
                if (entry.flag == TT_EXACT) return entry.score;
                if (entry.flag == TT_LOWER) alpha = std::max(alpha, entry.score);
                if (entry.flag == TT_UPPER) beta = std::min(beta, entry.score);
                if (alpha >= beta) return entry.score;
            }
        }
    }

    char turn = maximizing_player ? 'w' : 'b';
    bool in_check = is_square_attacked(state, find_king(state, turn), maximizing_player ? 'b' : 'w');

    if (in_check) depth++;
    if (depth <= 0) return quiescence_search(state, alpha, beta, maximizing_player, ply);

    // Internal Iterative Deepening (IID)
    if (depth >= 4 && tt_move.from == -1) {
        minimax(state, depth - 2, alpha, beta, maximizing_player, is_null_move, ply);
        std::lock_guard<std::mutex> lock(tt->locks[lock_idx]);
        if (tt->table[tt_idx].key == hash_key) tt_move = tt->table[tt_idx].best_move;
    }

    int static_eval = evaluate_board(state);
    if (depth <= 3 && !in_check && !is_null_move) {
        int margin = 120 * depth;
        if (maximizing_player && static_eval - margin >= beta) return static_eval;
        if (!maximizing_player && static_eval + margin <= alpha) return static_eval;
    }

    if (depth >= 3 && !is_null_move && !in_check) {
        state.current_turn = (state.current_turn == 'w') ? 'b' : 'w';
        state.current_hash ^= turn_key;
        int eval = minimax(state, depth - 1 - 2, alpha, beta, !maximizing_player, true, ply + 1);
        state.current_turn = (state.current_turn == 'w') ? 'b' : 'w';
        state.current_hash ^= turn_key;
        if (maximizing_player && eval >= beta) return beta;
        if (!maximizing_player && eval <= alpha) return alpha;
    }

    std::vector<Move> legal_moves;
    _generate_legal_moves(state, turn, false, legal_moves);

    // Mate Distance Evaluation
    if (legal_moves.empty()) return in_check ? (maximizing_player ? -99999 + ply : 99999 - ply) : 0;

    sort_moves(state, legal_moves, tt_move, ply, false, {-1,-1});

    int original_alpha = alpha;
    int original_beta = beta;
    int best_score = maximizing_player ? -999999 : 999999;
    Move best_move = {-1, -1};
    int legal_moves_played = 0;

    for (const auto& move : legal_moves) {
        char piece = state.board[move.from];
        char captured = state.board[move.to];

        if (depth == 1 && !in_check && captured == '.' && move.promotion == ' ') {
            if (maximizing_player && static_eval + 200 < alpha) continue;
            if (!maximizing_player && static_eval - 200 > beta) continue;
        }

        make_move_internal(state, move);
        legal_moves_played++;
        int eval;

        if (legal_moves_played == 1) {
            eval = minimax(state, depth - 1, alpha, beta, !maximizing_player, false, ply + 1);
        } else {
            int R = 0;
            if (depth >= 3 && legal_moves_played > 3 && !in_check && captured == '.' && move.promotion == ' ') {
                R = (legal_moves_played > 6) ? 2 : 1;
            }
            if (maximizing_player) {
                eval = minimax(state, depth - 1 - R, alpha, alpha + 1, !maximizing_player, false, ply + 1);
                if (eval > alpha && R > 0) eval = minimax(state, depth - 1, alpha, alpha + 1, !maximizing_player, false, ply + 1);
                if (eval > alpha && eval < beta) eval = minimax(state, depth - 1, alpha, beta, !maximizing_player, false, ply + 1);
            } else {
                eval = minimax(state, depth - 1 - R, beta - 1, beta, !maximizing_player, false, ply + 1);
                if (eval < beta && R > 0) eval = minimax(state, depth - 1, beta - 1, beta, !maximizing_player, false, ply + 1);
                if (eval > alpha && eval < beta) eval = minimax(state, depth - 1, alpha, beta, !maximizing_player, false, ply + 1);
            }
        }
        
        unmake_move_internal(state, move, piece, captured);
        if (time_up) return 0;

        if (maximizing_player) {
            if (eval > best_score) { best_score = eval; best_move = move; }
            alpha = std::max(alpha, eval);
            if (beta <= alpha) {
                if (captured == '.') {
                    state.killer_moves[ply][1] = state.killer_moves[ply][0];
                    state.killer_moves[ply][0] = move;
                    state.history_moves[0][move.from][move.to] += depth * depth;
                    if (ply > 0) state.counter_moves[piece_map(piece)][move.to] = move;
                }
                break;
            }
        } else {
            if (eval < best_score) { best_score = eval; best_move = move; }
            beta = std::min(beta, eval);
            if (beta <= alpha) {
                if (captured == '.') {
                    state.killer_moves[ply][1] = state.killer_moves[ply][0];
                    state.killer_moves[ply][0] = move;
                    state.history_moves[1][move.from][move.to] += depth * depth;
                    if (ply > 0) state.counter_moves[piece_map(piece)][move.to] = move;
                }
                break;
            }
        }
    }

    {
        std::lock_guard<std::mutex> lock(tt->locks[lock_idx]);
        TT_Entry& entry = tt->table[tt_idx];
        entry.key = hash_key;
        entry.depth = depth;
        entry.score = best_score;
        entry.best_move = best_move;
        if (best_score <= original_alpha) entry.flag = TT_UPPER;
        else if (best_score >= original_beta) entry.flag = TT_LOWER;
        else entry.flag = TT_EXACT;
    }

    return best_score;
}

int CyrusEngine::quiescence_search(ThreadState& state, int alpha, int beta, bool maximizing_player, int ply) {
    if ((++state.local_nodes & 2047) == 0) {
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - search_start_time).count() >= allocated_time_ms) time_up = true;
    }
    if (time_up) return 0;

    int stand_pat = evaluate_board(state);

    if (maximizing_player) {
        if (stand_pat >= beta) return beta;
        alpha = std::max(alpha, stand_pat);
    } else {
        if (stand_pat <= alpha) return alpha;
        beta = std::min(beta, stand_pat);
    }

    char turn = maximizing_player ? 'w' : 'b';
    std::vector<Move> captures;
    _generate_legal_moves(state, turn, true, captures);
    sort_moves(state, captures, {-1, -1}, ply, true, {-1,-1});

    for (const auto& move : captures) {
        char piece = state.board[move.from];
        char captured = state.board[move.to];

        // Delta Pruning
        int safety_margin = 200;
        if (maximizing_player && stand_pat + get_piece_value(captured) + safety_margin < alpha) continue;
        if (!maximizing_player && stand_pat - get_piece_value(captured) - safety_margin > beta) continue;

        // SEE Pruning
        if (see(state, move) < 0) continue;

        make_move_internal(state, move);
        int score = quiescence_search(state, alpha, beta, !maximizing_player, ply + 1);
        unmake_move_internal(state, move, piece, captured);

        if (time_up) return 0;

        if (maximizing_player) {
            if (score >= beta) return beta;
            alpha = std::max(alpha, score);
        } else {
            if (score <= alpha) return alpha;
            beta = std::min(beta, score);
        }
    }
    return maximizing_player ? alpha : beta;
}

int CyrusEngine::see(const ThreadState& state, const Move& move) const {
    int gain = get_piece_value(state.board[move.to]);
    int risk = get_piece_value(state.board[move.from]);
    if (risk <= gain) return gain;
    if (is_square_attacked(state, move.to, get_piece_color(state.board[move.to]))) return gain - risk;
    return gain;
}

int CyrusEngine::evaluate_board(const ThreadState& state) const {
    int score = 0;
    int w_pawns_file[8] = {0}, b_pawns_file[8] = {0};
    int w_fil_count = 0, b_fil_count = 0;
    int w_king_sq = find_king(state, 'w');
    int b_king_sq = find_king(state, 'b');

    for (int sq = 0; sq < 64; ++sq) {
        char p = state.board[sq];
        if (p == 'P') w_pawns_file[sq % 8]++;
        else if (p == 'p') b_pawns_file[sq % 8]++;
        else if (p == 'B') w_fil_count++;
        else if (p == 'b') b_fil_count++;
    }

    for (int sq = 0; sq < 64; ++sq) {
        char piece = state.board[sq];
        if (piece == '.') continue;

        int r = sq / 8, c = sq % 8;
        char color = get_piece_color(piece);
        int val = get_piece_value(piece) + get_pst_value(piece, sq);
        int piece_score = val;

        if (tolower(piece) == 'p') {
            bool passed = true;
            int dir = (color == 'w') ? -1 : 1;
            for (int rr = r + dir; rr >= 0 && rr < 8; rr += dir) {
                if (color == 'w' && (b_pawns_file[c] > 0)) {
                    if (state.board[rr*8+c] == 'p' || (c>0 && state.board[rr*8+c-1] == 'p') || (c<7 && state.board[rr*8+c+1] == 'p')) passed = false;
                } else if (color == 'b' && (w_pawns_file[c] > 0)) {
                    if (state.board[rr*8+c] == 'P' || (c>0 && state.board[rr*8+c-1] == 'P') || (c<7 && state.board[rr*8+c+1] == 'P')) passed = false;
                }
            }
            if (passed) piece_score += 40;

            bool isolated = true;
            if (color == 'w') {
                if ((c > 0 && w_pawns_file[c - 1] > 0) || (c < 7 && w_pawns_file[c + 1] > 0)) isolated = false;
            } else {
                if ((c > 0 && b_pawns_file[c - 1] > 0) || (c < 7 && b_pawns_file[c + 1] > 0)) isolated = false;
            }
            if (isolated) piece_score -= 10;
            if ((color == 'w' && w_pawns_file[c] > 1) || (color == 'b' && b_pawns_file[c] > 1)) piece_score -= 10;
        }
        else if (tolower(piece) == 'r') {
            if (w_pawns_file[c] == 0 && b_pawns_file[c] == 0) piece_score += 20; 
            else if ((color == 'w' && w_pawns_file[c] == 0) || (color == 'b' && b_pawns_file[c] == 0)) piece_score += 10; 
        }
        else if (tolower(piece) == 'n' || tolower(piece) == 'b') {
            int back_r = r + ((color == 'w') ? 1 : -1);
            if (back_r >= 0 && back_r < 8) {
                if ((c > 0 && state.board[back_r*8 + c - 1] == (color == 'w' ? 'P' : 'p')) || 
                    (c < 7 && state.board[back_r*8 + c + 1] == (color == 'w' ? 'P' : 'p'))) {
                    piece_score += 15; 
                }
            }
        }
        else if (tolower(piece) == 'q') {
            int k_sq = (color == 'w') ? w_king_sq : b_king_sq;
            if (k_sq != -1) {
                int dist = std::max(std::abs(r - (k_sq/8)), std::abs(c - (k_sq%8)));
                if (dist <= 2) piece_score += 10;
            }
        }

        score += (color == 'w') ? piece_score : -piece_score;
    }

    if (w_fil_count >= 2) score += 15;
    if (b_fil_count >= 2) score -= 15;

    if (w_king_sq != -1) {
        int r = w_king_sq/8, c = w_king_sq%8;
        if (r > 0) {
            if (c > 0 && state.board[(r-1)*8 + c-1] == 'P') score += 10;
            if (state.board[(r-1)*8 + c] == 'P') score += 10;
            if (c < 7 && state.board[(r-1)*8 + c+1] == 'P') score += 10;
        }
    }
    if (b_king_sq != -1) {
        int r = b_king_sq/8, c = b_king_sq%8;
        if (r < 7) {
            if (c > 0 && state.board[(r+1)*8 + c-1] == 'p') score -= 10;
            if (state.board[(r+1)*8 + c] == 'p') score -= 10;
            if (c < 7 && state.board[(r+1)*8 + c+1] == 'p') score -= 10;
        }
    }

    return score;
}

void CyrusEngine::make_move(const Move& move) {
    ThreadState dummy;
    std::memcpy(dummy.board, board, 64);
    dummy.current_turn = current_turn;
    dummy.current_hash = compute_zobrist_hash(dummy);
    make_move_internal(dummy, move);
    std::memcpy(board, dummy.board, 64);
    current_turn = dummy.current_turn;
}

void CyrusEngine::make_move_internal(ThreadState& state, const Move& move) {
    char piece = state.board[move.from];
    char target = state.board[move.to];

    state.current_hash ^= piece_keys[piece_map(piece)][move.from];
    if (target != '.') state.current_hash ^= piece_keys[piece_map(target)][move.to];
    
    state.board[move.from] = '.';
    if (tolower(piece) == 'p' && (move.to / 8 == 0 || move.to / 8 == 7)) {
        char promo_piece = (state.current_turn == 'w') ? 'Q' : 'q';
        state.board[move.to] = promo_piece;
        state.current_hash ^= piece_keys[piece_map(promo_piece)][move.to];
    } else {
        state.board[move.to] = piece;
        state.current_hash ^= piece_keys[piece_map(piece)][move.to];
    }
    
    state.current_hash ^= turn_key;
    state.current_turn = (state.current_turn == 'w') ? 'b' : 'w';
}

void CyrusEngine::unmake_move_internal(ThreadState& state, const Move& move, char piece, char captured_piece) {
    state.current_turn = (state.current_turn == 'w') ? 'b' : 'w';
    state.current_hash ^= turn_key;
    
    char moved_piece = state.board[move.to]; 
    state.board[move.from] = piece; 
    state.board[move.to] = captured_piece;
    
    state.current_hash ^= piece_keys[piece_map(piece)][move.from];
    state.current_hash ^= piece_keys[piece_map(moved_piece)][move.to];
    if (captured_piece != '.') state.current_hash ^= piece_keys[piece_map(captured_piece)][move.to];
}

int CyrusEngine::get_piece_value(char p) const {
    switch(tolower(p)) {
        case 'p': return 100;
        case 'n': return 320;
        case 'b': return 120; 
        case 'r': return 500;
        case 'q': return 110; 
        case 'k': return 20000;
        default: return 0;
    }
}

int CyrusEngine::get_pst_value(char piece, int sq) const {
    char p_type = tolower(piece);
    int idx = (get_piece_color(piece) == 'w') ? sq : sq ^ 56; 
    switch(p_type) {
        case 'p': return pst_p[idx];
        case 'n': return pst_n[idx];
        case 'b': return pst_b[idx];
        case 'r': return pst_r[idx];
        case 'q': return pst_q[idx];
        case 'k': return pst_k[idx];
        default: return 0;
    }
}

std::vector<Move> CyrusEngine::get_all_legal_moves(char turn, bool sort) {
    ThreadState state;
    std::memcpy(state.board, board, 64);
    state.current_turn = turn;
    
    std::vector<Move> legal_moves;
    _generate_legal_moves(state, turn, false, legal_moves);
    if (sort) sort_moves(state, legal_moves, {-1, -1}, 0, false, {-1,-1});
    return legal_moves;
}

int CyrusEngine::_score_move(const ThreadState& state, const Move& move, int ply, bool is_qs, Move prev_move) const {
    char target = state.board[move.to];
    if (target != '.') {
        char attacker = state.board[move.from];
        return 1000000 + 10 * get_piece_value(target) - get_piece_value(attacker); 
    }
    if (!is_qs) {
        if (state.killer_moves[ply][0] == move) return 900000;
        if (state.killer_moves[ply][1] == move) return 800000;
        if (prev_move.from != -1 && state.counter_moves[piece_map(state.board[prev_move.from])][prev_move.to] == move) return 700000;
        int color_idx = (state.current_turn == 'w') ? 0 : 1;
        return state.history_moves[color_idx][move.from][move.to];
    }
    return 0;
}

void CyrusEngine::sort_moves(const ThreadState& state, std::vector<Move>& moves, const Move& tt_move, int ply, bool is_qs, Move prev_move) const {
    std::vector<int> scores(moves.size());
    for (size_t i = 0; i < moves.size(); ++i) {
        if (moves[i] == tt_move) scores[i] = 2000000;
        else scores[i] = _score_move(state, moves[i], ply, is_qs, prev_move);
    }
    for (size_t i = 1; i < moves.size(); ++i) {
        Move m = moves[i];
        int s = scores[i];
        int j = static_cast<int>(i) - 1;
        while (j >= 0 && scores[j] < s) {
            scores[j + 1] = scores[j];
            moves[j + 1] = moves[j];
            j--;
        }
        moves[j + 1] = m;
        scores[j + 1] = s;
    }
}

// Strict Legal Move Generation
void CyrusEngine::_generate_legal_moves(ThreadState& state, char color, bool captures_only, std::vector<Move>& moves) {
    std::vector<Move> pseudo;
    _generate_pseudo_legal_moves(state, color, captures_only, pseudo);
    for (const auto& m : pseudo) {
        char p = state.board[m.from];
        char cap = state.board[m.to];
        make_move_internal(state, m);
        if (!is_square_attacked(state, find_king(state, color), (color == 'w') ? 'b' : 'w')) {
            moves.push_back(m);
        }
        unmake_move_internal(state, m, p, cap);
    }
}

void CyrusEngine::_generate_pseudo_legal_moves(const ThreadState& state, char color, bool captures_only, std::vector<Move>& moves) const {
    for (int sq = 0; sq < 64; ++sq) {
        if (state.board[sq] != '.' && get_piece_color(state.board[sq]) == color) {
            _get_moves_for_piece(state, sq, moves);
        }
    }
    if (captures_only) {
        auto it = std::remove_if(moves.begin(), moves.end(), [&state](const Move& m) {
            return state.board[m.to] == '.';
        });
        moves.erase(it, moves.end());
    }
}

void CyrusEngine::_get_moves_for_piece(const ThreadState& state, int sq, std::vector<Move>& moves) const {
    char piece = tolower(state.board[sq]);
    char color = get_piece_color(state.board[sq]);
    switch (piece) {
        case 'p': _get_pawn_moves(state, sq, color, moves); break;
        case 'n': _get_faras_moves(state, sq, color, moves); break;
        case 'b': _get_fil_moves(state, sq, color, moves); break;
        case 'r': {
            static const int rook_deltas[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};
            _get_sliding_moves(state, sq, color, rook_deltas, 4, moves); 
            break;
        }
        case 'q': _get_ferz_moves(state, sq, color, moves); break;
        case 'k': _get_shah_moves(state, sq, color, moves); break;
    }
}

void CyrusEngine::_get_pawn_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const {
    int r = sq / 8, c = sq % 8;
    int dir = (color == 'w') ? -1 : 1;
    if (r + dir >= 0 && r + dir < 8) {
        if (state.board[(r + dir) * 8 + c] == '.') moves.push_back({sq, (r + dir) * 8 + c});
        int dcs[2] = {-1, 1};
        for (int dc : dcs) {
            if (c + dc >= 0 && c + dc < 8) {
                int nsq = (r + dir) * 8 + (c + dc);
                if (state.board[nsq] != '.' && get_piece_color(state.board[nsq]) != color) moves.push_back({sq, nsq});
            }
        }
    }
}

void CyrusEngine::_get_faras_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const {
    int r = sq / 8, c = sq % 8;
    static const int deltas[8][2] = {{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
    for (int i = 0; i < 8; ++i) {
        int nr = r + deltas[i][0], nc = c + deltas[i][1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int nsq = nr * 8 + nc;
            if (get_piece_color(state.board[nsq]) != color) moves.push_back({sq, nsq});
        }
    }
}

void CyrusEngine::_get_fil_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const { 
    int r = sq / 8, c = sq % 8;
    static const int deltas[4][2] = {{2,2},{2,-2},{-2,2},{-2,-2}};
    for (int i = 0; i < 4; ++i) {
        int nr = r + deltas[i][0], nc = c + deltas[i][1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int nsq = nr * 8 + nc;
            if (get_piece_color(state.board[nsq]) != color) moves.push_back({sq, nsq});
        }
    }
}

void CyrusEngine::_get_ferz_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const { 
    int r = sq / 8, c = sq % 8;
    static const int deltas[4][2] = {{1,1},{1,-1},{-1,1},{-1,-1}};
    for (int i = 0; i < 4; ++i) {
        int nr = r + deltas[i][0], nc = c + deltas[i][1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int nsq = nr * 8 + nc;
            if (get_piece_color(state.board[nsq]) != color) moves.push_back({sq, nsq});
        }
    }
}

void CyrusEngine::_get_shah_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const { 
    int r = sq / 8, c = sq % 8;
    static const int deltas[8][2] = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
    for (int i = 0; i < 8; ++i) {
        int nr = r + deltas[i][0], nc = c + deltas[i][1];
        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int nsq = nr * 8 + nc;
            if (get_piece_color(state.board[nsq]) != color) moves.push_back({sq, nsq});
        }
    }
}

void CyrusEngine::_get_sliding_moves(const ThreadState& state, int sq, char color, const int deltas[][2], int num_deltas, std::vector<Move>& moves) const {
    int r = sq / 8, c = sq % 8;
    for (int i = 0; i < num_deltas; ++i) {
        int nr = r + deltas[i][0], nc = c + deltas[i][1];
        while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
            int nsq = nr * 8 + nc;
            if (state.board[nsq] == '.') {
                moves.push_back({sq, nsq});
            } else {
                if (get_piece_color(state.board[nsq]) != color) moves.push_back({sq, nsq});
                break;
            }
            nr += deltas[i][0]; nc += deltas[i][1];
        }
    }
}

bool CyrusEngine::is_square_attacked(const ThreadState& state, int sq, char attacker_color) const {
    if (sq == -1) return true;
    int r = sq / 8, c = sq % 8;
    
    int p_look_r = r + ((attacker_color == 'w') ? 1 : -1);
    if (p_look_r >= 0 && p_look_r < 8) {
        if (c > 0 && state.board[p_look_r * 8 + (c - 1)] == (attacker_color == 'w' ? 'P' : 'p')) return true;
        if (c < 7 && state.board[p_look_r * 8 + (c + 1)] == (attacker_color == 'w' ? 'P' : 'p')) return true;
    }
    
    static const int n_deltas[8][2] = {{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
    for (int i=0; i<8; ++i) {
        int nr = r + n_deltas[i][0], nc = c + n_deltas[i][1];
        if (nr>=0 && nr<8 && nc>=0 && nc<8 && state.board[nr*8+nc] == (attacker_color == 'w' ? 'N' : 'n')) return true;
    }
    
    static const int b_deltas[4][2] = {{2,2},{2,-2},{-2,2},{-2,-2}};
    for (int i=0; i<4; ++i) {
        int nr = r + b_deltas[i][0], nc = c + b_deltas[i][1];
        if (nr>=0 && nr<8 && nc>=0 && nc<8 && state.board[nr*8+nc] == (attacker_color == 'w' ? 'B' : 'b')) return true;
    }
    
    static const int q_deltas[4][2] = {{1,1},{1,-1},{-1,1},{-1,-1}};
    for (int i=0; i<4; ++i) {
        int nr = r + q_deltas[i][0], nc = c + q_deltas[i][1];
        if (nr>=0 && nr<8 && nc>=0 && nc<8 && state.board[nr*8+nc] == (attacker_color == 'w' ? 'Q' : 'q')) return true;
    }
    
    static const int k_deltas[8][2] = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
    for (int i=0; i<8; ++i) {
        int nr = r + k_deltas[i][0], nc = c + k_deltas[i][1];
        if (nr>=0 && nr<8 && nc>=0 && nc<8 && state.board[nr*8+nc] == (attacker_color == 'w' ? 'K' : 'k')) return true;
    }
    
    static const int r_deltas[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};
    for (int i=0; i<4; ++i) {
        int nr = r + r_deltas[i][0], nc = c + r_deltas[i][1];
        while (nr>=0 && nr<8 && nc>=0 && nc<8) {
            char p = state.board[nr*8+nc];
            if (p != '.') {
                if (p == (attacker_color == 'w' ? 'R' : 'r')) return true;
                break;
            }
            nr += r_deltas[i][0]; nc += r_deltas[i][1];
        }
    }
    return false;
}

char CyrusEngine::get_piece_color(char p) const {
    if (p == '.') return ' ';
    return isupper(p) ? 'w' : 'b';
}

bool CyrusEngine::is_in_check(char color) const {
    ThreadState state;
    std::memcpy(state.board, board, 64);
    return is_square_attacked(state, find_king(state, color), (color == 'w') ? 'b' : 'w');
}

int CyrusEngine::find_king(const ThreadState& state, char color) const {
    char king_char = (color == 'w') ? 'K' : 'k';
    for (int sq = 0; sq < 64; ++sq) {
        if (state.board[sq] == king_char) return sq;
    }
    return -1;
}

bool CyrusEngine::is_game_over(char turn) {
    return get_all_legal_moves(turn, false).empty();
}

std::string CyrusEngine::get_game_over_message(char turn) {
    std::string winner = (turn == 'w') ? "Black" : "White";
    if (is_in_check(turn)) return "Checkmate! " + winner + " wins.";
    else return "Stalemate! " + winner + " wins.";
}

void CyrusEngine::record_game_result(double result) {
    for (const auto& history : game_history) {
        int move_key = (history.second.from << 6) | history.second.to;
        BookEntry& entry = opening_book[history.first][move_key];
        
        if (result == 1.0) entry.wins++;
        else if (result == 0.0) entry.losses++;
        else entry.draws++;

        double total = entry.wins + entry.losses + entry.draws;
        entry.weight = ((entry.wins * 2.0) + entry.draws) / (total * 2.0) * 100.0;
        
        if (entry.losses > entry.wins + 2) entry.weight *= 0.5; 
    }
    save_book();
}

void CyrusEngine::save_book() {
    std::ofstream out("cyrus_book.dat");
    for (const auto& pos : opening_book) {
        for (const auto& move : pos.second) {
            out << pos.first << " " << move.first << " " << move.second.wins << " " 
                << move.second.losses << " " << move.second.draws << " " << move.second.weight << "\n";
        }
    }
}

void CyrusEngine::load_book() {
    std::ifstream in("cyrus_book.dat");
    if(!in.is_open()) return;
    uint64_t hash; int move_key, w, l, d; double weight;
    while (in >> hash >> move_key >> w >> l >> d >> weight) {
        opening_book[hash][move_key] = {w, l, d, weight};
    }
}

Move CyrusEngine::parse_move(const std::string& move_str) {
    if (move_str.length() < 4) return {-1, -1};
    int sc = move_str[0] - 'a', sr = 8 - (move_str[1] - '0');
    int ec = move_str[2] - 'a', er = 8 - (move_str[3] - '0');
    if (sr < 0 || sr > 7 || sc < 0 || sc > 7 || er < 0 || er > 7 || ec < 0 || ec > 7) return {-1, -1};
    return {sr * 8 + sc, er * 8 + ec};
}

std::string CyrusEngine::format_move(const Move& move) const {
    if (move.from == -1) return "0000";
    std::string str;
    str += (char)('a' + (move.from % 8)); str += std::to_string(8 - (move.from / 8));
    str += (char)('a' + (move.to % 8)); str += std::to_string(8 - (move.to / 8));
    return str;
}