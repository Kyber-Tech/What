from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess
import os

app = Flask(__name__)
CORS(app)

print("Compiling Cyrus Engine V4.0.0...")
os.system("g++ -O3 -pthread Cyrus.cpp main.cpp -o cyrus_engine")

engine = subprocess.Popen(['./cyrus_engine'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)

def send_command(cmd):
    engine.stdin.write(cmd + "\n")
    engine.stdin.flush()

@app.route('/newgame', methods=['POST'])
def newgame():
    send_command("usinewgame")
    return jsonify({"status": "ok"})

@app.route('/move', methods=['POST'])
def make_move():
    data = request.json
    moves = data.get('moves', '')
    
    send_command(f"position startpos moves {moves}")
    send_command("go movetime 1000") 
    
    while True:
        line = engine.stdout.readline().strip()
        if line.startswith("bestmove"):
            bestmove = line.split()[1]
            return jsonify({"bestmove": bestmove})

if __name__ == '__main__':
    send_command("usi")
    send_command("isready")
    print("Cyrus Bridge is running on http://localhost:5000")
    app.run(port=5000)