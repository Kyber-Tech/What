g++ -O3 -std=c++17 main.cpp Cyrus.cpp -o Cyrus
./Cyrus