#ifndef CYRUS_H
#define CYRUS_H

#include <vector>
#include <string>
#include <cstdint>
#include <chrono>
#include <thread>
#include <atomic>
#include <mutex>
#include <memory>
#include <unordered_map>

struct Move {
    int from;
    int to;
    char promotion = ' ';
    bool operator==(const Move& other) const { return from == other.from && to == other.to; }
};

enum TT_Flag { TT_EXACT, TT_LOWER, TT_UPPER };

struct TT_Entry {
    uint64_t key;
    int depth;
    int score;
    TT_Flag flag;
    Move best_move;
};

struct SharedTT {
    static const size_t SIZE = 1048576; 
    static const size_t NUM_LOCKS = 4096;
    std::vector<TT_Entry> table;
    std::unique_ptr<std::mutex[]> locks;
    SharedTT() {
        table.resize(SIZE, {0, 0, 0, TT_EXACT, {-1, -1}});
        locks = std::make_unique<std::mutex[]>(NUM_LOCKS);
    }
};

struct BookEntry {
    int wins = 0;
    int losses = 0;
    int draws = 0;
    double weight = 100.0;
};

class CyrusEngine {
public:
    CyrusEngine();
    
    // USI & State Management
    void load_fen(const std::string& fen);
    std::string get_fen() const;
    void print_board() const;
    void make_move(const Move& move);
    Move parse_move(const std::string& move_str);
    std::string format_move(const Move& move) const;
    
    // Search
    Move find_best_move(int wtime, int btime, int movetime = 0);
    void stop_search();

    // Game State
    std::vector<Move> get_all_legal_moves(char turn, bool sort = false);
    bool is_in_check(char color) const;
    bool is_game_over(char turn);
    std::string get_game_over_message(char turn);

    // Adaptive Learning
    void record_game_result(double result); 
    void save_book();
    void load_book();

    char board[64];
    char current_turn = 'w';
    int num_threads;
    std::atomic<bool> time_up;

private:
    std::shared_ptr<SharedTT> tt;
    std::atomic<long long> global_nodes;
    std::chrono::steady_clock::time_point search_start_time;
    int allocated_time_ms;

    std::unordered_map<uint64_t, std::unordered_map<int, BookEntry>> opening_book;
    std::vector<std::pair<uint64_t, Move>> game_history;

    struct ThreadState {
        char board[64];
        char current_turn;
        uint64_t current_hash;
        Move killer_moves[128][2];
        int history_moves[2][64][64];
        Move counter_moves[12][64]; // Counter Move Heuristic
        long long local_nodes = 0;
        int thread_id = 0;
    };

    void search_worker(int thread_id, char turn, int max_depth, Move& out_best_move);
    int minimax(ThreadState& state, int depth, int alpha, int beta, bool maximizing_player, bool is_null_move, int ply);
    int quiescence_search(ThreadState& state, int alpha, int beta, bool maximizing_player, int ply);
    int evaluate_board(const ThreadState& state) const;
    int see(const ThreadState& state, const Move& move) const; // Static Exchange Evaluation

    void make_move_internal(ThreadState& state, const Move& move);
    void unmake_move_internal(ThreadState& state, const Move& move, char piece, char captured_piece);

    // Strict Legal Move Generation
    void _generate_legal_moves(ThreadState& state, char color, bool captures_only, std::vector<Move>& moves);
    void _generate_pseudo_legal_moves(const ThreadState& state, char color, bool captures_only, std::vector<Move>& moves) const;
    void _get_moves_for_piece(const ThreadState& state, int sq, std::vector<Move>& moves) const;
    void _get_pawn_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const;
    void _get_faras_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const; 
    void _get_fil_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const;   
    void _get_ferz_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const;  
    void _get_shah_moves(const ThreadState& state, int sq, char color, std::vector<Move>& moves) const;  
    void _get_sliding_moves(const ThreadState& state, int sq, char color, const int deltas[][2], int num_deltas, std::vector<Move>& moves) const;

    char get_piece_color(char p) const;
    int find_king(const ThreadState& state, char color) const;
    bool is_square_attacked(const ThreadState& state, int sq, char attacker_color) const;
    int _score_move(const ThreadState& state, const Move& move, int ply, bool is_qs, Move prev_move) const;
    void sort_moves(const ThreadState& state, std::vector<Move>& moves, const Move& tt_move, int ply, bool is_qs, Move prev_move) const;

    static void init_zobrist();
    uint64_t compute_zobrist_hash(const ThreadState& state) const;
    static uint64_t piece_keys[12][64];
    static uint64_t turn_key;
    static bool zobrist_initialized;
    int piece_map(char p) const;

    int get_piece_value(char p) const;
    int get_pst_value(char piece, int sq) const;
};

#endif // CYRUS_H