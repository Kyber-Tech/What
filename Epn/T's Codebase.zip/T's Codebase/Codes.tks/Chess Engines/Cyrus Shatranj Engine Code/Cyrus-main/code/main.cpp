#include <iostream>
#include <string>
#include <sstream>
#include <thread>
#include "Cyrus.h"

int main() {
    CyrusEngine engine;
    std::string line;
    std::thread search_thread;

    while (std::getline(std::cin, line)) {
        std::istringstream iss(line);
        std::string command;
        iss >> command;

        if (command == "usi") {
            std::cout << "id name Cyrus Shatranj V4.0\n";
            std::cout << "id author Cyrus AI\n";
            std::cout << "usiok\n";
        } 
        else if (command == "isready") {
            std::cout << "readyok\n";
        } 
        else if (command == "ucinewgame" || command == "usinewgame") {
            engine.load_fen("rnbkqbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBKQBNR w - - 0 1");
        } 
        else if (command == "position") {
            std::string type;
            iss >> type;
            if (type == "startpos") {
                engine.load_fen("rnbkqbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBKQBNR w - - 0 1");
                std::string moves_keyword;
                iss >> moves_keyword;
                if (moves_keyword == "moves") {
                    std::string move_str;
                    while (iss >> move_str) engine.make_move(engine.parse_move(move_str));
                }
            } else if (type == "fen") {
                std::string fen = "", token;
                for (int i=0; i<6; i++) { 
                    if(iss >> token) fen += token + " "; 
                }
                engine.load_fen(fen);
                std::string moves_keyword;
                iss >> moves_keyword;
                if (moves_keyword == "moves") {
                    std::string move_str;
                    while (iss >> move_str) engine.make_move(engine.parse_move(move_str));
                }
            }
        } 
        else if (command == "go") {
            int wtime = 10000, btime = 10000, movetime = 0;
            std::string token;
            while (iss >> token) {
                if (token == "wtime") iss >> wtime;
                else if (token == "btime") iss >> btime;
                else if (token == "movetime") iss >> movetime;
            }
            
            if (search_thread.joinable()) search_thread.join();
            search_thread = std::thread([&engine, wtime, btime, movetime]() {
                Move best = engine.find_best_move(wtime, btime, movetime);
                std::cout << "bestmove " << engine.format_move(best) << std::endl;
            });
        } 
        else if (command == "stop") {
            engine.stop_search();
            if (search_thread.joinable()) search_thread.join();
        } 
        else if (command == "result") {
            std::string res; iss >> res;
            if (res == "1-0") engine.record_game_result(1.0);
            else if (res == "0-1") engine.record_game_result(0.0);
            else engine.record_game_result(0.5);
        }
        else if (command == "quit") {
            engine.stop_search();
            if (search_thread.joinable()) search_thread.join();
            break;
        }
    }
    return 0;
}