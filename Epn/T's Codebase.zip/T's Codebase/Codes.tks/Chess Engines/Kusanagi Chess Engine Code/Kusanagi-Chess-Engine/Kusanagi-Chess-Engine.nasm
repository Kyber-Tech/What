; ============================================================================
; Kusanagi.asm - V.1.5.6 - The Ghost in the Machine Code
; Version: 1.5.6
; Authored by: Tsukishiro Renji
;
; How to Compile and Run (on Linux):
;   nasm -f elf64 -g Kusanagi.asm -o Kusanagi.o
;   ld Kusanagi.o -o Kusanagi
;   ./Kusanagi
; ============================================================================

; --- Linux Syscall Numbers (x86_64) ---
SYS_OPEN equ 2
SYS_MMAP equ 9
SYS_CLOSE equ 3
SYS_CLONE       equ 56
SYS_GETTIMEOFDAY equ 96
SYS_FUTEX       equ 202
SYS_SCHED_GETAFFINITY equ 204

; --- File Open Flags ---
%define O_RDONLY 0

; --- Clone Flags (for creating threads) ---
CLONE_VM        equ 0x00000100
CLONE_FILES     equ 0x00000400
CLONE_SIGHAND   equ 0x00000800
CLONE_THREAD    equ 0x00010000
CLONE_PARENT_SETTID equ 0x00100000
CLONE_CHILD_CLEARTID equ 0x00200000
CLONE_FLAGS     equ CLONE_VM | CLONE_FILES | CLONE_SIGHAND | CLONE_THREAD | CLONE_PARENT_SETTID | CLONE_CHILD_CLEARTID

; --- Futex Operations ---
FUTEX_WAIT      equ 0
FUTEX_WAKE      equ 1

; --- mmap flags ---
PROT_READ   equ 0x1
MAP_PRIVATE equ 0x2

; --- Tablebase File Information ---
struc tb_file
    .filename: resb 64
    .pointer:  resq 1
    .size:     resq 1
endstruc

tablebase_files:
    istruc tb_file
        at .filename, db "KRPvK.rtbw", 0
        at .pointer,  dq 0
        at .size,     dq 0
    iend
active_tb_pointer: dq 0

%define MAX_THREADS 192
%define STACK_SIZE  (2 * 1024 * 1024)

struc ThreadInfo
    .state:         resd 1
    .futex_var:     resd 1
    .stack_base:    resq 1
    .board_copy:    resb 80
    .alpha:         resd 1
    .beta:          resd 1
    .depth:         resd 1
    .score:         resd 1
endstruc
%define ThreadInfo_size (SIZEOF.ThreadInfo)

section .data
EMPTY       equ 0; W_PAWN      equ 1; W_KNIGHT    equ 2; W_BISHOP    equ 3; W_ROOK      equ 4; W_QUEEN     equ 5; W_KING      equ 6
B_PAWN      equ 9; B_KNIGHT    equ 10; B_BISHOP    equ 11; B_ROOK      equ 12; B_QUEEN     equ 13; B_KING      equ 14
PIECE_MASK equ 7; COLOR_MASK equ 8
TT_EXACT equ 1; TT_LOWERBOUND equ 2; TT_UPPERBOUND equ 3
W_OO_RIGHT equ 1
W_OOO_RIGHT equ 2
B_OO_RIGHT equ 4
B_OOO_RIGHT equ 8

piece_values: dw 0, 100, 320, 330, 500, 900, 10000
passed_pawn_bonus: dw 0, 10, 30, 50, 75, 100, 150, 0
pst_pointers: dq pawn_pst, knight_pst, bishop_pst, rook_pst, queen_pst, king_pst

knight_offsets: db -17, -15, -10, -6, 6, 10, 15, 17
bishop_offsets: db -9, -7, 7, 9
rook_offsets:   db -8, -1, 1, 8
king_offsets:   db -9, -8, -7, -1, 1, 7, 8, 9

pawn_pst:
    db   0,   0,   0,   0,   0,   0,   0,   0,  50,  50,  50,  50,  50,  50,  50,  50
    db  10,  10,  20,  30,  30,  20,  10,  10,   5,   5,  10,  25,  25,  10,   5,   5
    db   0,   0,   0,  20,  20,   0,   0,   0,   5,  -5, -10,   0,   0, -10,  -5,   5
    db   5,  10,  10, -20, -20,  10,  10,   5,   0,   0,   0,   0,   0,   0,   0,   0
knight_pst:
    db -50, -40, -30, -30, -30, -30, -40, -50, -40, -20,   0,   0,   0,   0, -20, -40
    db -30,   0,  10,  15,  15,  10,   0, -30, -30,   5,  15,  20,  20,  15,   5, -30
    db -30,   0,  15,  20,  20,  15,   0, -30, -30,   5,  10,  15,  15,  10,   5, -30
    db -40, -20,   0,   5,   5,   0, -20, -40, -50, -40, -30, -30, -30, -30, -40, -50
bishop_pst:
    db -20, -10, -10, -10, -10, -10, -10, -20, -10,   0,   0,   0,   0,   0,   0, -10
    db -10,   0,   5,  10,  10,   5,   0, -10, -10,   5,   5,  10,  10,   5,   5, -10
    db -10,   0,  10,  10,  10,  10,   0, -10, -10,  10,  10,  10,  10,  10,  10, -10
    db -10,   5,   0,   0,   0,   0,   5, -10, -20, -10, -10, -10, -10, -10, -10, -20
rook_pst:
    db   0,   0,   0,   0,   0,   0,   0,   0,   5,  10,  10,  10,  10,  10,  10,   5
    db  -5,   0,   0,   0,   0,   0,   0,  -5,  -5,   0,   0,   0,   0,   0,   0,  -5
    db  -5,   0,   0,   0,   0,   0,   0,  -5,  -5,   0,   0,   0,   0,   0,   0,  -5
    db  -5,   0,   0,   0,   0,   0,   0,  -5,   0,   0,   0,   5,   5,   0,   0,   0
queen_pst:
    db -20, -10, -10,  -5,  -5, -10, -10, -20, -10,   0,   0,   0,   0,   0,   0, -10
    db -10,   0,   5,   5,   5,   5,   0, -10,  -5,   0,   5,   5,   5,   5,   0,  -5
    db   0,   0,   5,   5,   5,   5,   0,  -5, -10,   5,   5,   5,   5,   5,   0, -10
    db -10,   0,   5,   0,   0,   0,   0, -10, -20, -10, -10,  -5,  -5, -10, -10, -20
king_pst:
    db -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30
    db -30, -40, -40, -50, -50, -40, -40, -30, -30, -40, -40, -50, -50, -40, -40, -30
    db -20, -30, -30, -40, -40, -30, -30, -20, -10, -20, -20, -20, -20, -20, -20, -10
    db  20,  20,   0,   0,   0,   0,  20,  20,  20,  30,  10,   0,   0,  10,  30,  20

initial_board:
    db B_ROOK, B_KNIGHT, B_BISHOP, B_QUEEN, B_KING, B_BISHOP, B_KNIGHT, B_ROOK
    db B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN
    db 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0
    db W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN
    db W_ROOK, W_KNIGHT, W_BISHOP, W_QUEEN, W_KING, W_BISHOP, W_KNIGHT, W_ROOK

zobrist_keys:
    piece_keys: times 64 * 12 dq 0
    side_key: dq 0
    castling_keys: times 16 dq 0
    en_passant_keys: times 8 dq 0
opening_book_path: db "book.bin", 0
bestmove_msg: db "bestmove "
len_bestmove_msg: equ $ - bestmove_msg
newline: db 10
square_to_an: db "a1b1c1d1e1f1g1h1a2b2c2d2e2f2g2h2a3b3c3d3e3f3g3h3a4b4c4d4e4f4g4h4a5b5c5d5e5f5g5h5a6b6c6d6e6f6g6h6a7b7c7d7e7f7g7h7a8b8c8d8e8f8g8h8"
fen_pieces: db "PNBRQK  pnbrqk"
lcg_seed: dq 123456789123456789

uci_cmd_uci:        db "uci",0
uci_cmd_isready:    db "isready",0
uci_cmd_ucinewgame: db "ucinewgame",0
uci_cmd_position:   db "position",0
uci_cmd_startpos:   db "startpos",0
uci_cmd_fen:        db "fen",0
uci_cmd_moves:      db "moves",0
uci_cmd_go:         db "go",0
uci_cmd_quit:       db "quit",0
uci_cmd_depth:      db "depth",0
uci_cmd_movetime:   db "movetime",0
uci_cmd_wtime:      db "wtime",0
uci_cmd_btime:      db "btime",0
uci_cmd_winc:       db "winc",0
uci_cmd_binc:       db "binc",0
uci_cmd_infinite:   db "infinite",0

uci_response_id:    db "id name Kusanagi v1.5.6",10,0
uci_response_author:db "id author Tonmoy-KS",10,0
uci_response_uciok: db "uciok",10,0
uci_response_readyok:db "readyok",10,0

section .bss
board: resb 64
side_to_move: resb 1
castling_rights: resb 1
en_passant_square: resb 1
move_list: resb 256 * 4
move_list_end: resq 1
root_best_move: resd 1
nodes_searched: resq 1
move_scores: resd 256
opening_book: resb 16 * 1024 * 1024
book_size: resq 1
uci_input_buffer: resb 4096
token_pointer:    resq 1
fen_buffer: resb 100
best_score_prev_iter: resd 1
zobrist_hash: resq 1
TT_SIZE: equ 1024 * 1024
transposition_table: resb TT_SIZE * 16

; --- Time Management Variables ---
search_start_time_ms: resq 1
search_stop_time_ms:  resq 1
timeval_struct:       resq 2

; --- Thread Management ---
threads:        istruc ThreadInfo, MAX_THREADS
num_threads:    resq 1
is_searching:   resb 1
cpu_set:        resb 128

section .text
extern probe_syzygy_wdl_from_fen
global _start

%macro ADD_MOVE 2
    mov rdi, [move_list_end]
    mov byte [rdi], %1
    mov byte [rdi+1], %2
    mov dword [rdi+2], 0 ; Clear promo/flag bytes
    add rdi, 4
    mov [move_list_end], rdi
%endmacro

%macro ADD_PROMOTION_MOVE 4 ; from, to, promo_piece, flag
    mov rdi, [move_list_end]
    mov byte [rdi], %1
    mov byte [rdi+1], %2
    mov byte [rdi+2], %3
    mov byte [rdi+3], %4
    add rdi, 4
    mov [move_list_end], rdi
%endmacro

_start:
    ; --- Lazy SMP: Determine core count and create threads ---
    mov rax, SYS_SCHED_GETAFFINITY
    mov rdi, 0
    mov rsi, 128
    lea rdx, [cpu_set]
    syscall
    popcnt rax, [cpu_set]
    popcnt rbx, [cpu_set + 8]
    add rax, rbx
    mov [num_threads], rax

    mov r12, 1
.create_thread_loop:
    cmp r12, [num_threads]
    jge .master_thread_start
    mov rax, SYS_MMAP
    mov rdi, 0
    mov rsi, STACK_SIZE
    mov rdx, 3
    mov r10, 34
    mov r8, -1
    mov r9, 0
    syscall
    lea rbx, [threads + r12 * ThreadInfo_size]
    mov [rbx + ThreadInfo.stack_base], rax
    add rax, STACK_SIZE
    sub rax, 16
    mov rdi, CLONE_FLAGS
    mov rsi, rax
    lea rdx, [rbx + ThreadInfo.state]
    lea r10, [rbx + ThreadInfo.state]
    mov r8, rbx
    mov rax, SYS_CLONE
    syscall
    inc r12
    jmp .create_thread_loop

.master_thread_start:
    call initialize_engine
    jmp .main_loop

; --- Main UCI Loop ---
.main_loop:
    mov byte [token_pointer], 0 ; Reset token parser for each new line
    mov rax, 0 ; sys_read
    mov rdi, 0 ; stdin
    mov rsi, uci_input_buffer
    mov rdx, 4096
    syscall

    call parse_token
    mov rdi, rax
    cmp rdi, 0; je .main_loop ; Empty line

    mov rsi, uci_cmd_uci; call strcmp; test rax, rax; jz .handle_uci
    mov rsi, uci_cmd_isready; call strcmp; test rax, rax; jz .handle_isready
    mov rsi, uci_cmd_ucinewgame; call strcmp; test rax, rax; jz .handle_ucinewgame
    mov rsi, uci_cmd_position; call strcmp; test rax, rax; jz .handle_position
    mov rsi, uci_cmd_go; call strcmp; test rax, rax; jz .handle_go
    mov rsi, uci_cmd_quit; call strcmp; test rax, rax; jz .handle_quit
    jmp .main_loop

.handle_uci:
    mov rsi, uci_response_id; call print_string
    mov rsi, uci_response_author; call print_string
    mov rsi, uci_response_uciok; call print_string
    jmp .main_loop

.handle_isready:
    mov rsi, uci_response_readyok; call print_string
    jmp .main_loop

.handle_ucinewgame:
    call initialize_board
    jmp .main_loop

.handle_quit:
    mov rax, 60; xor rdi, rdi; syscall

.handle_position:
    call parse_token
    mov rdi, rax
    mov rsi, uci_cmd_startpos; call strcmp
    test rax, rax; jz .pos_startpos
    ; TODO: Implement FEN parsing
    jmp .main_loop
.pos_startpos:
    call initialize_board
.parse_moves:
    call parse_token
    cmp rax, 0; je .main_loop
    mov rdi, rax
    mov rsi, uci_cmd_moves; call strcmp
    test rax, rax; jne .main_loop
.moves_loop:
    call parse_token
    cmp rax, 0; je .main_loop
    mov rdi, rax
    call parse_uci_move
    mov r10, rax
    call make_move
    jmp .moves_loop

.handle_go:
    mov r8, 100; xor r9, r9; xor r12, r12; xor r13, r13; xor r14, r14; xor r15, r15; xor rcx, rcx
.go_loop:
    call parse_token
    cmp rax, 0; je .calculate_time_and_search
    mov rdi, rax
    mov rsi, uci_cmd_depth; call strcmp; test rax, rax; jne .check_movetime
    call parse_token; mov rdi, rax; call parse_int; mov r8, rax; jmp .go_loop
.check_movetime:
    mov rsi, uci_cmd_movetime; call strcmp; test rax, rax; jne .check_wtime
    call parse_token; mov rdi, rax; call parse_int; mov r9, rax; jmp .go_loop
.check_wtime:
    mov rsi, uci_cmd_wtime; call strcmp; test rax, rax; jne .check_btime
    call parse_token; mov rdi, rax; call parse_int; mov r12, rax; jmp .go_loop
.check_btime:
    mov rsi, uci_cmd_btime; call strcmp; test rax, rax; jne .check_winc
    call parse_token; mov rdi, rax; call parse_int; mov r13, rax; jmp .go_loop
.check_winc:
    mov rsi, uci_cmd_winc; call strcmp; test rax, rax; jne .check_binc
    call parse_token; mov rdi, rax; call parse_int; mov r14, rax; jmp .go_loop
.check_binc:
    mov rsi, uci_cmd_binc; call strcmp; test rax, rax; jne .check_infinite
    call parse_token; mov rdi, rax; call parse_int; mov r15, rax; jmp .go_loop
.check_infinite:
    mov rsi, uci_cmd_infinite; call strcmp; test rax, rax; jne .go_loop
    mov rcx, 1; jmp .go_loop

.calculate_time_and_search:
    mov rax, -1
    cmp r9, 0; jne .set_movetime
    cmp rcx, 1; je .set_infinite_time
    cmp r12, 0; je .no_time_control
    mov al, [side_to_move]; test al, al; jz .white_time_calc
    mov rax, r13; mov rbx, 25; div rbx; add rax, r15; jmp .time_is_set
.white_time_calc:
    mov rax, r12; mov rbx, 25; div rbx; add rax, r14; jmp .time_is_set
.set_movetime:
    mov rax, r9; jmp .time_is_set
.set_infinite_time:
    mov rax, -1; jmp .time_is_set
.no_time_control:
    mov rax, -1
.time_is_set:
    cmp rax, -1; je .start_search_no_time_limit
    mov rdi, rax
    call get_current_time_ms
    mov [search_start_time_ms], rax
    add rax, rdi
    mov [search_stop_time_ms], rax
    jmp .start_search
.start_search_no_time_limit:
    mov qword [search_stop_time_ms], 0x7FFFFFFFFFFFFFFF
.start_search:
    mov edi, r8d
    call iterative_deepening
    call print_best_move
    jmp .main_loop

; --- Helper thread entry point ---
helper_entry:
    mov r12, rdi
.wait_loop:
    mov rdi, [r12 + ThreadInfo.futex_var]
    mov rsi, 0
    call futex_wait
    jmp .wait_loop

; --- Engine Initialization and Search Functions ---
initialize_engine:
    call initialize_board
    call initialize_zobrist_keys
    call load_opening_book
    ret

iterative_deepening:
    mov dword [best_score_prev_iter], 0
    mov ecx, 1
.depth_loop:
    call get_current_time_ms
    cmp rax, [search_stop_time_ms]
    jge .id_done
    cmp ecx, edi
    jg .id_done
    mov edx, [best_score_prev_iter]
    mov esi, edx; sub esi, 50; add edx, 50
    mov r15d, ecx
    mov edi, ecx
    call search_root
    cmp eax, esi; jle .research_low
    cmp eax, edx; jge .research_high
    jmp .store_results
.research_low:
    mov esi, -30000; mov edi, r15d; call search_root; jmp .store_results
.research_high:
    mov edx, 30000; mov edi, r15d; call search_root
.store_results:
    mov [best_score_prev_iter], eax
    call get_current_time_ms
    cmp rax, [search_stop_time_ms]
    jge .id_done
    inc ecx
    jmp .depth_loop
.id_done:
    ret

search_root:
    push r12; push r13; push r14; push r15
    mov r12d, esi             ; r12d = alpha
    mov r13d, edx             ; r13d = beta
    mov r15, rdi              ; r15 = depth
    mov dword [root_best_move], 0
    mov qword [nodes_searched], 0

    call generate_moves
    call score_moves

    mov r11, 0                ; move_index
    mov r9d, -30001           ; best_score

.move_loop:
    mov r10, [move_list_end]; sub r10, move_list; shr r10, 2; cmp r11, r10
    jge .done_searching

call find_next_best_move
call make_move

    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    call is_king_in_check
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    test al, al
    jnz .illegal_root_move    ; If illegal, jump to the handler

    mov rdi, r15; dec rdi      ; depth-1
    mov esi, r13d; neg esi     ; -beta
    mov edx, r12d; neg edx     ; -alpha
    call negamax
    neg eax

    call unmake_move

    cmp eax, r12d
    jle .next_move_in_loop    ; Not better than alpha, continue

    ; New best move found
    mov r12d, eax             
    mov r9d, eax              
    mov cl, r8b               ; from
    mov ch, r9b               ; to
    mov [root_best_move], cx
    jmp .next_move_in_loop

.illegal_root_move:
    call unmake_move          ; Unmake the illegal move

.next_move_in_loop:
    inc r11
    jmp .move_loop

.done_searching:
    mov eax, r9d
    pop r15; pop r14; pop r13; pop r12;
    ret

negamax:
    push rbp; mov rbp, rsp; sub rsp, 8 ; Make space for best_flag
    push rbx; push r12; push r13; push r14; push r15

    call compute_zobrist_hash
    mov rax, [zobrist_hash]
    mov rbx, TT_SIZE - 1
    and rax, rbx
    lea r10, [transposition_table + rax*16] ; r10 = TT entry address

    cmp [r10], qword [zobrist_hash]
    jne .tt_miss

    mov eax, [r10+8]  ; Stored score/flag
    mov ebx, [r10+12] ; Stored depth
    cmp ebx, edi      ; if (stored_depth < current_depth) -> miss
    jl .tt_miss

    mov bl, al      ; flag in bl
    shr eax, 8      ; score in eax

    cmp bl, TT_EXACT
    je .tt_hit_return
    cmp bl, TT_LOWERBOUND
    je .tt_hit_lower
    ; It's an UPPERBOUND
    cmp eax, esi      ; if (score <= alpha) return score
    jle .tt_hit_return
    jmp .tt_miss
.tt_hit_lower:
    cmp eax, edx      ; if (score >= beta) return score
    jge .tt_hit_return

.tt_miss:
    mov rbx, rdi ; rbx = current_depth (edi)
    sub rbx, 3   ; NMP uses a reduction of 3 (R=3)
    cmp rdi, 3   ; Don't perform NMP at shallow depths
    jle .nmp_skip

    call is_king_in_check ; Ye Captain is under Cannon fire!
    test al, al
    jnz .nmp_skip ; Don't perform NMP if we are in check

    ; Make a null move by just flipping the side to move
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al

    mov rdi, rbx      ; depth = current_depth - R - 1
    mov esi, edx; neg esi ; new_alpha = -beta
    mov edx, esi; inc edx ; new_beta = -beta + 1
    call negamax
    neg eax

    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al

    cmp eax, edx ; if (score >= beta) -> prune this branch
    jge .nmp_prune
.nmp_skip:
    inc qword [nodes_searched]
    cmp rdi, 0; je .quiescence_search_entry

    mov r12d, esi             ; r12d = alpha
    mov r13d, edx             ; r13d = beta
    mov r14, rdi              ; r14  = depth
    mov r8d, -30001           ; best_score = -infinity
    mov byte [rbp-8], TT_UPPERBOUND ; best_flag = TT_UPPERBOUND 

    call generate_moves
    call score_moves
    mov r15, 0                ; move_index = 0

.move_loop_negamax:
    mov rbx, [move_list_end]; sub rbx, move_list; shr rbx, 2; cmp r15, rbx
    jge .done_searching

   call find_next_best_move
; Note: find_next_best_move uses r10 for the move address
  call make_move

    ; Legality check
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    call is_king_in_check
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    test al, al; jnz .illegal_move

; Is this the first move we are searching? (move_index == 0)
cmp r15, 0
jne .late_move_search_setup

; --- 1. Full Window Search (PV-Move) ---
; The first move is our best guess, so we search it with a full window.
.full_window_search:
    mov rdi, r14; dec rdi
    mov esi, r13d; neg esi
    mov edx, r12d; neg edx
    call negamax
    neg eax
    jmp .store_score

; --- 2. Null Window Search with Late Move Reductions ---
.late_move_search_setup:
    ; --- LMR Conditions ---
    mov rbx, 0 ; rbx will hold our depth reduction amount. Default to 0.
    cmp r14, 3 ; Is depth >= 3?
    jle .apply_reduction
    cmp r15, 3 ; Is move_index >= 4?
    jle .apply_reduction

    ; Check if the move is tactical (capture or promotion)
    movzx rdx, byte [r10+1] ; to_square
    cmp byte [board+rdx], EMPTY
    jne .apply_reduction ; It's a capture, don't reduce.
    cmp byte [r10+2], 0
    jne .apply_reduction ; It's a promotion, don't reduce.

    ; Check if we are in check
    push r15 ; Save move_index
    call is_king_in_check
    pop r15
    test al, al
    jnz .apply_reduction ; In check, don't reduce.

    ; --- All conditions met. Calculate the reduction. ---
    mov rbx, 1 ; Base reduction is 1 ply.
    ; For very late moves, we can reduce even more.
    ; R = 1 + (move_index / 8)
    mov rax, r15
    shr rax, 3 ; rax = r15 / 8
    add rbx, rax

.apply_reduction:
    mov rdi, r14; dec rdi
    sub rdi, rbx ; new_depth = depth - 1 - reduction

    ; Search with a null window to quickly see if this move is better than alpha
    mov esi, r12d; neg esi
    dec esi
    mov edx, r12d; neg edx
    call negamax
    neg eax

    ; --- 3. Re-Search if Necessary ---
    cmp eax, r12d
    jle .store_score ; Failed low, the move was bad, as expected.

    ; The reduced search proved the move is good. We MUST re-search
    ; with the FULL depth to get an accurate score.
    mov rdi, r14; dec rdi ; Use the ORIGINAL depth-1
    mov esi, r13d; neg esi
    mov edx, r12d; neg edx
    call negamax
    neg eax

.store_score:
    call unmake_move

    cmp eax, r8d
    jle .next_move_negamax
    mov r8d, eax

    cmp eax, r12d
    jle .next_move_negamax
    mov r12d, eax
    mov byte [rbp-8], TT_EXACT

    cmp r12d, r13d
    jge .beta_cutoff

.next_move_negamax:
    inc r15
    jmp .move_loop_negamax

.illegal_move: ; ye don't know what to do!
    call unmake_move
    jmp .next_move_negamax

.beta_cutoff:
    mov byte [rbp-8], TT_LOWERBOUND ; This was a beta cutoff, score is a lower bound
    mov r8d, r13d                   ; The score is at least beta

.done_searching:
    ; r10 still holds the TT entry address
    mov [r10], qword [zobrist_hash]
    mov eax, r8d
    shl eax, 8
    mov al, [rbp-8]
    mov [r10+8], eax ; Store score and flag
    mov [r10+12], edi ; Store depth
    mov eax, r8d ; Return the actual score
    jmp .exit

.quiescence_search_entry:
    call quiescence_search
    jmp .exit

.nmp_prune:
    ; The null move search was so good that it caused a beta cutoff.
    ; We can trust this result and prune this entire node.
    mov eax, edx ; Return beta
    jmp .exit

.tt_hit_return:
    mov r8d, eax ; Use the score from the TT
    jmp .exit ; Jmp to common exit path

.exit:
    pop r15; pop r14; pop r13; pop r12; pop rbx
    add rsp, 8 ; Clean up stack space for best_flag
    pop rbp
    ret

.exit:
    pop r15; pop r14; pop r13; pop r12; pop rbx
    add rsp, 8 ; Clean up stack space for best_flag
    pop rbp
    ret

quiescence_search:
    push rbp; mov rbp, rsp; push r12; push r13; push r14; push r15
    inc qword [nodes_searched]
    call evaluate
    cmp byte [side_to_move], 0; jne .negate_eval
.continue_eval:
    cmp eax, edx; jge .q_return_beta
    cmp eax, esi; jle .alpha_ok; mov esi, eax
.alpha_ok:
    mov r12d, esi; mov r13d, edx; mov r14d, eax
    call generate_tactical_moves; call score_moves
    mov r15, 0
.q_move_loop:
    mov r10, [move_list_end]; sub r10, move_list; shr r10, 2; cmp r15, r10
    jge .q_done
    call find_next_best_move
    movzx ecx, byte [r10]; movzx edx, byte [r10+1]
    call make_move
    mov rdi, 0; mov esi, r13d; neg esi; mov edx, r12d; neg edx
    call quiescence_search; neg eax
    call unmake_move; inc r15
    cmp eax, r14d; jle .q_next_move; mov r14d, eax
    cmp eax, r12d; jle .q_next_move; mov r12d, eax
    cmp r12d, r13d; jge .q_beta_cutoff
.q_next_move: jmp .q_move_loop
.negate_eval: neg eax; jmp .continue_eval
.q_beta_cutoff: mov eax, r13d; jmp .q_exit
.q_return_beta: mov eax, edx; jmp .q_exit
.q_done: mov eax, r14d
.q_exit: pop r15; pop r14; pop r13; pop r12; mov rsp, rbp; pop rbp; ret

evaluate:
    push rbx; push rcx; push rdx; push rsi; push rdi

    ; First, try probing the tablebase
    call probe_tablebase
    cmp rax, 32767 ; Check for "not found"
    jne .eval_done ; If found, rax already has the score.

    ; --- If not in TB, do classical evaluation ---
    xor edx, edx ; Clear total score

    ; Base material and PSTs
    call evaluate_base
    add edx, eax

    ; Advanced evaluation components
    call evaluate_pawns
    add edx, eax
    call evaluate_king_safety
    add edx, eax
    call evaluate_rooks
    add edx, eax

    mov eax, edx

.eval_done:
    pop rdi; pop rsi; pop rdx; pop rcx; pop rbx
    ret

; This is the original part is now separated
evaluate_base:
    push rbx; push rcx; push rsi; push rdi; push r8; push r9
    xor edx, edx
    mov rcx, 0
.eval_base_loop:
    cmp rcx, 64; jge .eval_base_done
    movzx rbx, byte [board + rcx]; cmp rbx, EMPTY; je .next_eval_square
    mov rdi, rbx; and rdi, COLOR_MASK; and rbx, PIECE_MASK
    movsx rax, word [piece_values - 2 + rbx*2]
    mov rsi, [pst_pointers - 8 + rbx*8]
    cmp rdi, 0; je .is_white_pst
    mov r8, 63; sub r8, rcx; movsx r9, byte [rsi + r8]; neg r9; add rax, r9; jmp .add_to_score
.is_white_pst: movsx r9, byte [rsi + rcx]; add rax, r9
.add_to_score: cmp rdi, 0; je .add_val; sub edx, eax; jmp .next_eval_square
.add_val: add edx, eax
.next_eval_square: inc rcx; jmp .eval_base_loop
.eval_base_done:
    mov eax, edx
    pop r9; pop r8; pop rdi; pop rsi; pop rcx; pop rbx
    ret
.eval_loop:
    cmp rcx, 64; jge .eval_done
    movzx rbx, byte [board + rcx]; cmp rbx, EMPTY; je .next_square
    mov rdi, rbx; and rdi, COLOR_MASK; and rbx, PIECE_MASK
    movsx rax, word [piece_values - 2 + rbx*2]
    mov rsi, [pst_pointers - 8 + rbx*8]
    cmp rdi, 0; je .is_white_pst
    mov r8, 63; sub r8, rcx; movsx r9, byte [rsi + r8]; neg r9; add rax, r9; jmp .add_to_score
.is_white_pst: movsx r9, byte [rsi + rcx]; add rax, r9
.add_to_score: cmp rdi, 0; je .add_val; sub edx, eax; jmp .next_square
.add_val: add edx, eax
.next_square: inc rcx; jmp .eval_loop
.eval_done: mov eax, edx; pop rdi; pop rsi; pop rcx; pop rbx; ret

score_moves:
    push r12; push r13; mov r10, move_list; mov r12, 0
.scoring_loop:
    cmp r10, [move_list_end]; jge .scoring_done
    movzx ecx, byte [r10]; movzx edx, byte [r10+1]; movzx eax, byte [board+rdx]
    cmp eax, EMPTY; jne .is_capture
    mov dword [move_scores + r12*4], 0; jmp .next_move
.is_capture:
    mov r8, rcx; mov r9, rdx
    call static_exchange_evaluation; add eax, 1000000
    mov [move_scores + r12*4], eax
.next_move: add r10, 4; inc r12; jmp .scoring_loop
.scoring_done: pop r13; pop r12; ret

static_exchange_evaluation: ; ARRR! This is a landlubber From stockfish! I will make this walk to plank later!
    push rbx; push rcx; push rdx; push rsi; push rdi; push r12; push r13; push r14; push r15
    sub rsp, 32 
    mov r12, rsp
    mov r14, r8
    mov r15, r9
    movzx eax, byte [board + r15]
    and eax, PIECE_MASK
    movsx eax, word [piece_values - 2 + eax*2]
    mov [r12], ax
    mov edi, 1
.see_loop:
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    mov rsi, r15
    mov dl, [side_to_move]
    call get_least_valuable_attacker
    cmp rax, -1
    je .see_done
    movzx ecx, byte [board+rax]
    and ecx, PIECE_MASK
    movsx ecx, word [piece_values - 2 + ecx*2]
    mov [r12 + edi*2], cx
    inc edi
    mov cl, [board+rax]
    mov byte [board+r15], cl
    mov byte [board+rax], EMPTY
    jmp .see_loop
.see_done:
    mov ecx, edi
.unwind_loop:
    dec ecx
    cmp ecx, 0
    jl .unwind_done
    mov al, [board+r15]
    mov byte [board+rax], al
    movzx ebx, word [r12 + ecx*2]
    mov byte [board+r15], bl
    jmp .unwind_loop
.unwind_done:
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    movsx eax, word [r12]
    mov ecx, 1
.calc_see:
    cmp ecx, edi
    jge .final_see
    movsx edx, word [r12 + ecx*2]
    sub eax, edx
    inc ecx
    cmp ecx, edi
    jge .final_see
    movsx edx, word [r12 + ecx*2]
    add eax, edx
    inc ecx; jmp .calc_see
.final_see:
    add rsp, 32
    pop r15; pop r14; pop r13; pop r12; pop rdi; pop rsi; pop rdx; pop rcx; pop rbx
    ret

; Helper utility: is_move_on_board(rax=from, rbx=to) -> al (0 or 1)
; Checks for board wrap-around. Essential for knight and pawn moves.
is_move_on_board:
    push rdx
    push rcx
    mov rcx, 8

    mov rdi, rax
    xor rdx, rdx
    div rcx             ; from_file in rdx
    push rdx

    mov rdi, rbx
    xor rdx, rdx
    div rcx             ; to_file in rdx

    pop rcx             ; pop from_file into rcx
    sub rdx, rcx        ; diff = to_file - from_file

    cmp rdx, 2
    jg .move_wraps
    cmp rdx, -2
    jl .move_wraps

    mov rax, 1
    jmp .util_done
.move_wraps:
    xor rax, rax
.util_done:
    pop rcx
    pop rdx
    ret

;--------------------------------------------------------------------------
; check_knight_attacks(rdi: square, rsi: attacker_color) -> rax (0 or 1)
;--------------------------------------------------------------------------
check_knight_attacks:
    push rbx; push rcx; push rdx; push r8; push r9
    mov r8, rdi             ; r8 = target square
    mov r9b, sil            ; r9b = attacker color
    mov rdx, knight_offsets
    mov rcx, 8              ; 8 knight moves
.loop:
    movsx rbx, byte [rdx]
    add rbx, r8
    cmp rbx, 0
    jl .next
    cmp rbx, 64
    jge .next
    mov rax, r8
    call is_move_on_board
    test al, al
    jz .next
    movzx rax, byte [board + rbx]
    cmp rax, EMPTY
    je .next
    mov al, byte [board + rbx]
    and al, COLOR_MASK
    cmp al, r9b
    jne .next
    mov al, byte [board + rbx]
    and al, PIECE_MASK
    cmp al, W_KNIGHT
    jne .next
    mov rax, 1
    jmp .exit
.next:
    inc rdx
    dec rcx
    jnz .loop
    xor rax, rax
.exit:
    pop r9; pop r8; pop rdx; pop rcx; pop rbx
    ret

;--------------------------------------------------------------------------
; check_sliding_attacks(rdi: square, rsi: attacker_color) -> rax (0 or 1)
; Checks for rook, bishop, queen, and king attacks.
;--------------------------------------------------------------------------
check_sliding_attacks:
    push rbx; push rcx; push rdx; push r10; push r11; push r12; push r13
    mov r10, rdi            ; r10 = target square
    mov r11b, sil           ; r11b = attacker color
    ; --- Check Diagonal (Bishop/Queen) ---
    mov r12, bishop_offsets
    mov r13, 4
    call .sliding_loop
    test al, al; jnz .found
    ; --- Check Straight (Rook/Queen) ---
    mov r12, rook_offsets
    mov r13, 4
    call .sliding_loop
    test al, al; jnz .found
    ; --- Check King ---
    mov rcx, 8
    mov rdx, king_offsets
.king_loop:
    movsx rax, byte [rdx]
    add rax, r10
    cmp rax, 0; jl .next_king
    cmp rax, 64; jge .next_king
    mov cl, byte [board+rax]; and cl, PIECE_MASK; cmp cl, W_KING; jne .next_king
    mov cl, byte [board+rax]; and cl, COLOR_MASK; cmp cl, r11b; jne .next_king
    mov rax, 1; jmp .exit
.next_king:
    inc rdx; dec rcx; jnz .king_loop
.not_found:
    xor rax, rax
    jmp .exit
.found:
    mov rax, 1
.exit:
    pop r13; pop r12; pop r11; pop r10; pop rdx; pop rcx; pop rbx
    ret
; Helper for check_sliding_attacks
.sliding_loop:
    movsx rdi, byte [r12]
    mov rax, r10
.ray_loop:
    add rax, rdi
    cmp rax, 0; jl .next_dir
    cmp rax, 64; jge .next_dir
    mov rsi, rax; sub rsi, rdi; call is_move_on_board; test al, al; jz .next_dir
    mov cl, byte [board + rax]
    cmp cl, EMPTY; je .ray_loop
    mov ch, cl; and ch, COLOR_MASK; cmp ch, r11b; jne .next_dir
    and cl, PIECE_MASK
    cmp cl, W_QUEEN; je .attack_is_real
    cmp r12, bishop_offsets; je .check_bishop
    cmp cl, W_ROOK; jne .next_dir
    jmp .attack_is_real
.check_bishop:
    cmp cl, W_BISHOP; jne .next_dir
.attack_is_real:
    mov al, 1; ret
.next_dir:
    inc r12; dec r13; jnz .sliding_loop
    mov al, 0; ret

;--------------------------------------------------------------------------
; is_square_attacked(rdi: square, rsi: attacker_color) -> rax (0 or 1)
;--------------------------------------------------------------------------
is_square_attacked:
    push rbx; push r12; push r13; push r14
    mov r12, rdi; mov r13b, sil
    mov r14, r13; xor r14, 8 ; opponent_color
    cmp r14b, 0; jne .check_black_pawn_attack
    mov rax, r12; sub rax, 9; call .check_pawn_attack; test al, al; jnz .attack_found
    mov rax, r12; sub rax, 7; call .check_pawn_attack; test al, al; jnz .attack_found
    jmp .check_non_pawn
.check_black_pawn_attack:
    mov rax, r12; add rax, 7; call .check_pawn_attack; test al, al; jnz .attack_found
    mov rax, r12; add rax, 9; call .check_pawn_attack; test al, al; jnz .attack_found
.check_non_pawn:
    mov rdi, r12; mov rsi, r13; call check_knight_attacks; test al, al; jnz .attack_found
    mov rdi, r12; mov rsi, r13; call check_sliding_attacks; test al, al; jnz .attack_found
.no_attack:
    xor rax, rax; jmp .done
.attack_found:
    mov rax, 1
.done:
    pop r14; pop r13; pop r12; pop rbx; ret
; Helper for is_square_attacked
.check_pawn_attack:
    cmp rax, 0; jl .pawn_fail; cmp rax, 64; jge .pawn_fail
    mov rbx, r12; mov rsi, rax; call is_move_on_board; test al, al; jz .pawn_fail
    movzx rbx, byte [board + rax]; cmp rbx, EMPTY; je .pawn_fail
    mov cl, r13b; or cl, W_PAWN; cmp bl, cl; jne .pawn_fail
    mov al, 1; ret
.pawn_fail:
    mov al, 0; ret

;--------------------------------------------------------------------------
; is_king_in_check() -> rax (0 or 1)
; Uses the current side_to_move to find its king and see if it's attacked.
;--------------------------------------------------------------------------
is_king_in_check:
    push rdi; push rsi; push rbx; push rcx
    movzx rsi, byte [side_to_move]
    mov cl, sil; or cl, W_KING
    mov rbx, 0
.find_loop:
    cmp byte [board + rbx], cl; je .found_king
    inc rbx; cmp rbx, 64; jne .find_loop
.found_king:
    mov rdi, rbx; mov rsi, [side_to_move]; xor rsi, 8
    call is_square_attacked
    pop rcx; pop rbx; pop rsi; pop rdi
    ret

; Finds the square of the least valuable piece of 'attacker_color' that is attacking 'square'.
get_least_valuable_attacker:
    push rdi; push rsi; push r8; push r9

    mov r8, rdi             ; r8 = target square
    mov r9b, sil            ; r9b = attacker color

    ; --- Check in order of piece value (cheapest first) ---
    ; 1. Pawns
    call .find_pawn_attacker
    cmp rax, -1
    jne .lva_found

    ; 2. Knights
    call .find_knight_attacker
    cmp rax, -1
    jne .lva_found

    ; 3. Bishops (and diagonally, Queens)
    mov rdi, W_BISHOP
    call .find_sliding_attacker
    cmp rax, -1
    jne .lva_found

    ; 4. Rooks (and cardinally, Queens)
    mov rdi, W_ROOK
    call .find_sliding_attacker
    cmp rax, -1
    jne .lva_found

    ; 5. King
    call .find_king_attacker
    cmp rax, -1
    jne .lva_found

    ; No attacker found
    mov rax, -1

.lva_found:
    pop r9; pop r8; pop rsi; pop rdi
    ret

; --- Helper functions for get_least_valuable_attacker ---

.find_pawn_attacker:
    ; Checks for pawn attackers. r8=target_sq, r9b=attacker_color
    push rbx; push rcx;
    movzx ecx, r9b ; attacker_color
    xor ecx, 8     ; opponent_color (the color of the pawn being attacked)
    cmp cl, 0
    jne .check_black_pawn_attackers ; If opponent is not white, attackers must be black

    ; Attacker is Black, victim is White. Black pawns attack from NW/NE (+7, +9)
    mov rax, r8; add rax, 7; call .check_pawn_at_square
    cmp rax, -1; jne .pawn_exit
    mov rax, r8; add rax, 9; call .check_pawn_at_square
    jmp .pawn_exit

.check_black_pawn_attackers:
    ; Attacker is White, victim is Black. White pawns attack from SW/SE (-9, -7)
    mov rax, r8; sub rax, 9; call .check_pawn_at_square
    cmp rax, -1; jne .pawn_exit
    mov rax, r8; sub rax, 7; call .check_pawn_at_square

.pawn_exit:
    pop rcx; pop rbx
    ret

.check_pawn_at_square: ; rax=potential_sq, r8=target_sq, r9b=attacker_color
    push rbx
    mov rbx, rax ; Save potential square
    cmp rbx, 0; jl .pawn_fail
    cmp rbx, 64; jge .pawn_fail
    mov rax, r8
    call is_move_on_board ; check for wrap-around
    test al, al
    jz .pawn_fail
    movzx rax, byte [board + rbx]
    mov cl, r9b; or cl, W_PAWN
    cmp al, cl
    jne .pawn_fail
    mov rax, rbx ; Success! Return the square of the attacking pawn
    jmp .pawn_return
.pawn_fail:
    mov rax, -1
.pawn_return:
    pop rbx
    ret

.find_knight_attacker: ; ARRR! Horse in the sea!
    ; r8=target_sq, r9b=attacker_color
    push rbx; push rcx; push rdx
    mov rdx, knight_offsets; mov rcx, 8
.knight_loop:
    movsx rbx, byte [rdx]
    add rbx, r8
    cmp rbx, 0; jl .next_knight
    cmp rbx, 64; jge .next_knight
    mov rax, r8
    call is_move_on_board; test al, al; jz .next_knight
    movzx rax, byte [board + rbx]
    mov cl, r9b; or cl, W_KNIGHT
    cmp al, cl
    jne .next_knight
    mov rax, rbx; jmp .knight_exit
.next_knight:
    inc rdx; dec rcx; jnz .knight_loop
    mov rax, -1
.knight_exit:
    pop rdx; pop rcx; pop rbx
    ret

.find_sliding_attacker: ; rdi=piece_type (W_BISHOP/W_ROOK), r8=target, r9b=color
    push rbx; push rcx; push rdx; push r10; push r11; push r12
    mov r10, rdi ; r10b = piece type
    mov r11, r8  ; r11 = target square
    mov r12b, r9b ; r12b = attacker color
    cmp r10b, W_BISHOP
    je .slide_bishop
    mov rdx, rook_offsets; mov rcx, 4; jmp .slide_loop
.slide_bishop:
    mov rdx, bishop_offsets; mov rcx, 4
.slide_loop:
    movsx rbx, byte [rdx]
    mov rax, r11
.ray_loop:
    add rax, rbx
    cmp rax, 0; jl .next_direction
    cmp rax, 64; jge .next_direction
    mov rdi, rax; sub rdi, rbx; push rbx; mov rbx, rax; mov rax, rdi;
    call is_move_on_board; pop rbx; test al, al; jz .next_direction
    movzx rdi, byte [board + rax]
    cmp rdi, EMPTY; je .ray_loop ; Empty, continue sliding
    mov cl, r12b; and dil, COLOR_MASK; cmp dil, cl; jne .next_direction ; Blocked by friendly piece
    movzx rdi, byte [board + rax]; and rdi, PIECE_MASK
    cmp dil, r10b; je .found_attacker
    cmp dil, W_QUEEN; je .found_attacker
    jmp .next_direction ; Blocked by other enemy piece
.next_direction:
    inc rdx; dec rcx; jnz .slide_loop
    mov rax, -1; jmp .slide_exit
.found_attacker:
    ; rax already holds the attacker's square
.slide_exit:
    pop r12; pop r11; pop r10; pop rdx; pop rcx; pop rbx
    ret

.find_king_attacker:
    push rbx; push rcx; push rdx
    mov rdx, king_offsets; mov rcx, 8
.king_loop:
    movsx rbx, byte [rdx]
    add rbx, r8
    cmp rbx, 0; jl .next_king
    cmp rbx, 64; jge .next_king
    mov rax, r8
    call is_move_on_board; test al, al; jz .next_king
    movzx rax, byte [board + rbx]
    mov cl, r9b; or cl, W_KING
    cmp al, cl
    jne .next_king
    mov rax, rbx; jmp .king_exit
.next_king:
    inc rdx; dec rcx; jnz .king_loop
    mov rax, -1
.king_exit:
    pop rdx; pop rcx; pop rbx
    ret

; Checks if a square is attacked by the side that is NOT currently to move.
is_square_attacked_by_opponent:
    push rdi; push rsi      ; Stow the old gear

    ; --- Find the Enemy's Colors ---
    mov al, [side_to_move]
    xor al, 8               ; Flip the flag to the opponent's color
    mov sil, al             ; Load the enemy colors into rsi

    ; --- Send the Lookout Up the Mast ---
    ; rdi already holds the target square
    call is_square_attacked ; Call our seasoned trusty lookout

    pop rsi; pop rdi         ; Back to yer stations!
    ret


; Adds bonuses for pawn shields and penalties for open files near the king.
evaluate_king_safety:
    push rbx; push rcx; push rdx; push rsi; push rdi; push r8; push r9
    xor rax, rax ; total_score = 0
    ; --- Evaluate White King ---
    mov rdi, W_KING
    call find_piece
    cmp rax, -1
    je .eval_black_king
    mov r8, rax ; r8 = white_king_square
    call .eval_ks_for_side
    mov r9, rax ; r9 = white_ks_score
    ; --- Evaluate Black King ---
.eval_black_king:
    mov rdi, B_KING
    call find_piece
    cmp rax, -1
    je .ks_done
    mov r8, rax ; r8 = black_king_square
    call .eval_ks_for_side
    neg rax ; Black's score is subtracted
    add r9, rax ; Add to total
.ks_done:
    mov rax, r9
    pop r9; pop r8; pop rdi; pop rsi; pop rdx; pop rcx; pop rbx
    ret

; Helper: .eval_ks_for_side (r8: king_sq) -> rax (ks_score for that side)
.eval_ks_for_side:
    push rbx; push rcx; push rdx; push rdi; push rsi; push r9
    xor rax, rax ; side_score = 0
    movzx r9, byte [board+r8]; and r9, COLOR_MASK ; r9 = king_color
    ; --- Pawn Shield Bonus ---
    mov rax, r8; xor rdx, rdx; mov rbx, 8; div rbx; mov rbx, rdx ; rbx = king_file
    mov rcx, rbx; sub rcx, 1 ; file = king_file - 1
.shield_loop:
    cmp rcx, rbx
    jg .check_open_files
    cmp rcx, 0; jl .next_shield_file
    cmp rcx, 8; jge .next_shield_file
    ; Check square in front of king
    mov rdi, r8
    cmp r9, 0 ; if WHITE
    je .white_shield_check
    sub rdi, 8; jmp .do_shield_check ; Black king, pawn is below
.white_shield_check:
    add rdi, 8
.do_shield_check:
    movzx rsi, byte [board+rdi]; cmp rsi, EMPTY; je .next_shield_file
    mov sil, sih; and rsi, COLOR_MASK; cmp rsi, r9; jne .next_shield_file
    movzx rsi, byte [board+rdi]; and rsi, PIECE_MASK; cmp rsi, W_PAWN; jne .next_shield_file
    add rax, 10 ; Add bonus for shield pawn
.next_shield_file:
    inc rcx
    jmp .shield_loop
.check_open_files:
    ; --- Open File Penalty ---
    mov rcx, rbx; sub rcx, 1
.open_file_loop:
    cmp rcx, rbx
    jg .ks_helper_done
    cmp rcx, 0; jl .next_open_file
    cmp rcx, 8; jge .next_open_file
    mov rdi, rcx
    call is_file_open
    test al, al
    jz .next_open_file
    sub rax, 15 ; Penalty for open file near king
.next_open_file:
    inc rcx
    jmp .open_file_loop
.ks_helper_done:
    pop r9; pop rsi; pop rdi; pop rdx; pop rcx; pop rbx
    ret

; --- Utility and Helper Functions ---

;--------------------------------------------------------------------------
; get_current_time_ms() -> rax (current time in milliseconds)
;--------------------------------------------------------------------------
get_current_time_ms:
    push rdi; push rsi; push rbx; push rcx; push rdx
    mov rax, SYS_GETTIMEOFDAY
    lea rdi, [timeval_struct]
    mov rsi, 0
    syscall
    mov rax, [timeval_struct]
    mov rdx, [timeval_struct+8]
    mov rbx, 1000
    mul rbx
    mov rcx, rax
    mov rax, rdx
    xor rdx, rdx
    div rbx
    add rax, rcx
    pop rdx; pop rcx; pop rbx; pop rsi; pop rdi
    ret

;--------------------------------------------------------------------------
; strcmp(rdi: str1, rsi: str2) -> rax (0 if equal)
;--------------------------------------------------------------------------
strcmp:
    push rsi; push rdi
.loop:
    mov al, [rdi]; mov bl, [rsi]; cmp al, bl; jne .notequal
    test al, al; jz .equal; inc rdi; inc rsi; jmp .loop
.notequal:
    mov rax, 1; jmp .done
.equal:
    xor rax, rax
.done:
    pop rdi; pop rsi; ret

;--------------------------------------------------------------------------
; parse_token() -> rax (pointer to next token or 0)
;--------------------------------------------------------------------------
parse_token:
    mov rsi, [token_pointer]
    cmp rsi, 0; jne .start_parse
    mov rsi, uci_input_buffer
.start_parse:
.skip_whitespace:
    mov al, [rsi]; test al, al; jz .no_more_tokens
    cmp al, ' '; je .is_whitespace
    cmp al, 10; je .is_whitespace
    cmp al, 13; je .is_whitespace
    jmp .found_token_start
.is_whitespace:
    inc rsi; jmp .skip_whitespace
.found_token_start:
    mov rax, rsi
.find_token_end:
    inc rsi; mov al, [rsi]; test al, al; jz .end_of_string
    cmp al, ' '; je .end_found
    cmp al, 10; je .end_found
    cmp al, 13; je .end_found
    jmp .find_token_end
.end_found:
    mov byte [rsi], 0; inc rsi; mov [token_pointer], rsi; ret
.end_of_string:
    mov [token_pointer], rsi; ret
.no_more_tokens:
    xor rax, rax; ret

;--------------------------------------------------------------------------
; parse_int(rdi: string) -> rax (integer value)
;--------------------------------------------------------------------------
parse_int:
    xor rax, rax
.loop:
    movzx rcx, byte [rdi]; cmp rcx, '0'; jl .done; cmp rcx, '9'; jg .done
    sub rcx, '0'; imul rax, 10; add rax, rcx; inc rdi; jmp .loop
.done:
    ret

;--------------------------------------------------------------------------
; print_string(rsi: string) -> void
;--------------------------------------------------------------------------
print_string:
    push rax; push rdi; push rsi; push rdx; push rcx
    mov rdi, rsi; xor rax, rax; mov rcx, -1; repne scasb
    not rcx; dec rcx; mov rdx, rcx
    mov rax, 1; mov rdi, 1; syscall
    pop rcx; pop rdx; pop rsi; pop rdi; pop rax; ret

;--------------------------------------------------------------------------
; parse_uci_move(rdi: string) -> rax (4-byte packed move)
;--------------------------------------------------------------------------
parse_uci_move:
    push rbx; push rcx; push rdx
    movzx rax, byte [rdi]; sub rax, 'a'
    movzx rbx, byte [rdi+1]; sub rbx, '1'
    imul rbx, 8; add rax, rbx
    movzx rcx, byte [rdi+2]; sub rcx, 'a'
    movzx rdx, byte [rdi+3]; sub rdx, '1'
    imul rdx, 8; add rcx, rdx
    shl rcx, 8; or rax, rcx
    movzx rbx, byte [rdi+4]; test rbx, rbx; jz .done
    mov rcx, [side_to_move]; test rcx, rcx; jnz .black_promo
.white_promo:
    cmp bl, 'q'; je .set_promo_q; cmp bl, 'r'; je .set_promo_r
    cmp bl, 'b'; je .set_promo_b; cmp bl, 'n'; je .set_promo_n
    jmp .done
.set_promo_q: mov rdx, W_QUEEN; jmp .promo
.set_promo_r: mov rdx, W_ROOK; jmp .promo
.set_promo_b: mov rdx, W_BISHOP; jmp .promo
.set_promo_n: mov rdx, W_KNIGHT; jmp .promo
.black_promo:
    cmp bl, 'q'; je .set_promo_bq; cmp bl, 'r'; je .set_promo_br
    cmp bl, 'b'; je .set_promo_bb; cmp bl, 'n'; je .set_promo_bn
    jmp .done
.set_promo_bq: mov rdx, B_QUEEN; jmp .promo
.set_promo_br: mov rdx, B_ROOK; jmp .promo
.set_promo_bb: mov rdx, B_BISHOP; jmp .promo
.set_promo_bn: mov rdx, B_KNIGHT; jmp .promo
.promo:
    shl rdx, 16; or rax, rdx
.done:
    pop rdx; pop rcx; pop rbx; ret

; --- Spinlock, Futex, and other system-level functions ---
; (The rest of the functions from your file go here)

search_root:
    push r12; push r13; push r14; push r15
    mov r12d, esi             ; r12d = alpha
    mov r13d, edx             ; r13d = beta
    mov r15, rdi              ; r15 = depth
    mov dword [root_best_move], 0
    mov qword [nodes_searched], 0
    call generate_moves
    call score_moves
    mov r11, 0                ; move_index
    mov r9d, -30001           ; best_score
.move_loop:
    mov r10, [move_list_end]; sub r10, move_list; shr r10, 2; cmp r11, r10
    jge .done_searching
    call find_next_best_move
    mov r10, rax ; find_next_best_move returns the move data now, not an index
    call make_move
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    call is_king_in_check
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    test al, al
    jnz .illegal_root_move
    mov rdi, r15; dec rdi
    mov esi, r13d; neg esi
    mov edx, r12d; neg edx
    call negamax
    neg eax
    call unmake_move
    cmp eax, r12d
    jle .next_move_in_loop
    mov r12d, eax
    mov r9d, eax
    movzx ecx, byte[r10]
    movzx edx, byte[r10+1]
    mov ch, dl
    mov cl, cl
    mov [root_best_move], cx
    jmp .next_move_in_loop
.illegal_root_move:
    call unmake_move
.next_move_in_loop:
    inc r11
    jmp .move_loop
.done_searching:
    mov eax, r9d
    pop r15; pop r14; pop r13; pop r12
    ret

; Helper: find_piece(rdi: piece_code) -> rax (square or -1)
find_piece:
    push rcx
    mov rcx, 0
.find_piece_loop:
    cmp rcx, 64
    jge .find_piece_not_found
    cmp byte [board+rcx], dil
    je .find_piece_found
    inc rcx
    jmp .find_piece_loop
.find_piece_found:
    mov rax, rcx; jmp .find_piece_done
.find_piece_not_found:
    mov rax, -1
.find_piece_done:
    pop rcx
    ret

; Checks if a file is completely free of pawns.
is_file_open:
    push rbx
    push rcx
    mov rcx, 0
.loop:
    cmp rcx, 8 ; Loop through all 8 ranks
    jge .is_open ; If loop finishes, file is open

    ; square_index = file + rank * 8
    mov rbx, rcx
    imul rbx, 8
    add rbx, rdi

    movzx rax, byte [board + rbx]
    and rax, PIECE_MASK
    cmp rax, W_PAWN
    je .not_open ; Found a pawn, file is not open

    inc rcx
    jmp .loop

.is_open:
    mov rax, 1
    jmp .done
.not_open:
    xor rax, rax
.done:
    pop rcx
    pop rbx
    ret

; Checks if a pawn at 'square' of 'color' is a passed pawn.
is_passed:
    push rbx; push rcx; push rdx; push r8; push r9

    mov r8, rdi ; r8 = pawn_square
    mov r9, rsi ; r9 = pawn_color

    ; Get file of the pawn
    mov rax, r8
    xor rdx, rdx
    mov rbx, 8
    div rbx
    mov rbx, rdx ; rbx = pawn_file

    cmp r9, 0 ; Is it a white pawn?
    jne .check_black_pawn

.check_white_pawn:
    ; Check files to the left, center, and right for opposing pawns ahead.
    mov rcx, rbx ; file
    sub rcx, 1   ; start with file-1
.white_loop:
    cmp rcx, rbx
    jg .pawn_is_passed ; Done checking all 3 files
    cmp rcx, 0
    jl .next_white_file
    cmp rcx, 8
    jge .next_white_file

    ; Iterate up the ranks on this file
    mov rdx, r8 ; pawn_square
.white_rank_loop:
    add rdx, 8
    and rdx, 0x3F ; Keep it on the board
    cmp rdx, r8
    je .next_white_file ; Wrapped around, done with this file
    movzx rax, byte [board + rdx]
    cmp al, B_PAWN
    je .pawn_not_passed ; Found an enemy pawn
    cmp al, EMPTY
    jne .white_rank_loop ; Not empty but not a pawn, continue
    jmp .white_rank_loop
.next_white_file:
    inc rcx
    jmp .white_loop

.check_black_pawn:
    ; Mirrored logic for black
    mov rcx, rbx
    sub rcx, 1
.black_loop:
    cmp rcx, rbx
    jg .pawn_is_passed
    cmp rcx, 0
    jl .next_black_file
    cmp rcx, 8
    jge .next_black_file
    mov rdx, r8
.black_rank_loop:
    sub rdx, 8
    and rdx, 0x3F
    cmp rdx, r8
    je .next_black_file
    movzx rax, byte [board + rdx]
    cmp al, W_PAWN
    je .pawn_not_passed
    cmp al, EMPTY
    jne .black_rank_loop
    jmp .black_rank_loop
.next_black_file:
    inc rcx
    jmp .black_loop

.pawn_is_passed:
    mov rax, 1
    jmp .is_passed_done
.pawn_not_passed:
    xor rax, rax
.is_passed_done:
    pop r9; pop r8; pop rdx; pop rcx; pop rbx
    ret

; Adds bonuses for rooks on open files and on the 7th rank.
evaluate_rooks: ; If Ship on 7th sea, Engine give treasure
    push rbx; push rcx; push rdi
    xor rax, rax ; score = 0
    mov rcx, 0   ; square_index
.loop_all_squares:
    cmp rcx, 64
    jge .done

    movzx rbx, byte [board + rcx]
    and rbx, PIECE_MASK
    cmp rbx, W_ROOK
    jne .next_square

    ; Found a rook, get its file and rank
    mov rdi, rcx
    push rax ; Save current score
    mov rax, rcx
    xor rdx, rdx
    mov rbx, 8
    div rbx
    mov rdi, rdx ; rdi = file
    pop rax  ; Restore score

    ; Bonus for open file
    push rax
    call is_file_open
    test al, al
    pop rax
    jz .check_7th_rank
    add rax, 15 ; Add bonus for white rook on open file

.check_7th_rank:
    ; Bonus for 7th rank
    mov rbx, rcx
    and rbx, 0x38 ; Mask to get rank bits
    cmp rbx, 6 * 8 ; Is it on rank 7 (index 6)?
    jne .subtract_for_black
    add rax, 20

.subtract_for_black:
    ; If the piece was black, negate all the bonuses we just calculated
    movzx rbx, byte [board + rcx]
    and rbx, COLOR_MASK
    cmp rbx, 0
    je .next_square 
    neg rax       

.next_square:
    inc rcx
    jmp .loop_all_squares
.done:
    pop rdi; pop rcx; pop rbx
    ret

;--------------------------------------------------------------------------
; probe_tablebase() -> rax (score)
; Returns a score if the position is in the tablebase.
; Return value convention:
;   32000: Win
;  -32000: Loss
;       0: Draw
;   32767: Not found in tablebase
;--------------------------------------------------------------------------
probe_tablebase:
    push rbx; push rcx; push rdx; push rsi; push rdi; push r8; push r9; push r10

    ; --- 1. Identify Position and Find Correct Table ---
    ; For this example, we hard-code the check for KRPvK.
    ; A full implementation would loop through `tablebase_files`.

    ; Count pieces
    mov r8, 0 ; piece_count
    mov r9, 0 ; piece_signature
    mov rcx, 0
.count_loop:
    cmp rcx, 64
    jge .count_done
    movzx rbx, byte [board+rcx]
    cmp rbx, EMPTY
    je .count_next
    inc r8
    bts r9, rbx ; Set bit for this piece type in our signature
.count_next:
    inc rcx
    jmp .count_loop
.count_done:

    cmp r8, 4 ; We only support KRPvK (4 pieces) for now
    jne .not_found

    ; Create the signature for KRPvK
    mov r10, 0
    bts r10, W_KING; bts r10, W_ROOK; bts r10, W_PAWN
    bts r10, B_KING

    cmp r9, r10 ; Does the signature match KRPvK?
    jne .not_found

    ; --- 2. Ensure Table is Memory-Mapped ---
    ; The table we want is the first one in our list
    mov rdi, tablebase_files
    mov rbx, [rdi + tb_file.pointer]
    test rbx, rbx ; Is it already mapped?
    jnz .table_ready

    ; If not, map it
    call mmap_table
    test rax, rax ; Check for error from mmap
    jz .not_found
    mov [rdi + tb_file.pointer], rax
    mov rbx, rax

.table_ready:
    mov [active_tb_pointer], rbx ; Store pointer for the index calculation

    ; --- 3. Calculate Syzygy Index ---
    call calculate_krpvk_index
    test rax, rax
    js .not_found ; Negative index means error

    ; --- 4. Probe the Table ---
    mov rbx, [active_tb_pointer]
    mov rcx, rax ; rcx = index
    shr rax, 2   ; index / 4 to get the byte index
    add rbx, rax ; rbx = pointer to the correct byte in the file

    and rcx, 3   ; index % 4 to get the pair index within the byte
    shl rcx, 1   ; * 2 to get the bit index

    movzx rax, byte [rbx] ; Read the byte with 4 WDL values
    shr ax, cl   ; Shift the value we want to the low bits
    and rax, 3   ; Mask to get only our 2 bits

    ; --- 5. Convert WDL value to Score ---
    ; WDL bits: 0=LL, 1=DL, 2=DW, 3=WW
    ; We map this to: Loss, Draw, Draw, Win
    cmp rax, 3
    je .is_a_win
    cmp rax, 0
    je .is_a_loss
    ; It's a draw
    xor rax, rax
    jmp .exit
.is_a_win:
    mov rax, 32000
    jmp .exit
.is_a_loss:
    mov rax, -32000
    jmp .exit

.not_found:
    mov rax, 32767 ; Special value for "not found"

;--------------------------------------------------------------------------
; mmap_table(rdi: pointer to tb_file struct) -> rax (pointer or 0 on error)
; Opens and memory-maps a tablebase file.
;--------------------------------------------------------------------------
mmap_table:
    push rbx; push rcx; push rdx; push rsi;
    mov r8, rdi ; Save struct pointer

    ; --- sys_open ---
    mov rax, SYS_OPEN
    mov rdi, [r8 + tb_file.filename]
    mov rsi, O_RDONLY
    xor rdx, rdx
    syscall
    cmp rax, 0
    jl .mmap_error ; Error if fd < 0

    mov r9, rax ; r9 = file descriptor

    ; --- For simplicity, we assume a max size. A full implementation
    ; --- would use fstat to get the exact file size.
    mov r10, 1024 * 1024 ; Map up to 1MB

    ; --- sys_mmap ---
    mov rax, SYS_MMAP
    xor rdi, rdi              ; addr = 0 (let kernel choose)
    mov rsi, r10              ; len
    mov rdx, PROT_READ        ; prot
    mov r10, MAP_PRIVATE      ; flags
    mov r8, r9                ; fd
    xor r9, r9                ; offset = 0
    syscall

    mov r11, rax ; Save mmap pointer

    ; --- sys_close ---
    mov rax, SYS_CLOSE
    mov rdi, r8 ; fd is in r8 now
    syscall

    mov rax, r11 ; Return the pointer from mmap
    jmp .mmap_done

.mmap_error:
    xor rax, rax ; Return 0 on error

.mmap_done:
    pop rsi; pop rdx; pop rcx; pop rbx
    ret

;--------------------------------------------------------------------------
; calculate_krpvk_index() -> rax (index)
; Calculates the specific index for a KRPvK position.
;--------------------------------------------------------------------------
calculate_krpvk_index:
    push rbx; push rcx; push rdx; push rdi; push r8; push r9

    ; --- Find piece locations ---
    mov r8, 0 ; Loop counter
    xor r9, r9 ; Store piece locations here
.find_loop:
    cmp r8, 64; jge .find_done
    movzx rbx, byte [board+r8]
    cmp rbx, EMPTY; je .find_next
    ; Store location: shift left by 8, then add new location
    shl r9, 8; or r9b, r8b
.find_next:
    inc r8; jmp .find_loop
.find_done:

    ; r9 now contains piece locations packed into bytes. Unpack them.
    mov rdi, r9; shr rdi, 24; and rdi, 0xFF ; White King square
    mov rsi, r9; shr rsi, 16; and rsi, 0xFF ; White Rook square
    mov rdx, r9; shr rdx, 8; and rdx, 0xFF  ; White Pawn square
    mov rcx, r9; and rcx, 0xFF              ; Black King square

    ; --- Pawns on rank 1 or 8 are impossible, they are promotions
    mov rax, rdx
    and rax, 0x38 ; Mask rank bits
    cmp rax, 0; je .index_error
    cmp rax, 7 * 8; je .index_error

    ; --- Map pawn square to its index (ranks 2-7 -> 0-5)
    mov rax, rdx; shr rax, 3; dec rax; mov rbx, 8; mul rbx; mov rbx, rax
    mov rax, rdx; and rax, 7; add rbx, rax; mov rdx, rbx ; rdx = pawn_idx (0-47)

    ; --- Final Index Calculation ---
    ; This formula is specific to the KRPvK table encoding.
    ; index = (((black_king * 64 + white_king) * 64 + rook) * 48 + pawn) * 2 + side
    mov rax, rcx ; black_king
    imul rax, 64
    add rax, rdi ; + white_king
    imul rax, 64
    add rax, rsi ; + rook
    imul rax, 48
    add rax, rdx ; + pawn
    shl rax, 1   ; * 2
    add rax, [side_to_move] ; + side_to_move

    jmp .index_exit
.index_error:
    mov rax, -1 ; Return -1 on error
.index_exit:
    pop r9; pop r8; pop rdi; pop rdx; pop rcx; pop rbx
    ret

.exit:
    pop r10; pop r9; pop r8; pop rdi; pop rsi; pop rdx; pop rcx; pop rbx
    ret

board_to_fen:
    push rbx; push rcx; push rdx; push rsi; push rdi; push r8
    mov rsi, fen_buffer ; rsi = pointer to our output string
    mov r8, 7 ; rank = 7
.rank_loop:
    mov rdx, 0 ; empty_count = 0
    mov rcx, 0 ; file = 0
.file_loop:
    ; square = file + rank * 8
    mov rbx, r8
    imul rbx, 8
    add rbx, rcx
    movzx rdi, byte [board + rbx]
    cmp rdi, EMPTY
    je .is_empty

    ; Found a piece. Write pending empty count if any.
    cmp rdx, 0
    je .write_piece
    add rdx, '0'
    mov [rsi], dl
    inc rsi
    mov rdx, 0
.write_piece:
    ; Get piece character from fen_pieces lookup table
    mov rdi, [fen_pieces + rdi]
    mov [rsi], dil
    inc rsi
    jmp .next_file
.is_empty:
    inc rdx
.next_file:
    inc rcx
    cmp rcx, 8
    jl .file_loop

    ; End of rank, write final empty count if any
    cmp rdx, 0
    je .rank_done
    add rdx, '0'
    mov [rsi], dl
    inc rsi
.rank_done:
    cmp r8, 0
    je .board_done
    mov byte [rsi], '/'
    inc rsi
    dec r8
    jmp .rank_loop

.board_done:
    mov byte [rsi], ' '; inc rsi
    ; Side to move
    mov al, [side_to_move]
    test al, al
    jz .white_to_move
    mov byte [rsi], 'b'; inc rsi; jmp .castling
.white_to_move:
    mov byte [rsi], 'w'; inc rsi

.castling:
    mov byte [rsi], ' '; inc rsi
    mov rbx, [castling_rights]
    mov rcx, 0 ; a flag to see if we wrote any castling char
    test bl, W_OO_RIGHT; jz .check_w_ooo
    mov byte [rsi], 'K'; inc rsi; mov rcx, 1
.check_w_ooo:
    test bl, W_OOO_RIGHT; jz .check_b_oo
    mov byte [rsi], 'Q'; inc rsi; mov rcx, 1
.check_b_oo:
    test bl, B_OO_RIGHT; jz .check_b_ooo
    mov byte [rsi], 'k'; inc rsi; mov rcx, 1
.check_b_ooo:
    test bl, B_OOO_RIGHT; jz .no_castle
    mov byte [rsi], 'q'; inc rsi; mov rcx, 1
.no_castle:
    test rcx, rcx; jnz .ep_square
    mov byte [rsi], '-'; inc rsi

.ep_square:
    mov byte [rsi], ' '; inc rsi
    ; For now, EP, halfmove and fullmove are simplified
    mov rax, qword "- 0 1"
    mov [rsi], rax

    ; We are done. rax should return a pointer to the start of the buffer.
    mov rax, fen_buffer
    pop r8; pop rdi; pop rsi; pop rdx; pop rcx; pop rbx
    ret

; Reads the "book.bin" file into the opening_book buffer.
load_opening_book:
    push rax; push rdi; push rsi; push rdx

    ; sys_open
    mov rax, 2
    mov rdi, opening_book_path
    mov rsi, 0 ; O_RDONLY
    syscall
    cmp rax, 0
    jl .error ; If file descriptor < 0, open failed

    mov rdi, rax ; rdi = file descriptor

    ; sys_read
    mov rax, 0
    mov rsi, opening_book
    mov rdx, 16 * 1024 * 1024 ; Max book size
    syscall
    mov [book_size], rax ; Store actual number of bytes read

    ; sys_close
    mov rax, 3
    ; rdi still holds the file descriptor
    syscall

.error:
    pop rdx; pop rsi; pop rdi; pop rax
    ret


; Searches the loaded book for the current position and returns a weighted-random move.
find_book_move:
    push rbx; push rcx; push rdx; push rsi; push rdi; push r8; push r9; push r10

    call compute_zobrist_hash
    mov r8, [zobrist_hash] ; r8 = our target hash

    mov r9, 0 ; total_weight = 0
    mov r10, move_list ; Use move_list as a temporary buffer for candidate moves

.search_loop:
    mov rsi, opening_book
    add rsi, [book_size] ; rsi = end of book
    mov rdi, opening_book
    add rdi, rcx ; rdi = current entry
    cmp rdi, rsi
    jge .search_done

    mov rbx, [rdi] ; rbx = book entry hash
    cmp rbx, r8
    jne .next_entry

    ; Found a match. Store the move and its weight.
    mov ax, [rdi+8]  ; ax = move data
    mov [r10], ax
    mov ax, [rdi+10] ; ax = weight
    mov [r10+2], ax
    add r9, rax      ; Add to total_weight
    add r10, 4       ; Move to next slot in our temp buffer

.next_entry:
    add rcx, 16
    jmp .search_loop

.search_done:
    cmp r9, 0
    je .no_move_found ; If total_weight is 0, no moves were found

    ; We have moves, now do a weighted choice
    mov rdi, r9 ; rdi = total_weight
    call weighted_choice
    mov rcx, rax ; rcx = chosen random weight

    mov r10, move_list
.selection_loop:
    mov ax, [r10+2] ; ax = current move's weight
    sub rcx, rax
    cmp rcx, 0
    jle .move_selected

    add r10, 4
    jmp .selection_loop

.move_selected:
    mov ax, [r10] ; Found it. Load move into rax.
    jmp .exit

.no_move_found:
    xor rax, rax

.exit:
    pop r10; pop r9; pop r8; pop rdi; pop rsi; pop rdx; pop rcx; pop rbx
    ret

; Helper function to pick a random number up to total_weight.
weighted_choice:
    call lcg_rand ; Get a 64-bit random number in rax
    xor rdx, rdx
    div rdi       ; rax = rax / total_weight, rdx = rax % total_weight
    mov rax, rdx  ; We want the remainder
    ret

compute_zobrist_hash:
    push rax; push rbx; push rcx; push rdi
    xor rax, rax ; This will be our hash
    mov rcx, 0
.hash_loop:
    cmp rcx, 64
    jge .hash_done
    movzx rdi, byte [board+rcx]
    cmp rdi, EMPTY
    je .next_square
    ; Hash piece: piece_keys[square * 12 + piece_type-1]
    mov rbx, rcx
    imul rbx, 12
    add rbx, rdi
    dec rbx ; Piece values are 1-14, array is 0-indexed
    xor rax, [piece_keys + rbx * 8]
.next_square:
    inc rcx
    jmp .hash_loop
.hash_done:
    mov rbx, [side_to_move]
    test rbx, rbx
    jz .white_to_move
    xor rax, [side_key] ; Hash in black to move
.white_to_move:
    movzx rbx, byte [castling_rights]
    xor rax, [castling_keys + rbx * 8]
    movzx rbx, byte [en_passant_square]
    test rbx, rbx
    jz .no_ep_hash
    and rbx, 7 ; Get the file (0-7) of the en passant square
    xor rax, [en_passant_keys + rbx * 8]
    mov [zobrist_hash], rax
    pop rdi; pop rcx; pop rbx; pop rax
    ret
initialize_zobrist_keys:
    mov rdi, zobrist_keys
    mov rcx, 769 
.rand_loop:
    push rcx
    call lcg_rand
    mov [rdi], rax
    add rdi, 8
    pop rcx
    loop .rand_loop
    ret

lcg_rand:
    mov rax, [lcg_seed]
    mov rbx, 6364136223846793005
    mul rbx
    add rax, 1442695040888963407
    mov [lcg_seed], rax
    ret

find_next_best_move:
    push rsi; push rdi; mov ebx, -2000000000; mov rax, -1; mov rcx, 0
.find_loop:
    mov rdi, [move_list_end]; mov rsi, move_list; sub rdi, rsi; shr rdi, 2
    cmp rcx, rdi; jge .find_done; mov edx, [move_scores + rcx*4]; cmp edx, ebx
    jle .find_next; mov ebx, edx; mov rax, rcx
.find_next: inc rcx; jmp .find_loop
.find_done: mov dword [move_scores + rax*4], -2000000000; mov r10, move_list
    lea r10, [r10 + rax*4]; pop rdi; pop rsi; ret

generate_tactical_moves:
    mov rbx, move_list; mov [move_list_end], rbx
    call generate_moves
    ret

generate_moves:
    mov rbx, move_list; mov [move_list_end], rbx; mov r11b, [side_to_move]; mov rcx, 0
.gen_loop:
    cmp rcx, 64; jge .gen_done; movzx rdi, byte [board + rcx]; cmp rdi, EMPTY
    je .next_gen_square; mov rsi, rdi; and rsi, COLOR_MASK; cmp sil, r11b
    jne .next_gen_square; and edi, PIECE_MASK; cmp edi, W_PAWN; je .gen_pawn
    cmp edi, W_KNIGHT; je .gen_knight; cmp edi, W_BISHOP; je .gen_bishop
    cmp edi, W_ROOK; je .gen_rook; cmp edi, W_QUEEN; je .gen_queen
    cmp edi, W_KING; je .gen_king; jmp .next_gen_square
.gen_pawn: call generate_pawn_moves; jmp .next_gen_square
.gen_knight: call generate_knight_moves; jmp .next_gen_square
.gen_bishop: call generate_sliding_moves_bishop; jmp .next_gen_square
.gen_rook: call generate_sliding_moves_rook; jmp .next_gen_square
.gen_queen: call generate_sliding_moves_bishop; call generate_sliding_moves_rook; jmp .next_gen_square
.gen_king: call generate_king_moves; jmp .next_gen_square
.next_gen_square: inc rcx; jmp .gen_loop
.gen_done: ret

generate_pawn_moves:
    push r8; push r9; push r10; push r11; push r12
    mov r8, rcx                 ; from square
    mov al, [side_to_move]
    test al, al; jz .white_pawn

; --- BLACK PAWNS ---
.black_pawn:
    mov r10, r8; sub r10, 8
    cmp r10, 0; jl .black_captures
    cmp byte [board+r10], EMPTY; jne .black_captures
    cmp r10, 8; jge .black_single_push
    ADD_PROMOTION_MOVE r8b, r10b, B_QUEEN; ADD_PROMOTION_MOVE r8b, r10b, B_ROOK
    ADD_PROMOTION_MOVE r8b, r10b, B_BISHOP; ADD_PROMOTION_MOVE r8b, r10b, B_KNIGHT
    jmp .black_captures
.black_single_push:
    ADD_MOVE r8b, r10b
    cmp r8, 48; jl .black_captures; cmp r8, 56; jge .black_captures
    mov r10, r8; sub r10, 16
    cmp byte [board+r10], EMPTY; jne .black_captures
    ADD_MOVE r8b, r10b

.black_captures:
    ; Capture West
    mov r10, r8; sub r10, 9
    cmp r10, 0; jl .black_capture_east
    mov rax, r8; mov rbx, r10; call is_move_on_board; test al, al; jz .black_capture_east
    movzx r11, byte [board+r10]
    cmp r11, EMPTY; je .black_ep_west ; If empty, check for EP
    mov r11b, [board+r10]; and r11b, COLOR_MASK; cmp r11b, 0; jne .black_capture_east
    cmp r10, 8; jge .black_capture_west_no_promo
    ADD_PROMOTION_MOVE r8b, r10b, B_QUEEN; ADD_PROMOTION_MOVE r8b, r10b, B_ROOK
    ADD_PROMOTION_MOVE r8b, r10b, B_BISHOP; ADD_PROMOTION_MOVE r8b, r10b, B_KNIGHT
    jmp .black_capture_east
.black_capture_west_no_promo:
    ADD_MOVE r8b, r10b; jmp .black_capture_east
.black_ep_west:
    movzx r12, byte [en_passant_square]
    cmp r10, r12 ; Is the target square the EP square?
    jne .black_capture_east
    ADD_PROMOTION_MOVE r8b, r10b, 1 ; Add EP move (flag=1)

.black_capture_east:
    mov r10, r8; sub r10, 7
    cmp r10, 0; jl .pawn_done
    mov rax, r8; mov rbx, r10; call is_move_on_board; test al, al; jz .pawn_done
    movzx r11, byte [board+r10]
    cmp r11, EMPTY; je .black_ep_east
    mov r11b, [board+r10]; and r11b, COLOR_MASK; cmp r11b, 0; jne .pawn_done
    cmp r10, 8; jge .black_capture_east_no_promo
    ADD_PROMOTION_MOVE r8b, r10b, B_QUEEN; ADD_PROMOTION_MOVE r8b, r10b, B_ROOK
    ADD_PROMOTION_MOVE r8b, r10b, B_BISHOP; ADD_PROMOTION_MOVE r8b, r10b, B_KNIGHT
    jmp .pawn_done
.black_capture_east_no_promo:
    ADD_MOVE r8b, r10b; jmp .pawn_done
.black_ep_east:
    movzx r12, byte [en_passant_square]
    cmp r10, r12; jne .pawn_done
    ADD_PROMOTION_MOVE r8b, r10b, 1

    jmp .pawn_done

; --- WHITE PAWNS ---
.white_pawn:
    mov r10, r8; add r10, 8
    cmp r10, 64; jge .white_captures
    cmp byte [board+r10], EMPTY; jne .white_captures
    cmp r10, 56; jl .white_single_push
    ADD_PROMOTION_MOVE r8b, r10b, W_QUEEN; ADD_PROMOTION_MOVE r8b, r10b, W_ROOK
    ADD_PROMOTION_MOVE r8b, r10b, W_BISHOP; ADD_PROMOTION_MOVE r8b, r10b, W_KNIGHT
    jmp .white_captures
.white_single_push:
    ADD_MOVE r8b, r10b
    cmp r8, 8; jl .white_captures; cmp r8, 16; jge .white_captures
    mov r10, r8; add r10, 16
    cmp byte [board+r10], EMPTY; jne .white_captures
    ADD_MOVE r8b, r10b

.white_captures:
    ; Capture West
    mov r10, r8; add r10, 7
    cmp r10, 64; jge .white_capture_east
    mov rax, r8; mov rbx, r10; call is_move_on_board; test al, al; jz .white_capture_east
    movzx r11, byte [board+r10]
    cmp r11, EMPTY; je .white_ep_west
    mov r11b, [board+r10]; and r11b, COLOR_MASK; cmp r11b, 8; jne .white_capture_east
    cmp r10, 56; jl .white_capture_west_no_promo
    ADD_PROMOTION_MOVE r8b, r10b, W_QUEEN; ADD_PROMOTION_MOVE r8b, r10b, W_ROOK
    ADD_PROMOTION_MOVE r8b, r10b, W_BISHOP; ADD_PROMOTION_MOVE r8b, r10b, W_KNIGHT
    jmp .white_capture_east
.white_capture_west_no_promo:
    ADD_MOVE r8b, r10b; jmp .white_capture_east
.white_ep_west:
    movzx r12, byte [en_passant_square]
    cmp r10, r12; jne .white_capture_east
    ADD_PROMOTION_MOVE r8b, r10b, 1

.white_capture_east:
    mov r10, r8; add r10, 9
    cmp r10, 64; jge .pawn_done
    mov rax, r8; mov rbx, r10; call is_move_on_board; test al, al; jz .pawn_done
    movzx r11, byte [board+r10]
    cmp r11, EMPTY; je .white_ep_east
    mov r11b, [board+r10]; and r11b, COLOR_MASK; cmp r11b, 8; jne .pawn_done
    cmp r10, 56; jl .white_capture_east_no_promo
    ADD_PROMOTION_MOVE r8b, r10b, W_QUEEN; ADD_PROMOTION_MOVE r8b, r10b, W_ROOK
    ADD_PROMOTION_MOVE r8b, r10b, W_BISHOP; ADD_PROMOTION_MOVE r8b, r10b, W_KNIGHT
    jmp .pawn_done
.white_capture_east_no_promo:
    ADD_MOVE r8b, r10b; jmp .pawn_done
.white_ep_east:
    movzx r12, byte [en_passant_square]
    cmp r10, r12; jne .pawn_done
    ADD_PROMOTION_MOVE r8b, r10b, 1

.pawn_done:
    pop r12; pop r11; pop r10; pop r9; pop r8
    ret

generate_knight_moves:
    mov r8, rcx; mov r9, knight_offsets; mov r12, 8
.knight_loop:
    mov r10, r8; movsx rdx, byte [r9]; add r10, rdx
    cmp r10, 0; jl .next_knight_move; cmp r10, 64; jge .next_knight_move
    mov rax, r8; mov rbx, 8; xor rdx, rdx; div rbx; mov rbx, rdx
    mov rax, r10; mov rdi, 8; xor rdx, rdx; div rdi; mov rdi, rdx
    sub rbx, rdi; cmp rbx, -2; jle .next_knight_move; cmp rbx, 2; jge .next_knight_move
    movzx r11, byte [board+r10]; cmp r11, EMPTY; je .knight_add_move
    mov r11b, [side_to_move]; xor r11b, 8; movzx rax, byte [board+r10]
    and al, COLOR_MASK; cmp al, r11b; jne .next_knight_move
.knight_add_move: ADD_MOVE r8b, r10b
.next_knight_move: inc r9; dec r12; jnz .knight_loop; ret

generate_king_moves:
    mov r8, rcx; mov r9, king_offsets; mov r12, 8
.king_loop:
    mov r10, r8; movsx rdx, byte [r9]; add r10, rdx
    cmp r10, 0; jl .next_king_move; cmp r10, 64; jge .next_king_move
    mov rax, r8; mov rbx, r10; call is_move_on_board; test al, al; jz .next_king_move
    movzx r11, byte [board+r10]; cmp r11, EMPTY; je .king_add_move
    mov r11b, [side_to_move]; xor r11b, 8; movzx rax, byte [board+r10]
    and al, COLOR_MASK; cmp al, r11b; jne .next_king_move
.king_add_move:
    ADD_MOVE r8b, r10b
.next_king_move:
    inc r9; dec r12; jnz .king_loop

    ; Is side to move white?
    mov al, [side_to_move]
    test al, al
    jnz .check_black_castle

    ; Check White Kingside (O-O)
    movzx ebx, byte [castling_rights]
    test bl, W_OO_RIGHT
    jz .check_white_queenside
    cmp byte [board+5], EMPTY ; f1
    jne .check_white_queenside
    cmp byte [board+6], EMPTY ; g1
    jne .check_white_queenside
    ; Check if king is in check
    call is_king_in_check; test al, al; jnz .check_white_queenside
    ; Check if squares are attacked
    mov rdi, 5; mov rsi, 8; call is_square_attacked; test al, al; jnz .check_white_queenside
    mov rdi, 6; mov rsi, 8; call is_square_attacked; test al, al; jnz .check_white_queenside
    ADD_MOVE 4, 6 ; Add e1g1

.check_white_queenside:
    ; Check White Queenside (O-O-O)
    movzx ebx, byte [castling_rights]
    test bl, W_OOO_RIGHT
    jz .done_castle_gen
    cmp byte [board+3], EMPTY ; d1
    jne .done_castle_gen
    cmp byte [board+2], EMPTY ; c1
    jne .done_castle_gen
    cmp byte [board+1], EMPTY ; b1
    jne .done_castle_gen
    call is_king_in_check; test al, al; jnz .done_castle_gen
    mov rdi, 3; mov rsi, 8; call is_square_attacked; test al, al; jnz .done_castle_gen
    mov rdi, 2; mov rsi, 8; call is_square_attacked; test al, al; jnz .done_castle_gen
    ADD_MOVE 4, 2 ; Add e1c1
    jmp .done_castle_gen

.check_black_castle:
    ; Check Black Kingside (O-O)
    movzx ebx, byte [castling_rights]
    test bl, B_OO_RIGHT
    jz .check_black_queenside
    cmp byte [board+61], EMPTY ; f8
    jne .check_black_queenside
    cmp byte [board+62], EMPTY ; g8
    jne .check_black_queenside
    call is_king_in_check; test al, al; jnz .check_black_queenside
    mov rdi, 61; mov rsi, 0; call is_square_attacked; test al, al; jnz .check_black_queenside
    mov rdi, 62; mov rsi, 0; call is_square_attacked; test al, al; jnz .check_black_queenside
    ADD_MOVE 60, 62 ; Add e8g8

.check_black_queenside:
    ; Check Black Queenside (O-O-O)
    movzx ebx, byte [castling_rights]
    test bl, B_OOO_RIGHT
    jz .done_castle_gen
    cmp byte [board+59], EMPTY ; d8
    jne .done_castle_gen
    cmp byte [board+58], EMPTY ; c8
    jne .done_castle_gen
    cmp byte [board+57], EMPTY ; b8
    jne .done_castle_gen
    call is_king_in_check; test al, al; jnz .done_castle_gen
    mov rdi, 59; mov rsi, 0; call is_square_attacked; test al, al; jnz .done_castle_gen
    mov rdi, 58; mov rsi, 0; call is_square_attacked; test al, al; jnz .done_castle_gen
    ADD_MOVE 60, 58 ; Add e8c8

.done_castle_gen:
    ret

generate_sliding_moves_bishop: mov r12, bishop_offsets; mov r13, 4; call generate_sliding_moves; ret
generate_sliding_moves_rook: mov r12, rook_offsets; mov r13, 4; call generate_sliding_moves; ret
generate_sliding_moves:
    push r8; push r9; push r10; push r11; push r12; push r13; mov r9, r12
.dir_loop:
    mov r8, rcx; movsx r10, byte [r9]
.slide_loop:
    add r8, r10; cmp r8, 0; jl .next_dir; cmp r8, 64; jge .next_dir
    movzx rbx, byte [board+r8]; cmp rbx, EMPTY; je .empty_square
    mov r11b, [side_to_move]; xor r11b, 8; movzx rax, byte [board+r8]
    and al, COLOR_MASK; cmp al, r11b; jne .next_dir
    ADD_MOVE cl, r8b; jmp .next_dir
.empty_square: ADD_MOVE cl, r8b; jmp .slide_loop
.next_dir: inc r9; dec r13; jnz .dir_loop
    pop r13; pop r12; pop r11; pop r10; pop r9; pop r8; ret

make_move:
    movzx r8, byte [r10]
    movzx r9, byte [r10+1]
    push r8; push r9

    movzx rax, byte [board+r9]; push rax
    movzx rax, byte [board+r8]; push rax
    mov al, [castling_rights]; push rax
    mov al, [en_passant_square]; push rax

    mov byte [en_passant_square], -1
    movzx ecx, byte [board+r8]
    and ecx, PIECE_MASK
    cmp ecx, W_PAWN
    jne .update_castling_rights
    mov ecx, r9
    sub ecx, r8
    cmp ecx, 16
    je .set_white_ep
    cmp ecx, -16
    je .set_black_ep
    jmp .update_castling_rights
.set_white_ep:
    mov al, r8b; add al, 8; mov [en_passant_square], al; jmp .update_castling_rights
.set_black_ep:
    mov al, r8b; sub al, 8; mov [en_passant_square], al;

.update_castling_rights:
    mov r11b, [castling_rights]
    cmp r8, 4; jne .check_e8; and r11, ~3
.check_e8:
    cmp r8, 60; jne .check_rooks; and r11, ~12
.check_rooks:
    cmp r8, 0; jne .check_h1; and r11, ~2
.check_h1:
    cmp r8, 7; jne .check_a8; and r11, ~1
.check_a8:
    cmp r8, 56; jne .check_h8; and r11, ~8
.check_h8:
    cmp r8, 63; jne .rights_updated; and r11, ~4
.rights_updated:
    mov [castling_rights], r11b

    pop rax
    cmp r9b, al
    jne .normal_capture
    movzx ecx, byte [board+r8]
    and ecx, PIECE_MASK
    cmp ecx, W_PAWN
    jne .normal_capture
    cmp byte [side_to_move], 0
    je .remove_black_pawn
    mov cl, r9b; add cl, 8; mov byte [board+cl], EMPTY; jmp .move_piece
.remove_black_pawn:
    mov cl, r9b; sub cl, 8; mov byte [board+cl], EMPTY; jmp .move_piece
.normal_capture:

.move_piece:
    mov cl, byte [board+r8]
    mov byte [board+r9], cl
    mov byte [board+r8], EMPTY

    movzx rax, byte [r10+3]; test rax, rax; jz .check_promotion
    cmp r9, 6; je .move_h1_rook; cmp r9, 2; je .move_a1_rook
    cmp r9, 62; je .move_h8_rook; cmp r9, 58; je .move_a8_rook
    jmp .check_promotion
.move_h1_rook: mov cl, [board+7]; mov [board+5], cl; mov byte [board+7], EMPTY; jmp .check_promotion
.move_a1_rook: mov cl, [board+0]; mov [board+3], cl; mov byte [board+0], EMPTY; jmp .check_promotion
.move_h8_rook: mov cl, [board+63]; mov [board+61], cl; mov byte [board+63], EMPTY; jmp .check_promotion
.move_a8_rook: mov cl, [board+56]; mov [board+59], cl; mov byte [board+56], EMPTY;

.check_promotion:
    movzx rax, byte [r10+2]; test rax, rax; jz .no_promotion
    mov byte [board+r9], al

.no_promotion:
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    ret

unmake_move:
    movzx r8, byte [r10]
    movzx r9, byte [r10+1]

    pop rax; mov [en_passant_square], al
    pop rax; mov [castling_rights], al

    mov cl, byte [board+r9]
    mov [r8], cl
    mov byte [board+r9], EMPTY

    pop rax
    pop rax

    cmp al, EMPTY
    jne .restore_normal_capture
    mov cl, [r8]
    and cl, PIECE_MASK
    cmp cl, W_PAWN
    jne .restore_normal_capture
    mov cl, r8b
    and cl, 0x38
    cmp cl, 0x20
    je .maybe_ep_unmake
    cmp cl, 0x18
    jne .restore_normal_capture
.maybe_ep_unmake:
    cmp byte [side_to_move], 8
    je .restore_black_pawn
    mov byte [board+r9-8], W_PAWN
    jmp .unmake_castling
.restore_black_pawn:
    mov byte [board+r9+8], B_PAWN
    jmp .unmake_castling
.restore_normal_capture:
    mov [r9], al

.unmake_castling:
    movzx rax, byte [r10+3]; test rax, rax; jz .unmake_done
    cmp r9, 6; je .unmove_h1_rook; cmp r9, 2; je .unmove_a1_rook
    cmp r9, 62; je .unmove_h8_rook; cmp r9, 58; je .unmove_a8_rook
    jmp .unmake_done
.unmove_h1_rook: mov cl, [board+5]; mov [board+7], cl; mov byte [board+5], EMPTY; jmp .unmake_done
.unmove_a1_rook: mov cl, [board+3]; mov [board+0], cl; mov byte [board+3], EMPTY; jmp .unmake_done
.unmove_h8_rook: mov cl, [board+61]; mov [board+63], cl; mov byte [board+61], EMPTY; jmp .unmake_done
.unmove_a8_rook: mov cl, [board+59]; mov [board+56], cl; mov byte [board+59], EMPTY;

.unmake_done:
    mov al, [side_to_move]; xor al, 8; mov [side_to_move], al
    pop r9; pop r8
    ret
print_best_move:
    push rax; push rdi; push rsi; push rdx
    mov rax, 1; mov rdi, 1; mov rsi, bestmove_msg; mov rdx, len_bestmove_msg; syscall
    movzx rbx, word [root_best_move]
    movzx rcx, bl; shl rcx, 1; mov rsi, square_to_an; add rsi, rcx
    mov rax, 1; mov rdi, 1; mov rdx, 2; syscall
    movzx rcx, bh; shl rcx, 1; mov rsi, square_to_an; add rsi, rcx
    mov rax, 1; mov rdi, 1; mov rdx, 2; syscall
    mov rax, 1; mov rdi, 1; mov rsi, newline; mov rdx, 1; syscall
    pop rdx; pop rsi; pop rdi; pop rax; ret

initialize_board:
    mov rsi, initial_board; mov rdi, board; mov rcx, 64; rep movsb
    mov byte [side_to_move], 0
    mov byte [castling_rights], W_OO_RIGHT | W_OOO_RIGHT | B_OO_RIGHT | B_OOO_RIGHT
    mov byte [en_passant_square], 0 ; 0 means no en passant square
    ret
