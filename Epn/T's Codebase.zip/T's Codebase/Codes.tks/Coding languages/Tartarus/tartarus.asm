; ==============================================================================
; TARTARUS - The Event Horizon
; Architecture: x86_64 Linux
; Authored by: Tsukishiro Renji
; ==============================================================================

section .data
    ; --- SYNTAX & CIPHER ---
    diamond_marker  db 0xE2, 0x99, 0xA2
    ; Map: 0=Left, 1=Right, 2=Bet(Inc), 3=Fold(Dec), 4=Out, 5=In, 6=Jump, 7=PANIC
    ; We scramble the table so finding a valid command is hard.
    cipher_table    db "7....2.0..1..4..3..5..6...................................", 0
    
    ; --- FILE PATHS ---
    path_temp       db "/sys/class/thermal/thermal_zone0/temp", 0
    path_tumor      db "TUMOR.blob", 0
    
    ; --- ERROR MESSAGES (Hidden in Registers) ---
    err_rax         dq 0x203A524F52524553 ; "SERROR :"
    err_rbx         dq 0x524F525245205841 ; "AX ERROR"
    err_rcx         dq 0x444945204E4F5721 ; "!WON EID"

section .bss
    ; --- BUFFERS ---
    file_buf        resb 1048576    ; 1MB Source Buffer
    code_buf        resb 1048576    ; 1MB Extracted Executable Code (Post-Diamond)
    temp_buf        resb 16         ; Temperature reading buffer
    
    ; --- POINTERS ---
    mem_base        resq 1          ; Base of the 1GB Memory Void
    data_ptr        resq 1          ; Current Cell Pointer
    inst_ptr        resq 1          ; Instruction Pointer (Index in code_buf)
    code_len        resq 1          ; Length of valid code extracted
    
    ; --- STATE ---
    parser_state    resb 1          ; 0=Comment, 1=Code
    prev_char       resb 1          ; For Enigma Decoding
    rng_seed        resq 1          ; D20 Seed
    cycle_count     resq 1          ; For Taxman
    fever_mode      resb 1          ; 0=Normal, 1=Inverted Logic
    
    ; --- BABEL I/O ---
    babel_val       resd 1
    babel_bits      resb 1
    last_time       resq 2
    curr_time       resq 2

section .text
    global _start

; ==============================================================================
; ENTRY POINT
; ==============================================================================
_start:
    ; 1. Initialize Seed (using RDTSC)
    rdtsc
    shl rdx, 32
    or rax, rdx
    mov [rng_seed], rax

    ; 2. PROOF OF WORK (Stall execution immediately)
    call proof_of_work

    ; 3. LOAD FILE (Standard Linux Syscalls)
    pop rax                 ; Argc
    cmp rax, 2
    jl .die_silent
    pop rax                 ; Exec Name
    pop rdi                 ; Filename
    
    mov rax, 2              ; sys_open
    mov rsi, 0              ; O_RDONLY
    mov rdx, 0
    syscall
    cmp rax, 0
    jl .die_silent
    mov r8, rax             ; FD

    mov rax, 0              ; sys_read
    mov rdi, r8
    mov rsi, file_buf
    mov rdx, 1048576
    syscall
    push rax                ; Save file length
    
    mov rax, 3              ; sys_close
    mov rdi, r8
    syscall
    
    pop r15                 ; R15 = Raw File Length

    ; 4. ALLOCATE THE VOID (1GB RAM)
    mov rax, 9              ; sys_mmap
    mov rdi, 0
    mov rsi, 1073741824
    mov rdx, 3              ; RW
    mov r10, 34             ; Private+Anon
    mov r8, -1
    mov r9, 0
    syscall
    cmp rax, 0
    jl .die_silent
    mov [mem_base], rax
    mov [data_ptr], rax

    ; 5. EXTRACT CODE FROM DIAMOND CAGES
    ; We pre-process to handle Retrograde flow easily later
    call extract_diamonds

    ; ==========================================================================
    ; THE EXECUTION LOOP
    ; ==========================================================================
    mov qword [inst_ptr], 0
    mov qword [cycle_count], 0

interpreter_loop:
    mov rcx, [inst_ptr]
    cmp rcx, [code_len]
    jge .shutdown

    ; --- 1. THE TAXMAN (Resource Decay) ---
    call invoke_taxman

    ; --- 2. THE FEVER (Thermal Check) ---
    ; Only check every 100 cycles to save IO, or every time for pain?
    ; Let's do every time. Pain is the goal.
    call check_fever

    ; --- 3. FETCH & DECODE ---
    mov rsi, code_buf
    add rsi, [inst_ptr]     ; RSI points to current instruction char
    
    call decode_enigma      ; Returns Opcode in RAX
    
    ; --- 4. EXECUTE ---
    call execute_opcode     ; Handles D20, Retrograde, etc.

    ; --- 5. UPDATE POINTER (Retrograde Logic) ---
    ; If Opcode (RAX) was odd: Backwards. Even: Forwards.
    test rax, 1
    jz .flow_forward

.flow_backward:
    dec qword [inst_ptr]
    cmp qword [inst_ptr], 0
    jge interpreter_loop
    mov qword [inst_ptr], 0 ; Clamp at 0 (or wrap?)
    jmp interpreter_loop

.flow_forward:
    inc qword [inst_ptr]
    jmp interpreter_loop

.shutdown:
    mov rax, 60
    xor rdi, rdi
    syscall

.die_silent:
    mov rax, 60
    mov rdi, 1
    syscall

; ==============================================================================
; EXTRACTION LOGIC (The Diamond Parser)
; ==============================================================================
extract_diamonds:
    mov rsi, file_buf
    mov rdi, code_buf
    xor rcx, rcx            ; Input Index
    xor rdx, rdx            ; Output Index
    mov byte [parser_state], 0

.ext_loop:
    cmp rcx, r15            ; Compare with file len
    jge .ext_done

    ; Check Diamond
    mov al, [rsi + rcx]
    cmp al, 0xE2
    jne .check_state
    cmp byte [rsi + rcx + 1], 0x99
    jne .check_state
    cmp byte [rsi + rcx + 2], 0xA2
    jne .check_state

    ; Toggle State
    xor byte [parser_state], 1
    add rcx, 3
    jmp .ext_loop

.check_state:
    cmp byte [parser_state], 1
    jne .skip_byte
    
    ; Copy Byte
    mov al, [rsi + rcx]
    mov [rdi + rdx], al
    inc rdx

.skip_byte:
    inc rcx
    jmp .ext_loop

.ext_done:
    mov [code_len], rdx
    ret

; ==============================================================================
; CORE MECHANICS
; ==============================================================================

; --- PROOF OF WORK ---
; Forces CPU to spin for a specific hash ending in 0000 (approx 0.5s)
proof_of_work:
    push rax
    push rbx
    xor rbx, rbx
.mine:
    inc rbx
    mov rax, rbx
    imul rax, 0x5DEECE66D ; LCG Multiplier
    xor rax, [rng_seed]
    test rax, 0xFFFFF     ; Difficulty Mask (Higher = Slower)
    jnz .mine
    pop rbx
    pop rax
    ret

; --- CHECK FEVER ---
; Reads thermal zone. If > 50C, set fever_mode = 1 (Inverts Logic)
check_fever:
    push rax
    push rdi
    push rsi
    push rdx
    
    mov rax, 2              ; open
    mov rdi, path_temp
    mov rsi, 0
    syscall
    cmp rax, 0
    jl .assume_hot
    push rax                ; Save FD

    mov rdi, rax
    mov rax, 0              ; read
    mov rsi, temp_buf
    mov rdx, 5
    syscall
    
    mov rax, 3              ; close
    pop rdi
    syscall

    ; Parse ASCII (Simple check: is first digit '5','6','7','8','9'?)
    ; e.g., "51000"
    cmp byte [temp_buf], '5'
    jge .set_fever
    mov byte [fever_mode], 0
    jmp .fever_done

.set_fever:
    mov byte [fever_mode], 1
    jmp .fever_done

.assume_hot:
    mov byte [fever_mode], 1

.fever_done:
    pop rdx
    pop rsi
    pop rdi
    pop rax
    ret

; --- INVOKE TAXMAN ---
; Every 1000 cycles, decrement current cell value
invoke_taxman:
    inc qword [cycle_count]
    cmp qword [cycle_count], 1000
    jl .tax_safe
    
    mov qword [cycle_count], 0
    ; Tax the current pointer
    mov rbx, [data_ptr]
    dec byte [rbx]          ; Steal 1 byte
    ; If 0? We could unmap, but simpler: leave it at -1 (255) to mess up math

.tax_safe:
    ret

; --- SPAWN TUMOR ---
; Creates a 1GB file on disk. Called on Panic.
spawn_tumor:
    mov rax, 2              ; open
    mov rdi, path_tumor
    mov rsi, 65             ; CREAT|WRONLY
    mov rdx, 420
    syscall
    cmp rax, 0
    jl .tumor_fail
    mov rdi, rax

    mov rax, 285            ; fallocate
    mov rsi, 0
    mov rdx, 0
    mov r10, 1073741824     ; 1GB
    syscall
    
    mov rax, 3              ; close
    syscall
.tumor_fail:
    ret

; --- ROLL D20 ---
; Returns RAX (1-20). Modified by Fever.
roll_d20:
    rdtsc
    xor rax, [rng_seed]
    mov [rng_seed], rax
    
    ; Modulo 20
    xor rdx, rdx
    mov rbx, 20
    div rbx
    inc rdx         ; 1-20
    mov rax, rdx
    
    ; Fever Logic: If Fever active, invert roll (1->20, 20->1)
    cmp byte [fever_mode], 1
    jne .roll_done
    
    mov rbx, 21
    sub rbx, rax
    mov rax, rbx

.roll_done:
    ret

; ==============================================================================
; DECODER & LOGIC
; ==============================================================================
decode_enigma:
    ; Input: [inst_ptr]
    ; Logic: (Char + Index + Prev) % 94 -> Table lookup
    movzx rax, byte [rsi]   ; Current Char
    movzx rbx, byte [prev_char]
    add rax, rbx
    add rax, [inst_ptr]
    
    xor rdx, rdx
    mov rbx, 94
    div rbx
    
    ; Lookup
    movzx rax, byte [cipher_table + rdx]
    sub rax, '0'            ; Convert ASCII to int
    
    ; Save Prev
    mov bl, [rsi]
    mov [prev_char], bl
    ret

execute_opcode:
    ; RAX = Opcode (0-7)
    cmp rax, 0
    je .do_left
    cmp rax, 1
    je .do_right
    cmp rax, 2
    je .do_bet      ; Increment (Gambling)
    cmp rax, 3
    je .do_fold     ; Decrement (Gambling)
    cmp rax, 4
    je .do_out
    cmp rax, 7
    je .do_panic
    ret

.do_left:
    dec qword [data_ptr]
    ret
.do_right:
    inc qword [data_ptr]
    ret

.do_bet:
    ; D20 Gambling Logic
    call roll_d20
    cmp rax, 1
    je .do_panic    ; Nat 1 = Death
    cmp rax, 11
    jge .bet_win
    ; Else Lose (Decrement)
    call schrodinger_load
    dec byte [rbx]
    ret
.bet_win:
    call schrodinger_load
    inc byte [rbx]
    ret

.do_fold:
    call schrodinger_load
    dec byte [rbx]
    ret

.do_out:
    call schrodinger_load
    movzx rcx, byte [rbx]
    call push_babel
    ret

.do_panic:
    call spawn_tumor        ; Punish Disk
    call trigger_schrodinger_error
    ret

; --- SCHRÖDINGER LOAD ---
; Loads address into RBX and mutates the value
schrodinger_load:
    mov rbx, [data_ptr]
    rdtsc
    test al, 1
    jz .s_even
    not byte [rbx]
    ret
.s_even:
    rol byte [rbx], 1
    ret

; --- TRIGGER ERROR ---
trigger_schrodinger_error:
    mov rax, [err_rax]
    mov rbx, [err_rbx]
    mov rcx, [err_rcx]
    mov rdx, 0
    mov [rdx], rax          ; SEGFAULT with Message in Registers
    ret                     ; (Never reached)

; --- PUSH BABEL ---
push_babel:
    ; Input: CL = 2 bits
    ; Add Decay logic here if desired (check time delta)
    and cl, 3
    shl dword [babel_val], 2
    or byte [babel_val], cl
    
    inc byte [babel_bits]
    cmp byte [babel_bits], 16
    jl .babel_ret
    
    ; Flush
    mov rax, 1
    mov rdi, 1
    lea rsi, [babel_val]
    mov rdx, 4
    syscall
    mov dword [babel_val], 0
    mov byte [babel_bits], 0
.babel_ret:
    ret