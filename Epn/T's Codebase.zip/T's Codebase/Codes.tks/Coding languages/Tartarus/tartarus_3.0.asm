; ==============================================================================
; TARTARUS - The Abyss Gazes Also 
; Architecture: x86_64 Linux
; V: 3.0.8664
; ==============================================================================

section .data
    diamond_marker  db 0xE2, 0x99, 0xA2
    cipher_table    db "7....2.0..1..4..3..5..6..................................."
    path_temp       db "/sys/class/thermal/thermal_zone0/temp", 0
    path_tumor      db "TUMOR.blob", 0
    path_null       db "/dev/null", 0
    path_log        db "SINGULARITY.log", 0
    path_memoir     db "TARTARUS_MEMOIR.txt", 0
    err_rax         dq 0x203A524F52524553
    err_rbx         dq 0x524F525245205841
    err_rcx         dq 0x444945204E4F5721
    sudo_msg        db 27, "[1;31m[sudo] password for user: ********", 10
                    db "rm: cannot remove '/': Is a directory", 10
                    db "rm: cannot remove '/boot': Permission denied", 10
                    db "rm: cannot remove '/etc': Device or resource busy", 10
                    db "rm: cannot remove '/home/user': Operation not permitted", 10
                    db 27, "[0m", 0
    msg_len         equ $ - sudo_msg - 1

section .bss
    file_buf          resb 1048576
    code_buf          resb 1048576
    temp_buf          resb 16
    mem_base          resq 1
    data_ptr_main     resq 1
    data_ptr_shadow   resq 1
    data_ptr_ghost    resq 1
    inst_ptr_present  resq 1
    inst_ptr_past     resq 1
    inst_ptr_future   resq 1
    code_len          resq 1
    parser_state      resb 1
    prev_char         resb 1
    rng_seed          resq 1
    cycle_count       resq 1
    fever_mode        resb 1
    babel_val         resd 1
    babel_bits        resb 1
    last_time         resq 2
    curr_time         resq 2
    echo_buffer       resb 1048576
    echo_prob         resb 1048576
    log_fd            resq 1
    log_entry         resb 24
    expansion_counter resq 1
    proc_path         resb 32
    input_buffer      resb 1
    tax_fib_prev      resq 1
    tax_fib_curr      resq 1
    momentum_left     resq 1
    momentum_right    resq 1
    cell_ghost        resb 1048576
    history_buffer    resb 10000
    history_index     resq 1
    message_cycles    resq 1
    message_triggered resb 1
    memoir_fd         resq 1
    log_buffer        resb 128
    committee_votes   resb 16
    enc_key           resq 1

section .text
    global _start

_start:
    rdtsc
    shl rdx, 32
    or rax, rdx
    mov [rng_seed], rax
    mov qword [tax_fib_prev], 0
    mov qword [tax_fib_curr], 1
    call proof_of_work
    pop rax
    cmp rax, 2
    jl die_silent
    pop rax
    pop rdi
    mov rax, 2
    mov rsi, 0
    mov rdx, 0
    syscall
    cmp rax, 0
    jl die_silent
    mov r8, rax
    mov rax, 0
    mov rdi, r8
    mov rsi, file_buf
    mov rdx, 1048576
    syscall
    push rax
    mov rax, 3
    mov rdi, r8
    syscall
    pop r15
    mov rax, 9
    mov rdi, 0
    mov rsi, 1073741824
    mov rdx, 3
    mov r10, 34
    mov r8, -1
    mov r9, 0
    syscall
    cmp rax, 0
    jl die_silent
    mov [mem_base], rax
    mov [data_ptr_main], rax
    mov [data_ptr_shadow], rax
    mov [data_ptr_ghost], rax
    mov rax, 2
    mov rdi, path_log
    mov rsi, 66
    mov rdx, 420
    syscall
    mov [log_fd], rax
    call extract_diamonds
    mov qword [inst_ptr_present], 0
    mov qword [inst_ptr_past], -1
    mov qword [inst_ptr_future], 1
    mov qword [cycle_count], 0
    mov qword [tax_fib_prev], 0
    mov qword [tax_fib_curr], 1

interpreter_loop:
    mov rcx, [inst_ptr_present]
    cmp rcx, [code_len]
    jge shutdown
    call darkmatter_expansion
    call fibonacci_tax
    call price_of_computation
    call check_fever
    call time_dilation
    call chorus_execute
    call instruction_echo
    call apply_momentum
    call lottery_ticket
    call archive_and_judge
    call reencrypt_code
    call diplomat
    call biographer
    call simulate_destruction
    call whispers
    mov rsi, code_buf
    add rsi, [inst_ptr_present]
    call decode_enigma
    call crowd_execute
    call witness_log
    call check_haunt
    mov rax, [inst_ptr_present]
    mov [inst_ptr_past], rax
    test rax, 1
    jz flow_forward

flow_backward:
    inc qword [momentum_left]
    dec qword [inst_ptr_present]
    mov rax, [inst_ptr_present]
    sub rax, 1
    mov [inst_ptr_future], rax
    cmp qword [inst_ptr_present], 0
    jge interpreter_loop
    mov qword [inst_ptr_present], 0
    jmp interpreter_loop

flow_forward:
    inc qword [momentum_right]
    inc qword [inst_ptr_present]
    mov rax, [inst_ptr_present]
    add rax, 1
    mov [inst_ptr_future], rax
    jmp interpreter_loop

shutdown:
    mov rax, 60
    xor rdi, rdi
    syscall

die_silent:
    mov rax, 60
    mov rdi, 1
    syscall

extract_diamonds:
    mov rsi, file_buf
    mov rdi, code_buf
    xor rcx, rcx
    xor rdx, rdx
    mov byte [parser_state], 0

ext_loop:
    cmp rcx, r15
    jge ext_done
    mov al, [rsi + rcx]
    cmp al, 0xE2
    jne check_state
    cmp byte [rsi + rcx + 1], 0x99
    jne check_state
    cmp byte [rsi + rcx + 2], 0xA2
    jne check_state
    xor byte [parser_state], 1
    add rcx, 3
    jmp ext_loop

check_state:
    cmp byte [parser_state], 1
    jne skip_byte
    mov al, [rsi + rcx]
    mov [rdi + rdx], al
    inc rdx

skip_byte:
    inc rcx
    jmp ext_loop

ext_done:
    mov [code_len], rdx
    ret

proof_of_work:
    push rax
    push rbx
    xor rbx, rbx
mine:
    inc rbx
    mov rax, rbx
    imul rax, 0x5DEECE66D
    xor rax, [rng_seed]
    test rax, 0xFFFFF
    jnz mine
    pop rbx
    pop rax
    ret

check_fever:
    push rax
    push rdi
    push rsi
    push rdx
    mov rax, 2
    mov rdi, path_temp
    mov rsi, 0
    syscall
    cmp rax, 0
    jl assume_hot
    push rax
    mov rdi, rax
    mov rax, 0
    mov rsi, temp_buf
    mov rdx, 5
    syscall
    mov rax, 3
    pop rdi
    syscall
    cmp byte [temp_buf], 0x35
    jge set_fever
    mov byte [fever_mode], 0
    jmp fever_done

set_fever:
    mov byte [fever_mode], 1
    jmp fever_done

assume_hot:
    mov byte [fever_mode], 1

fever_done:
    pop rdx
    pop rsi
    pop rdi
    pop rax
    ret

fibonacci_tax:
    push rax
    push rbx
    mov rax, [tax_fib_prev]
    mov rbx, [tax_fib_curr]
    add rax, rbx
    mov [tax_fib_prev], rbx
    mov [tax_fib_curr], rax
    mov rcx, [data_ptr_main]
    sub byte [rcx], al
    pop rbx
    pop rax
    ret

spawn_tumor:
    mov rax, 2
    mov rdi, path_tumor
    mov rsi, 65
    mov rdx, 420
    syscall
    cmp rax, 0
    jl tumor_fail
    mov rdi, rax
    mov rax, 285
    mov rsi, 0
    mov rdx, 0
    mov r10, 1073741824
    syscall
    mov rax, 3
    syscall
tumor_fail:
    ret

roll_d20:
    rdtsc
    xor rax, [rng_seed]
    mov [rng_seed], rax
    xor rdx, rdx
    mov rbx, 20
    div rbx
    inc rdx
    mov rax, rdx
    cmp byte [fever_mode], 1
    jne roll_done
    mov rbx, 21
    sub rbx, rax
    mov rax, rbx
roll_done:
    ret

roll_d1000:
    rdtsc
    xor rax, [rng_seed]
    mov [rng_seed], rax
    xor rdx, rdx
    mov rbx, 1000
    div rbx
    inc rdx
    mov rax, rdx
    ret

decode_enigma:
    movzx rax, byte [rsi]
    movzx rbx, byte [prev_char]
    add rax, rbx
    add rax, [inst_ptr_present]
    xor rdx, rdx
    mov rbx, 94
    div rbx
    movzx rax, byte [cipher_table + rdx]
    sub rax, 0x30
    mov bl, [rsi]
    mov [prev_char], bl
    ret

crowd_execute:
    push rax
    push rbx
    push rcx
    cmp rax, 0
    je crowd_left
    cmp rax, 1
    je crowd_right
    cmp rax, 2
    je do_bet
    cmp rax, 3
    je do_fold
    cmp rax, 4
    je do_out
    cmp rax, 5
    je do_inp
    cmp rax, 6
    je do_jmp
    cmp rax, 7
    je do_panic
    jmp crowd_done

crowd_left:
    dec qword [data_ptr_main]
    inc qword [data_ptr_shadow]
    rdtsc
    test al, 1
    jz ghost_left
    inc qword [data_ptr_ghost]
    jmp crowd_resolve
ghost_left:
    dec qword [data_ptr_ghost]
    jmp crowd_resolve

crowd_right:
    inc qword [data_ptr_main]
    dec qword [data_ptr_shadow]
    rdtsc
    test al, 1
    jz ghost_right
    inc qword [data_ptr_ghost]
    jmp crowd_resolve
ghost_right:
    dec qword [data_ptr_ghost]

crowd_resolve:
    mov rbx, [data_ptr_main]
    mov rcx, [rbx]
    mov rbx, [data_ptr_shadow]
    xor rcx, [rbx]
    mov rbx, [data_ptr_ghost]
    xor rcx, [rbx]
    mov rbx, [data_ptr_main]
    mov [rbx], cl
    mov rbx, [data_ptr_shadow]
    mov [rbx], cl
    mov rbx, [data_ptr_ghost]
    mov [rbx], cl
    mov rbx, [data_ptr_main]
    mov al, [inst_ptr_present]
    mov [cell_ghost + rbx], al

crowd_done:
    pop rcx
    pop rbx
    pop rax
    ret

do_bet:
    call roll_d20
    cmp rax, 1
    je do_panic
    cmp rax, 11
    jge bet_win
    call schrodinger_load
    dec byte [rbx]
    ret
bet_win:
    call schrodinger_load
    inc byte [rbx]
    ret

do_fold:
    call schrodinger_load
    dec byte [rbx]
    ret

do_out:
    call schrodinger_load
    movzx rcx, byte [rbx]
    call push_babel
    ret

do_inp:
    push rax
    push rdi
    push rsi
    push rdx
    mov rax, 0
    mov rdi, 0
    mov rsi, input_buffer
    mov rdx, 1
    syscall
    cmp rax, 1
    jne inp_failed
    call schrodinger_load
    mov al, [input_buffer]
    mov [rbx], al
inp_failed:
    pop rdx
    pop rsi
    pop rdi
    pop rax
    ret

do_jmp:
    call schrodinger_load
    movzx rax, byte [rbx]
    test rax, rax
    jz jmp_skip
    movsx rcx, al
    add [inst_ptr_present], rcx
    cmp qword [inst_ptr_present], 0
    jge jmp_check_upper
    mov qword [inst_ptr_present], 0
    jmp jmp_skip
jmp_check_upper:
    mov rax, [inst_ptr_present]
    cmp rax, [code_len]
    jl jmp_skip
    mov rax, [code_len]
    dec rax
    mov [inst_ptr_present], rax
jmp_skip:
    ret

do_panic:
    call spawn_tumor
    call trigger_schrodinger_error
    ret

schrodinger_load:
    mov rbx, [data_ptr_main]
    mov rcx, [rbx]
    and rcx, 0x3FFFFFFF
    mov rdx, [mem_base]
    add rdx, rcx
    mov rbx, rdx
    mov rcx, [data_ptr_main]
    rol qword [rcx], 3
    rdtsc
    test al, 1
    jz s_even
    not byte [rbx]
    ret
s_even:
    rol byte [rbx], 1
    ret

trigger_schrodinger_error:
    mov rax, [err_rax]
    mov rbx, [err_rbx]
    mov rcx, [err_rcx]
    mov rdx, 0
    mov [rdx], rax
    ret

push_babel:
    and cl, 3
    shl dword [babel_val], 2
    or byte [babel_val], cl
    inc byte [babel_bits]
    cmp byte [babel_bits], 16
    jl babel_ret
    mov rax, 1
    mov rdi, 1
    lea rsi, [babel_val]
    mov rdx, 4
    syscall
    mov dword [babel_val], 0
    mov byte [babel_bits], 0
babel_ret:
    ret

darkmatter_expansion:
    inc qword [expansion_counter]
    cmp qword [expansion_counter], 10000
    jl no_expand
    mov rax, 9
    mov rdi, 0
    mov rsi, 1073741824
    mov rdx, 3
    mov r10, 34
    mov r8, -1
    mov r9, 0
    syscall
    mov qword [expansion_counter], 0
no_expand:
    ret

price_of_computation:
    mov rax, 9
    mov rdi, 0
    mov rsi, 4096
    mov rdx, 3
    mov r10, 34
    mov r8, -1
    mov r9, 0
    syscall
    mov rax, 2
    mov rdi, path_null
    mov rsi, 0
    mov rdx, 0
    syscall
    rdtsc
    test al, 1
    jz skip_spin
    call proof_of_work
skip_spin:
    ret

time_dilation:
    mov rbx, [data_ptr_main]
    movzx rax, byte [rbx]
    movzx rcx, word [inst_ptr_present]
    xor rax, rcx
    and rax, 0x7F
    cmp byte [fever_mode], 1
    jne delay_loop
    not rax
    and rax, 0x7F
delay_loop:
    dec rax
    test rax, rax
    jg delay_loop
    ret

chorus_execute:
    mov rax, [inst_ptr_present]
    cmp [inst_ptr_past], rax
    je trigger_schrodinger_error
    cmp [inst_ptr_future], rax
    je trigger_schrodinger_error
    ret

execute_with_echo:
    call execute_opcode
    mov rcx, [inst_ptr_present]
    mov al, [code_buf + rcx]
    mov [echo_buffer + rcx], al
    mov byte [echo_prob + rcx], 0x10
    xor rdx, rdx
    rdtsc
    and al, 0x3F
    cmp al, [echo_prob + rcx]
    jg no_echo
    push qword [inst_ptr_present]
    mov [inst_ptr_present], rcx
    call execute_opcode
    pop qword [inst_ptr_present]
no_echo:
    ret

witness_log:
    push rax
    push rsi
    push rdi
    push rdx
    mov rax, [inst_ptr_present]
    mov [log_entry], rax
    mov rax, [data_ptr_main]
    mov [log_entry + 8], rax
    mov rax, [cycle_count]
    mov [log_entry + 16], rax
    mov rax, 1
    mov rdi, [log_fd]
    mov rsi, log_entry
    mov rdx, 24
    syscall
    pop rdx
    pop rdi
    pop rsi
    pop rax
    ret

whispers:
    push rax
    push rcx
    push rdx
    push rsi
    push rdi
    rdtsc
    and rax, 0x7FFF
    mov rcx, 10
    mov rdi, proc_path
    mov dword [rdi], 0x6F72702F
    mov word [rdi+4], 0x2F63
    add rdi, 6
pid_loop:
    xor rdx, rdx
    div rcx
    add dl, 0x30
    mov [rdi], dl
    inc rdi
    test rax, rax
    jnz pid_loop
    mov dword [rdi], 0x6D656D2F
    mov byte [rdi+4], 0
    mov rax, 2
    mov rdi, proc_path
    mov rsi, 2
    mov rdx, 0
    syscall
    cmp rax, 0
    jl w_done
    mov rdi, rax
    mov rax, 1
    mov rsi, data_ptr_main
    mov rdx, 1
    syscall
    mov rax, 3
    syscall
w_done:
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rax
    ret

instruction_echo:
    push rax
    push rbx
    push rsi
    mov rsi, code_buf
    add rsi, [inst_ptr_present]
    mov al, [rsi]
    mov rbx, [inst_ptr_present]
    inc rbx
    cmp rbx, [code_len]
    jge .no_forward
    rol byte [rsi + 1], 1
.no_forward:
    cmp qword [inst_ptr_present], 0
    je .no_backward
    mov bl, [rsi - 1]
    xor [rsi - 1], al
.no_backward:
    rdtsc
    and rax, 0xFFFFF
    cmp rax, [code_len]
    jae .no_far
    xor byte [code_buf + rax], 0xFF
.no_far:
    pop rsi
    pop rbx
    pop rax
    ret

apply_momentum:
    push rax
    push rcx
    mov rcx, [momentum_left]
    sub [data_ptr_main], rcx
    sub [data_ptr_shadow], rcx
    sub [data_ptr_ghost], rcx
    mov rcx, [momentum_right]
    add [data_ptr_main], rcx
    add [data_ptr_shadow], rcx
    add [data_ptr_ghost], rcx
    shr qword [momentum_left], 1
    shr qword [momentum_right], 1
    pop rcx
    pop rax
    ret

check_haunt:
    push rax
    push rbx
    mov rbx, [data_ptr_main]
    mov al, [cell_ghost + rbx]
    cmp al, [inst_ptr_present]
    jne .no_haunt
    mov rsi, code_buf
    add rsi, [inst_ptr_present]
    mov bl, [rbx]
    mov [rsi], bl
.no_haunt:
    pop rbx
    pop rax
    ret

lottery_ticket:
    push rax
    call roll_d1000
    cmp rax, 1
    je .lottery_panic
    cmp rax, 1000
    je .toggle_fever
    cmp rax, 2
    je .double_exec
    cmp rax, 3
    je .double_exec
    cmp rax, 5
    je .double_exec
    cmp rax, 7
    je .double_exec
    cmp rax, 11
    je .double_exec
    cmp rax, 13
    je .double_exec
    cmp rax, 17
    je .double_exec
    cmp rax, 19
    je .double_exec
    cmp rax, 23
    je .double_exec
    call is_perfect_square
    cmp rax, 1
    je .skip_next
    pop rax
    ret
.lottery_panic:
    pop rax
    jmp do_panic
.toggle_fever:
    xor byte [fever_mode], 1
    pop rax
    ret
.double_exec:
    pop rax
    push rax
    call crowd_execute
    pop rax
    jmp crowd_execute
.skip_next:
    pop rax
    inc qword [inst_ptr_present]
    ret

is_perfect_square:
    push rbx
    push rcx
    mov rbx, rax
    mov rcx, 1
.square_loop:
    mov rax, rcx
    mul rcx
    cmp rax, rbx
    je .is_square
    jg .not_square
    inc rcx
    jmp .square_loop
.is_square:
    mov rax, 1
    jmp .square_done
.not_square:
    xor rax, rax
.square_done:
    pop rcx
    pop rbx
    ret

archive_and_judge:
    push rax
    push rbx
    push rcx
    mov rcx, [history_index]
    mov al, [data_ptr_main]
    mov [history_buffer + rcx], al
    inc rcx
    and rcx, 9999
    mov [history_index], rcx
    call detect_loop
    cmp rax, 1
    jne .no_pattern
    rdtsc
    mov rsi, code_buf
    add rsi, [inst_ptr_present]
    xor [rsi], al
    mov rbx, [data_ptr_main]
    xor [rbx], al
    xor byte [fever_mode], 1
.no_pattern:
    pop rcx
    pop rbx
    pop rax
    ret

detect_loop:
    push rbx
    push rcx
    push rdx
    xor rax, rax
    mov rcx, 4
.pattern_loop:
    cmp rcx, 100
    jg .no_loop
    mov rdx, [history_index]
    sub rdx, rcx
    jns .check
    add rdx, 10000
.check:
    mov al, [history_buffer + rdx]
    mov bl, [history_buffer + rdx - 1]
    cmp al, bl
    jne .next_pattern
    loop .check
    mov rax, 1
    jmp .detect_done
.next_pattern:
    inc rcx
    jmp .pattern_loop
.no_loop:
    xor rax, rax
.detect_done:
    pop rdx
    pop rcx
    pop rbx
    ret

reencrypt_code:
    push rax
    push rcx
    push r8
    cmp qword [cycle_count], 5000
    jl .no_reencrypt
    mov qword [cycle_count], 0
    rdtsc
    mov r8, rax
    xor rcx, rcx
.enc_loop:
    cmp rcx, [code_len]
    jge .enc_done
    mov al, [code_buf + rcx]
    xor al, r8b
    rol r8, 1
    mov [code_buf + rcx], al
    inc rcx
    jmp .enc_loop
.enc_done:
.no_reencrypt:
    pop r8
    pop rcx
    pop rax
    ret

count_tartarus_instances:
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    xor rax, rax
    mov rdi, proc_path
    mov dword [rdi], 0x6F72702F
    mov word [rdi+4], 0x2F63
    add rdi, 6
    mov rsi, 0
    call pid_loop_count
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    ret

pid_loop_count:
    ret

diplomat:
    push rax
    push rbx
    call count_tartarus_instances
    cmp rax, 1
    jle .alone
    call generate_vote
    call collect_other_votes
    cmp bl, 2
    jl .alone
    cmp al, bl
    jl .panic_vote
    jmp .alone
.panic_vote:
    call do_panic
.alone:
    pop rbx
    pop rax
    ret

generate_vote:
    rdtsc
    and rax, 1
    ret

collect_other_votes:
    xor rbx, rbx
    ret

biographer:
    push rax
    push rcx
    push rdx
    push rsi
    push rdi
    push r12
    mov rax, 2
    mov rdi, path_memoir
    mov rsi, 65 | 1024
    mov rdx, 420
    syscall
    mov r12, rax
    call format_log_entry
    mov rax, 1
    mov rdi, r12
    mov rsi, log_buffer
    mov rdx, 128
    syscall
    mov rax, 3
    mov rdi, r12
    syscall
    pop r12
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rax
    ret

format_log_entry:
    push rax
    push rbx
    push rcx
    push rdx
    mov rdi, log_buffer
    mov rax, [cycle_count]
    call format_number
    mov byte [rdi], ' '
    inc rdi
    mov rax, [inst_ptr_present]
    call format_number
    mov byte [rdi], ' '
    inc rdi
    mov rax, [data_ptr_main]
    call format_number
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret

format_number:
    push rax
    push rbx
    push rcx
    push rdx
    mov rbx, 10
    xor rcx, rcx
.div_loop:
    xor rdx, rdx
    div rbx
    push rdx
    inc rcx
    test rax, rax
    jnz .div_loop
.write_loop:
    pop rax
    add al, 0x30
    mov [rdi], al
    inc rdi
    loop .write_loop
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret

simulate_destruction:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    mov rax, [message_cycles]
    inc rax
    mov [message_cycles], rax
    cmp rax, 100000
    jl .skip_message
    mov qword [message_cycles], 0
    call roll_d20
    cmp rax, 3
    jge .skip_message
    cmp byte [message_triggered], 1
    je .skip_message
    mov byte [message_triggered], 1
    mov rax, 1
    mov rdi, 1
    mov rsi, sudo_msg
    mov rdx, msg_len
    syscall
    jmp .done
.skip_message:
    test rax, 0xFFF
    jnz .done
    mov byte [message_triggered], 0
.done:
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret