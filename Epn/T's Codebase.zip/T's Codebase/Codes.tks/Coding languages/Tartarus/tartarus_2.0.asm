; ==============================================================================
; TARTARUS - The Singularity 
; Architecture: x86_64 Linux
; V: 2.0.8664
; ==============================================================================

section .data
    diamond_marker  db 0xE2, 0x99, 0xA2
    cipher_table    db "7....2.0..1..4..3..5..6...................................", 0
    path_temp       db "/sys/class/thermal/thermal_zone0/temp", 0
    path_tumor      db "TUMOR.blob", 0
    path_null       db "/dev/null", 0
    path_log        db "SINGULARITY.log", 0
    err_rax         dq 0x203A524F52524553
    err_rbx         dq 0x524F525245205841
    err_rcx         dq 0x444945204E4F5721

section .bss
    file_buf          resb 1048576
    code_buf          resb 1048576
    temp_buf          resb 16
    mem_base          resq 1
    data_ptr          resq 1
    inst_ptr_present  resq 1
    inst_ptr_past     resq 1
    inst_ptr_future   resq 1
    code_len          resq 1
    parser_state      resb 1
    prev_char         resb 1
    rng_seed          resq 1
    cycle_count       resq 1
    fever_mode        resb 1
    babel_val         resd 1
    babel_bits        resb 1
    last_time         resq 2
    curr_time         resq 2
    echo_buffer       resb 1048576
    echo_prob         resb 1048576
    log_fd            resq 1
    log_entry         resb 24
    expansion_counter resq 1
    proc_path         resb 32

section .text
    global _start

_start:
    rdtsc
    shl rdx, 32
    or rax, rdx
    mov [rng_seed], rax

    call proof_of_work

    pop rax
    cmp rax, 2
    jl die_silent
    pop rax
    pop rdi
    
    mov rax, 2
    mov rsi, 0
    mov rdx, 0
    syscall
    cmp rax, 0
    jl die_silent
    mov r8, rax

    mov rax, 0
    mov rdi, r8
    mov rsi, file_buf
    mov rdx, 1048576
    syscall
    push rax
    
    mov rax, 3
    mov rdi, r8
    syscall
    
    pop r15

    mov rax, 9
    mov rdi, 0
    mov rsi, 1073741824
    mov rdx, 3
    mov r10, 34
    mov r8, -1
    mov r9, 0
    syscall
    cmp rax, 0
    jl die_silent
    mov [mem_base], rax
    mov [data_ptr], rax

    mov rax, 2
    mov rdi, path_log
    mov rsi, 66
    mov rdx, 420
    syscall
    mov [log_fd], rax

    call extract_diamonds

    mov qword [inst_ptr_present], 0
    mov qword [inst_ptr_past], -1
    mov qword [inst_ptr_future], 1
    mov qword [cycle_count], 0

interpreter_loop:
    mov rcx,[inst_ptr_present]
    cmp rcx, [code_len]
    jge shutdown

    call darkmatter_expansion
    call invoke_taxman
    call price_of_computation
    call check_fever
    call time_dilation
    call chorus_execute
    call whispers

    mov rsi, code_buf
    add rsi, [inst_ptr_present]
    
    call decode_enigma
    
    call execute_with_echo
    call witness_log

    mov rax,[inst_ptr_present]
    mov [inst_ptr_past], rax

    test rax, 1
    jz flow_forward

flow_backward:
    dec qword[inst_ptr_present]
    mov rax, [inst_ptr_present]
    sub rax, 1
    mov [inst_ptr_future], rax
    cmp qword [inst_ptr_present], 0
    jge interpreter_loop
    mov qword [inst_ptr_present], 0
    jmp interpreter_loop

flow_forward:
    inc qword [inst_ptr_present]
    mov rax, [inst_ptr_present]
    add rax, 1
    mov[inst_ptr_future], rax
    jmp interpreter_loop

shutdown:
    mov rax, 60
    xor rdi, rdi
    syscall

die_silent:
    mov rax, 60
    mov rdi, 1
    syscall

extract_diamonds:
    mov rsi, file_buf
    mov rdi, code_buf
    xor rcx, rcx
    xor rdx, rdx
    mov byte [parser_state], 0

ext_loop:
    cmp rcx, r15
    jge ext_done

    mov al, [rsi + rcx]
    cmp al, 0xE2
    jne check_state
    cmp byte[rsi + rcx + 1], 0x99
    jne check_state
    cmp byte[rsi + rcx + 2], 0xA2
    jne check_state

    xor byte [parser_state], 1
    add rcx, 3
    jmp ext_loop

check_state:
    cmp byte[parser_state], 1
    jne skip_byte
    
    mov al, [rsi + rcx]
    mov [rdi + rdx], al
    inc rdx

skip_byte:
    inc rcx
    jmp ext_loop

ext_done:
    mov [code_len], rdx
    ret

proof_of_work:
    push rax
    push rbx
    xor rbx, rbx
mine:
    inc rbx
    mov rax, rbx
    imul rax, 0x5DEECE66D
    xor rax, [rng_seed]
    test rax, 0xFFFFF
    jnz mine
    pop rbx
    pop rax
    ret

check_fever:
    push rax
    push rdi
    push rsi
    push rdx
    
    mov rax, 2
    mov rdi, path_temp
    mov rsi, 0
    syscall
    cmp rax, 0
    jl assume_hot
    push rax

    mov rdi, rax
    mov rax, 0
    mov rsi, temp_buf
    mov rdx, 5
    syscall
    
    mov rax, 3
    pop rdi
    syscall

    cmp byte [temp_buf], 0x35
    jge set_fever
    mov byte [fever_mode], 0
    jmp fever_done

set_fever:
    mov byte [fever_mode], 1
    jmp fever_done

assume_hot:
    mov byte [fever_mode], 1

fever_done:
    pop rdx
    pop rsi
    pop rdi
    pop rax
    ret

invoke_taxman:
    mov rbx, [data_ptr]
    inc byte[rbx + 1]
    mov rax, [cycle_count]
    inc rax
    mov[cycle_count], rax
    test rax, 0xFF
    jnz tax_safe
    
    mov al, [rbx + 1]
    shr al, 4
    add al, 1
    sub [rbx], al
    mov byte [rbx + 1], 0
tax_safe:
    ret

spawn_tumor:
    mov rax, 2
    mov rdi, path_tumor
    mov rsi, 65
    mov rdx, 420
    syscall
    cmp rax, 0
    jl tumor_fail
    mov rdi, rax

    mov rax, 285
    mov rsi, 0
    mov rdx, 0
    mov r10, 1073741824
    syscall
    
    mov rax, 3
    syscall
tumor_fail:
    ret

roll_d20:
    rdtsc
    xor rax, [rng_seed]
    mov[rng_seed], rax
    
    xor rdx, rdx
    mov rbx, 20
    div rbx
    inc rdx
    mov rax, rdx
    
    cmp byte [fever_mode], 1
    jne roll_done
    
    mov rbx, 21
    sub rbx, rax
    mov rax, rbx

roll_done:
    ret

decode_enigma:
    movzx rax, byte [rsi]
    movzx rbx, byte [prev_char]
    add rax, rbx
    add rax,[inst_ptr_present]
    
    xor rdx, rdx
    mov rbx, 94
    div rbx
    
    movzx rax, byte [cipher_table + rdx]
    sub rax, 0x30
    
    mov bl, [rsi]
    mov[prev_char], bl
    ret

execute_opcode:
    cmp rax, 0
    je do_left
    cmp rax, 1
    je do_right
    cmp rax, 2
    je do_bet
    cmp rax, 3
    je do_fold
    cmp rax, 4
    je do_out
    cmp rax, 7
    je do_panic
    ret

do_left:
    mov rbx, [data_ptr]
    test byte[rbx], 0x80
    jz normal_left
    movzx rax, byte[rbx]
    and rax, 0x7F
    shl rax, 20
    add rax, [mem_base]
    mov [data_ptr], rax
    ret
normal_left:
    dec qword [data_ptr]
    ret

do_right:
    mov rbx, [data_ptr]
    test byte [rbx], 0x80
    jz normal_right
    movzx rax, byte [rbx]
    and rax, 0x7F
    shl rax, 20
    add rax, [mem_base]
    mov [data_ptr], rax
    ret
normal_right:
    inc qword[data_ptr]
    ret

do_bet:
    call roll_d20
    cmp rax, 1
    je do_panic
    cmp rax, 11
    jge bet_win
    call schrodinger_load
    dec byte [rbx]
    ret
bet_win:
    call schrodinger_load
    inc byte [rbx]
    ret

do_fold:
    call schrodinger_load
    dec byte [rbx]
    ret

do_out:
    call schrodinger_load
    movzx rcx, byte [rbx]
    call push_babel
    ret

do_panic:
    call spawn_tumor
    call trigger_schrodinger_error
    ret

schrodinger_load:
    mov rbx,[data_ptr]
    mov rcx, [rbx]
    and rcx, 0x3FFFFFFF
    mov rdx, [mem_base]
    add rdx, rcx
    mov rbx, rdx
    
    mov rcx, [data_ptr]
    rol qword [rcx], 3
    
    rdtsc
    test al, 1
    jz s_even
    not byte[rbx]
    ret
s_even:
    rol byte [rbx], 1
    ret

trigger_schrodinger_error:
    mov rax, [err_rax]
    mov rbx, [err_rbx]
    mov rcx, [err_rcx]
    mov rdx, 0
    mov [rdx], rax
    ret

push_babel:
    and cl, 3
    shl dword [babel_val], 2
    or byte[babel_val], cl
    
    inc byte [babel_bits]
    cmp byte [babel_bits], 16
    jl babel_ret
    
    mov rax, 1
    mov rdi, 1
    lea rsi, [babel_val]
    mov rdx, 4
    syscall
    mov dword [babel_val], 0
    mov byte [babel_bits], 0
babel_ret:
    ret

darkmatter_expansion:
    inc qword [expansion_counter]
    cmp qword [expansion_counter], 10000
    jl no_expand
    mov rax, 9
    mov rdi, 0
    mov rsi, 1073741824
    mov rdx, 3
    mov r10, 34
    mov r8, -1
    mov r9, 0
    syscall
    mov qword[expansion_counter], 0
no_expand:
    ret

price_of_computation:
    mov rax, 9
    mov rdi, 0
    mov rsi, 4096
    mov rdx, 3
    mov r10, 34
    mov r8, -1
    mov r9, 0
    syscall
    mov rax, 2
    mov rdi, path_null
    mov rsi, 0
    mov rdx, 0
    syscall
    rdtsc
    test al, 1
    jz skip_spin
    call proof_of_work
skip_spin:
    ret

time_dilation:
    mov rbx,[data_ptr]
    movzx rax, byte [rbx]
    movzx rcx, word[inst_ptr_present]
    xor rax, rcx
    and rax, 0x7F
    cmp byte [fever_mode], 1
    jne delay_loop
    not rax
    and rax, 0x7F
delay_loop:
    dec rax
    test rax, rax
    jg delay_loop
    ret

chorus_execute:
    mov rax, [inst_ptr_present]
    cmp [inst_ptr_past], rax
    je trigger_schrodinger_error
    cmp [inst_ptr_future], rax
    je trigger_schrodinger_error
    ret

execute_with_echo:
    call execute_opcode
    mov rcx, [inst_ptr_present]
    mov al, [code_buf + rcx]
    mov [echo_buffer + rcx], al
    mov byte [echo_prob + rcx], 0x10
    xor rdx, rdx
    rdtsc
    and al, 0x3F
    cmp al, [echo_prob + rcx]
    jg no_echo
    push qword [inst_ptr_present]
    mov [inst_ptr_present], rcx
    call execute_opcode
    pop qword [inst_ptr_present]
no_echo:
    ret

witness_log:
    push rax
    push rsi
    push rdi
    push rdx
    mov rax, [inst_ptr_present]
    mov [log_entry], rax
    mov rax, [data_ptr]
    mov [log_entry + 8], rax
    mov rax, [cycle_count]
    mov [log_entry + 16], rax
    mov rax, 1
    mov rdi, [log_fd]
    mov rsi, log_entry
    mov rdx, 24
    syscall
    pop rdx
    pop rdi
    pop rsi
    pop rax
    ret

whispers:
    push rax
    push rcx
    push rdx
    push rsi
    push rdi
    rdtsc
    and rax, 0x7FFF
    mov rcx, 10
    mov rdi, proc_path
    mov dword [rdi], 0x6F72702F
    mov word [rdi+4], 0x2F63
    add rdi, 6
pid_loop:
    xor rdx, rdx
    div rcx
    add dl, 0x30
    mov [rdi], dl
    inc rdi
    test rax, rax
    jnz pid_loop
    mov dword [rdi], 0x6D656D2F
    mov byte [rdi+4], 0
    mov rax, 2
    mov rdi, proc_path
    mov rsi, 2
    mov rdx, 0
    syscall
    cmp rax, 0
    jl w_done
    mov rdi, rax
    mov rax, 1
    mov rsi, data_ptr
    mov rdx, 1
    syscall
    mov rax, 3
    syscall
w_done:
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rax
    ret