import random
import numpy as np
from abc import ABC, abstractmethod
from enum import Enum
import pickle
import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                               QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                               QSpinBox, QGroupBox, QGridLayout, QProgressBar,
                               QTabWidget, QTableWidget, QTableWidgetItem,
                               QHeaderView, QSplitter, QFrame)
from PySide6.QtCore import QTimer, Qt, Signal, QObject
from PySide6.QtGui import QFont, QColor, QPalette

# ==================== ENUMS AND CONSTANTS ====================

class Season(Enum):
    SPRING = "spring"
    SUMMER = "summer"
    AUTUMN = "autumn"
    WINTER = "winter"

class Weather(Enum):
    CLEAR = "clear"
    RAIN = "rain"
    DROUGHT = "drought"
    STORM = "storm"
    MILD = "mild"

# ==================== GENETIC TRAITS ====================

class GeneticTraits:
    """Genetic traits that can be inherited and evolve"""
    
    def __init__(self, parent1=None, parent2=None):
        if parent1 and parent2:
            # Inherit from parents with mutation
            self.speed = self._inherit_trait(parent1.speed, parent2.speed)
            self.strength = self._inherit_trait(parent1.strength, parent2.strength)
            self.fertility = self._inherit_trait(parent1.fertility, parent2.fertility)
            self.longevity = self._inherit_trait(parent1.longevity, parent2.longevity)
            self.metabolism = self._inherit_trait(parent1.metabolism, parent2.metabolism)
        else:
            # Random initial traits
            self.speed = random.uniform(0.5, 1.5)
            self.strength = random.uniform(0.5, 1.5)
            self.fertility = random.uniform(0.5, 1.5)
            self.longevity = random.uniform(0.5, 1.5)
            self.metabolism = random.uniform(0.5, 1.5)
    
    def _inherit_trait(self, trait1, trait2):
        """Inherit trait with mutation"""
        # Average of parents
        trait = (trait1 + trait2) / 2
        
        # 10% chance of mutation
        if random.random() < 0.1:
            trait *= random.uniform(0.8, 1.2)
        
        # Keep within bounds
        return max(0.3, min(2.0, trait))
    
    def to_dict(self):
        return {
            'speed': self.speed,
            'strength': self.strength,
            'fertility': self.fertility,
            'longevity': self.longevity,
            'metabolism': self.metabolism
        }

# ==================== ABSTRACT BASE CLASSES ====================

class Animal(ABC):
    """Abstract base class for all animals"""
    
    def __init__(self, name, energy, species):
        self.name = name
        self.energy = energy
        self.species = species
        self.age = 0
        self.max_energy = 100
        self.days_since_last_meal = 0
        self.genes = GeneticTraits()
        self.territory = None
        self.home_range = []
    
    def move(self):
        loss = int(random.randint(1, 5) * self.genes.metabolism)
        self.energy = max(0, self.energy - loss)
        return loss
    
    def eat(self, food_energy=0):
        if food_energy > 0:
            gain = food_energy
            self.energy = min(self.max_energy, self.energy + food_energy)
            self.days_since_last_meal = 0
        else:
            gain = random.randint(5, 10)
            self.energy = min(self.max_energy, self.energy + gain)
            self.days_since_last_meal = 0
        return gain
    
    def is_alive(self):
        # Die from starvation if no food for 5 days
        if self.days_since_last_meal > 5:
            return False
        # Max age influenced by genetics
        max_age = int(5844 * self.genes.longevity)
        return self.energy > 0 and self.age < max_age
    
    @abstractmethod
    def daily_action(self, forest):
        """Polymorphic method - different for each animal type"""
        pass
    
    @abstractmethod
    def reproduce(self, partner=None):
        """Reproduction behavior"""
        pass
    
    def __str__(self):
        return f"{self.name} ({self.species}) - Energy: {self.energy}, Age: {self.age}"

# ==================== TERRITORY SYSTEM ====================

class Territory:
    """Territory that animals can claim and defend"""
    
    def __init__(self, name, size, food_density):
        self.name = name
        self.size = size
        self.food_density = food_density
        self.occupants = []
        self.resources = size * food_density
        self.owner = None  # Alpha animal that owns the territory
    
    def add_occupant(self, animal):
        if animal not in self.occupants:
            self.occupants.append(animal)
            animal.territory = self
    
    def remove_occupant(self, animal):
        if animal in self.occupants:
            self.occupants.remove(animal)
            animal.territory = None
            if self.owner == animal:
                self.owner = None
    
    def claim(self, animal):
        """Claim territory (if strong enough)"""
        if self.owner is None:
            self.owner = animal
            return True
        elif animal.genes.strength > self.owner.genes.strength:
            # Challenge existing owner
            self.owner = animal
            return True
        return False
    
    def regenerate_resources(self, season):
        """Regenerate resources based on season"""
        season_multiplier = {
            Season.SPRING: 1.5,
            Season.SUMMER: 1.2,
            Season.AUTUMN: 1.0,
            Season.WINTER: 0.5
        }
        self.resources = min(self.size * self.food_density * 2,
                           self.resources + self.size * season_multiplier[season])

# ==================== ANIMAL CLASSES ====================

class Lion(Animal):
    """Lion class with pack behavior"""
    
    def __init__(self, name, energy):
        super().__init__(name, energy, "Lion")
        self.hunt_success_rate = 0.5 * self.genes.strength
        self.hunger_threshold = 15
        self.pride = []
        self.hunts_successful = 0
        self.hunts_failed = 0
        self.pack_size = 1
    
    def daily_action(self, forest):
        super().daily_action(forest)
        rabbits = [a for a in forest if isinstance(a, Rabbit)]
        action_report = []
        
        # Update pack size (lions in same territory)
        if self.territory:
            self.pack_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Lion))
        
        # Hunting bonus from pack
        hunting_bonus = min(0.3, self.pack_size * 0.1)
        
        if rabbits and self.energy < self.hunger_threshold:
            # Hungry lions hunt more aggressively
            target = random.choice(rabbits)
            success = random.random() < (self.hunt_success_rate + hunting_bonus)
            
            if success:
                forest.remove(target)
                self.eat(target.energy)
                self.hunts_successful += 1
                action_report.append(f"🦁 {self.name} hunted {target.name}! Energy now: {self.energy}")
                return "hunt_success", action_report
            else:
                loss = self.move()
                self.hunts_failed += 1
                action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                return "hunt_fail", action_report
        elif rabbits:
            # Well-fed lions may still hunt occasionally
            if random.random() < 0.3:
                target = random.choice(rabbits)
                if random.random() < (self.hunt_success_rate + hunting_bonus):
                    forest.remove(target)
                    self.eat(target.energy)
                    self.hunts_successful += 1
                    action_report.append(f"🦁 {self.name} hunted {target.name}! Energy: {self.energy}")
                    return "hunt_success", action_report
                else:
                    loss = self.move()
                    self.hunts_failed += 1
                    action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                    return "hunt_fail", action_report
            else:
                loss = self.move()
                action_report.append(f"🦁 {self.name} rested. Lost {loss} energy. Energy: {self.energy}")
                return "rest", action_report
        else:
            loss = self.move()
            action_report.append(f"🦁 {self.name} found no prey. Lost {loss} energy. Energy: {self.energy}")
            return "no_prey", action_report
    
    def reproduce(self, partner=None):
        """Lion reproduction"""
        if partner and isinstance(partner, Lion):
            # Create cub with inherited genes
            cub = Lion(f"Cub_{random.randint(100,999)}", 
                      random.randint(15, 25))
            cub.genes = GeneticTraits(self, partner)
            cub.age = 0
            return cub
        return None

class Rabbit(Animal):
    """Rabbit class with hiding behavior"""
    
    def __init__(self, name, energy):
        super().__init__(name, energy, "Rabbit")
        self.reproduction_rate = 0.3 * self.genes.fertility
        self.hidden = False
        self.hiding_spot = None
        self.children_born = 0
        self.herd_size = 1
    
    def daily_action(self, forest):
        super().daily_action(forest)
        action_report = []
        lions_present = any(isinstance(a, Lion) for a in forest)
        
        # Update herd size (rabbits in same territory)
        if self.territory:
            self.herd_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Rabbit))
        
        # Safety in numbers - less likely to hide in large herds
        hiding_chance = 0.4 / max(1, self.herd_size * 0.5)
        
        if lions_present and random.random() < hiding_chance:
            # Rabbits can hide from lions
            self.hidden = True
            self.hiding_spot = f"spot_{random.randint(1,10)}"
            action_report.append(f"🐰 {self.name} is hiding in {self.hiding_spot}!")
        else:
            self.hidden = False
            self.hiding_spot = None
            loss = self.move()
            action_report.append(f"🐰 {self.name} moved. Lost {loss} energy. Energy: {self.energy}")
        
        # Reproduce only if enough energy and safe
        baby = None
        if self.energy > 15 and random.random() < self.reproduction_rate and not self.hidden:
            baby_energy = random.randint(5, 10)
            baby = Rabbit(f"Rabbit_{random.randint(100,999)}", baby_energy)
            baby.genes = GeneticTraits(self, self)  # Self-reproduction
            baby.age = 0
            self.children_born += 1
            action_report.append(f"🐰 {self.name} gave birth to {baby.name}!")
        
        return baby, action_report
    
    def reproduce(self, partner=None):
        """Rabbit reproduction"""
        if random.random() < self.reproduction_rate:
            baby = Rabbit(f"Rabbit_{random.randint(100,999)}", 
                         random.randint(5, 10))
            if partner and isinstance(partner, Rabbit):
                baby.genes = GeneticTraits(self, partner)
            else:
                baby.genes = GeneticTraits(self, self)
            return baby
        return None

# ==================== NEW ANIMAL SPECIES ====================

class Wolf(Animal):
    """Wolf class - hunts in packs"""
    
    def __init__(self, name, energy):
        super().__init__(name, energy, "Wolf")
        self.pack_size = 1
        self.hunting_bonus = 0.1
        self.hunts_successful = 0
        self.hunts_failed = 0
    
    def daily_action(self, forest):
        super().daily_action(forest)
        rabbits = [a for a in forest if isinstance(a, (Rabbit, Deer))]
        action_report = []
        
        # Update pack size
        if self.territory:
            self.pack_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Wolf))
        
        pack_bonus = min(0.5, self.pack_size * 0.15)
        
        if rabbits and self.energy < 20:
            target = random.choice(rabbits)
            success = random.random() < (0.4 + pack_bonus) * self.genes.strength
            
            if success:
                forest.remove(target)
                self.eat(target.energy)
                self.hunts_successful += 1
                action_report.append(f"🐺 {self.name} hunted {target.name}! Energy: {self.energy}")
            else:
                loss = self.move()
                self.hunts_failed += 1
                action_report.append(f"🐺 {self.name} failed to hunt. Lost {loss} energy")
        else:
            loss = self.move()
            action_report.append(f"🐺 {self.name} roamed. Lost {loss} energy")
        
        return None, action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Wolf):
            pup = Wolf(f"Wolf_{random.randint(100,999)}", random.randint(10, 20))
            pup.genes = GeneticTraits(self, partner)
            return pup
        return None

class Deer(Animal):
    """Deer class - fast herbivore"""
    
    def __init__(self, name, energy):
        super().__init__(name, energy, "Deer")
        self.herd_size = 1
        self.speed_bonus = 1.5 * self.genes.speed
    
    def daily_action(self, forest):
        super().daily_action(forest)
        action_report = []
        
        # Update herd size
        if self.territory:
            self.herd_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Deer))
        
        # Deer are fast - they move more but can escape better
        loss = self.move()
        action_report.append(f"🦌 {self.name} grazed. Lost {loss} energy")
        
        # Reproduction
        baby = None
        if self.energy > 25 and random.random() < 0.2 * self.genes.fertility:
            baby = Deer(f"Deer_{random.randint(100,999)}", random.randint(10, 15))
            baby.genes = GeneticTraits(self, self)
            action_report.append(f"🦌 {self.name} gave birth to a fawn!")
        
        return baby, action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Deer):
            fawn = Deer(f"Deer_{random.randint(100,999)}", random.randint(10, 15))
            fawn.genes = GeneticTraits(self, partner)
            return fawn
        return None

# ==================== ANIMAL FACTORY ====================

class AnimalFactory:
    """Factory for creating animals"""
    
    @staticmethod
    def create_animal(species, name=None, energy=None):
        """Create an animal of the specified species"""
        if species == "Lion":
            name = name or AnimalFactory._random_lion_name()
            energy = energy or random.randint(25, 35)
            return Lion(name, energy)
        elif species == "Rabbit":
            name = name or f"Rabbit_{random.randint(100,999)}"
            energy = energy or random.randint(8, 15)
            return Rabbit(name, energy)
        elif species == "Wolf":
            name = name or f"Wolf_{random.randint(100,999)}"
            energy = energy or random.randint(20, 30)
            return Wolf(name, energy)
        elif species == "Deer":
            name = name or f"Deer_{random.randint(100,999)}"
            energy = energy or random.randint(15, 25)
            return Deer(name, energy)
        else:
            raise ValueError(f"Unknown species: {species}")
    
    @staticmethod
    def _random_lion_name():
        male_names = ["Leo", "Leon", "Aslan", "Simba", "Mufasa", "Scar", "Kimba"]
        female_names = ["Nala", "Sarabi", "Kiara", "Cleopatra", "Nefertiti", "Zara"]
        all_names = male_names + female_names
        return f"{random.choice(all_names)}_{random.randint(10,99)}"

# ==================== EVENT SYSTEM ====================

class Event(ABC):
    """Base class for random events"""
    
    def __init__(self, name, probability):
        self.name = name
        self.probability = probability
    
    @abstractmethod
    def apply(self, simulator):
        """Apply the event to the simulator"""
        pass
    
    def __str__(self):
        return self.name

class ForestFire(Event):
    """Forest fire event - reduces plants and harms animals"""
    
    def __init__(self):
        super().__init__("🔥 Forest Fire", 0.01)
    
    def apply(self, simulator):
        # Reduce plant food by half
        simulator.environment.food_available = int(simulator.environment.food_available * 0.5)
        
        # Harm all animals
        casualties = []
        for animal in simulator.forest[:]:
            if random.random() < 0.3:  # 30% chance of death/injury
                animal.energy = int(animal.energy * 0.7)
                casualties.append(animal.name)
        
        return f"🔥 FOREST FIRE! Plants halved. {len(casualties)} animals injured."

class DiseaseOutbreak(Event):
    """Disease outbreak - affects specific species"""
    
    def __init__(self):
        super().__init__("🦠 Disease Outbreak", 0.02)
    
    def apply(self, simulator):
        # Choose random species
        species = random.choice(["Lion", "Rabbit", "Wolf", "Deer"])
        casualties = []
        
        for animal in simulator.forest[:]:
            if animal.species == species and random.random() < 0.4:
                simulator.forest.remove(animal)
                casualties.append(animal.name)
        
        return f"🦠 DISEASE OUTBREAK! {len(casualties)} {species}s died."

class MatingSeason(Event):
    """Mating season - boosts reproduction"""
    
    def __init__(self):
        super().__init__("💕 Mating Season", 0.1)
    
    def apply(self, simulator):
        # Boost reproduction for one day
        newborns = 0
        for animal in simulator.forest[:]:
            if isinstance(animal, Rabbit) and random.random() < 0.5:
                baby = animal.reproduce()
                if baby:
                    simulator.forest.append(baby)
                    newborns += 1
        
        return f"💕 MATING SEASON! {newborns} babies born today!"

class MigratingHerd(Event):
    """Migrating herd - adds new animals"""
    
    def __init__(self):
        super().__init__("🦌 Migrating Herd", 0.05)
    
    def apply(self, simulator):
        # Add new animals
        new_animals = []
        for _ in range(random.randint(1, 3)):
            species = random.choice(["Deer", "Rabbit"])
            animal = AnimalFactory.create_animal(species)
            new_animals.append(animal)
        
        simulator.forest.extend(new_animals)
        names = ", ".join([a.name for a in new_animals])
        return f"🦌 MIGRATING HERD! New arrivals: {names}"

class EventManager:
    """Manages random events in the simulation"""
    
    def __init__(self):
        self.events = [
            ForestFire(),
            DiseaseOutbreak(),
            MatingSeason(),
            MigratingHerd()
        ]
        self.event_history = []
    
    def check_events(self, simulator):
        """Check and apply random events"""
        reports = []
        for event in self.events:
            if random.random() < event.probability:
                result = event.apply(simulator)
                reports.append(result)
                self.event_history.append((simulator.day, event.name))
        return reports

# ==================== ENVIRONMENT ====================

class Environment:
    """Environment with seasons and weather"""
    
    def __init__(self, name):
        self.name = name
        self.food_available = 100
        self.weather = Weather.CLEAR
        self.season = Season.SPRING
        self.day = 0
        self.territories = self._create_territories()
    
    def _create_territories(self):
        """Create territories for the forest"""
        return [
            Territory("Meadow", 10, 8),
            Territory("Forest", 15, 6),
            Territory("River Valley", 12, 7),
            Territory("Hilltop", 8, 5),
            Territory("Deep Woods", 20, 4)
        ]
    
    def update_weather(self):
        self.day += 1
        
        # Update season every 10 days
        if self.day % 10 == 0:
            season_index = (self.day // 10) % 4
            self.season = list(Season)[season_index]
        
        # Weather probabilities based on season
        weights = {
            Season.SPRING: [0.3, 0.4, 0.1, 0.1, 0.1],
            Season.SUMMER: [0.5, 0.1, 0.3, 0.05, 0.05],
            Season.AUTUMN: [0.3, 0.3, 0.1, 0.2, 0.1],
            Season.WINTER: [0.2, 0.2, 0.1, 0.3, 0.2]
        }
        
        self.weather = random.choices(list(Weather), weights[self.season])[0]
        
        # Update food availability
        season_food_modifier = {
            Season.SPRING: 8,
            Season.SUMMER: 3,
            Season.AUTUMN: 2,
            Season.WINTER: -10
        }
        
        weather_food_modifier = {
            Weather.CLEAR: 0,
            Weather.RAIN: 5,
            Weather.DROUGHT: -5,
            Weather.STORM: -3,
            Weather.MILD: 2
        }
        
        self.food_available += season_food_modifier[self.season] + weather_food_modifier[self.weather]
        self.food_available = max(20, min(200, self.food_available))
        
        # Regenerate territories
        for territory in self.territories:
            territory.regenerate_resources(self.season)
        
        return self.weather
    
    def apply_weather_effects(self, animal):
        if animal is None:
            return 0
            
        effect = 0
        if self.weather == Weather.RAIN:
            effect = random.randint(1, 3)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        elif self.weather == Weather.DROUGHT:
            effect = -random.randint(0, 2)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == Weather.STORM:
            effect = -random.randint(1, 4)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == Weather.MILD:
            effect = random.randint(0, 1)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        
        return effect
    
    def get_plant_food(self):
        if self.food_available > 0:
            max_food = 3 if self.season == Season.WINTER else 5
            food = min(random.randint(1, max_food), self.food_available)
            self.food_available -= food
            return food
        return 0
    
    def assign_territory(self, animal):
        """Assign animal to a territory"""
        if not animal.territory:
            # Find territory with space
            available = [t for t in self.territories if len(t.occupants) < t.size]
            if available:
                territory = random.choice(available)
                territory.add_occupant(animal)
                return territory
        return animal.territory
    
    def __str__(self):
        return f"Weather: {self.weather.value}, Season: {self.season.value}, Plants: {self.food_available}"

# ==================== OPTIMIZED FOREST (NUMPY) ====================

class OptimizedForest:
    """Forest with numpy optimization for large populations"""
    
    def __init__(self):
        # Use numpy arrays for efficient operations
        self.rabbit_energies = np.array([])
        self.rabbit_ages = np.array([])
        self.rabbit_genes = []
        
        self.lion_energies = np.array([])
        self.lion_ages = np.array([])
        self.lion_genes = []
        
        self.wolf_energies = np.array([])
        self.deer_energies = np.array([])
    
    def add_rabbits(self, count, base_energy=10):
        """Add multiple rabbits efficiently"""
        new_energies = np.random.randint(base_energy-3, base_energy+3, count)
        new_ages = np.zeros(count)
        
        self.rabbit_energies = np.concatenate([self.rabbit_energies, new_energies])
        self.rabbit_ages = np.concatenate([self.rabbit_ages, new_ages])
        
        # Add random genes
        for _ in range(count):
            self.rabbit_genes.append(GeneticTraits())
    
    def apply_daily_energy_loss(self, loss_range=(1, 5)):
        """Apply energy loss to all animals at once"""
        # Vectorized operations for rabbits
        rabbit_loss = np.random.randint(loss_range[0], loss_range[1], 
                                       size=len(self.rabbit_energies))
        self.rabbit_energies = np.maximum(0, self.rabbit_energies - rabbit_loss)
        
        # Vectorized for lions
        lion_loss = np.random.randint(loss_range[0], loss_range[1], 
                                     size=len(self.lion_energies))
        self.lion_energies = np.maximum(0, self.lion_energies - lion_loss)
    
    def get_stats(self):
        """Get population statistics"""
        return {
            'rabbits': len(self.rabbit_energies),
            'lions': len(self.lion_energies),
            'wolves': len(self.wolf_energies),
            'deer': len(self.deer_energies),
            'total_energy': (np.sum(self.rabbit_energies) + 
                           np.sum(self.lion_energies) +
                           np.sum(self.wolf_energies) +
                           np.sum(self.deer_energies))
        }

# ==================== PYSIDE6 GUI ====================

class SimulationWorker(QObject):
    """Worker object for running simulation in separate thread"""
    
    update_signal = Signal(str)
    status_signal = Signal(dict)
    finished = Signal()
    
    def __init__(self, simulator):
        super().__init__()
        self.simulator = simulator
        self.running = False
        self.paused = False
        self.speed = 1.0
    
    def run(self):
        """Run the simulation"""
        self.running = True
        while self.running and self.simulator.forest:
            if not self.paused:
                # Run one day
                reports = self.simulator.simulate_day()
                
                # Send updates
                for report in reports:
                    self.update_signal.emit(report)
                
                # Send status
                self.status_signal.emit(self.simulator.get_status_dict())
            
            # Wait based on speed
            QApplication.processEvents()
            QTimer.singleShot(int(1000 / self.speed), lambda: None)
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
    
    def pause(self):
        self.paused = not self.paused

class ForestSimulatorGUI(QMainWindow):
    """Main GUI window for the forest simulator"""
    
    def __init__(self):
        super().__init__()
        self.simulator = ForestSimulator()
        self.worker = None
        self.timer = QTimer()
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("🌳 Wildlife Simulator")
        self.setGeometry(100, 100, 1200, 800)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Left panel - Controls
        left_panel = self.create_control_panel()
        main_layout.addWidget(left_panel, 1)
        
        # Right panel - Display
        right_panel = self.create_display_panel()
        main_layout.addWidget(right_panel, 2)
        
        # Apply dark theme
        self.apply_dark_theme()
    
    def create_control_panel(self):
        """Create the control panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Simulation controls group
        control_group = QGroupBox("Simulation Controls")
        control_layout = QVBoxLayout()
        
        # Day selection
        day_layout = QHBoxLayout()
        day_layout.addWidget(QLabel("Days to run:"))
        self.day_spinbox = QSpinBox()
        self.day_spinbox.setRange(1, 1000)
        self.day_spinbox.setValue(30)
        day_layout.addWidget(self.day_spinbox)
        control_layout.addLayout(day_layout)
        
        # Speed control
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("Speed:"))
        self.speed_slider = QProgressBar()
        self.speed_slider.setRange(1, 10)
        self.speed_slider.setValue(5)
        speed_layout.addWidget(QLabel("Slow"))
        speed_layout.addWidget(self.speed_slider)
        speed_layout.addWidget(QLabel("Fast"))
        control_layout.addLayout(speed_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.start_btn = QPushButton("▶ Start")
        self.start_btn.clicked.connect(self.start_simulation)
        button_layout.addWidget(self.start_btn)
        
        self.pause_btn = QPushButton("⏸ Pause")
        self.pause_btn.clicked.connect(self.pause_simulation)
        self.pause_btn.setEnabled(False)
        button_layout.addWidget(self.pause_btn)
        
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)
        
        control_layout.addLayout(button_layout)
        
        # Step button
        self.step_btn = QPushButton("⏩ Step Day")
        self.step_btn.clicked.connect(self.step_day)
        control_layout.addWidget(self.step_btn)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        # Initialization group
        init_group = QGroupBox("Initialize")
        init_layout = QVBoxLayout()
        
        self.init_btn = QPushButton("🌱 New Forest")
        self.init_btn.clicked.connect(self.initialize_forest)
        init_layout.addWidget(self.init_btn)
        
        init_group.setLayout(init_layout)
        layout.addWidget(init_group)
        
        # Save/Load group
        save_group = QGroupBox("Save/Load")
        save_layout = QVBoxLayout()
        
        self.save_btn = QPushButton("💾 Save")
        self.save_btn.clicked.connect(self.save_simulation)
        save_layout.addWidget(self.save_btn)
        
        self.load_btn = QPushButton("📂 Load")
        self.load_btn.clicked.connect(self.load_simulation)
        save_layout.addWidget(self.load_btn)
        
        save_group.setLayout(save_layout)
        layout.addWidget(save_group)
        
        # Statistics display
        stats_group = QGroupBox("Current Statistics")
        self.stats_layout = QVBoxLayout()
        
        self.stats_labels = {
            'day': QLabel("Day: 0"),
            'rabbits': QLabel("🐰 Rabbits: 0"),
            'lions': QLabel("🦁 Lions: 0"),
            'wolves': QLabel("🐺 Wolves: 0"),
            'deer': QLabel("🦌 Deer: 0"),
            'plants': QLabel("🌱 Plants: 100"),
            'weather': QLabel("☀️ Weather: Clear"),
            'season': QLabel("🌸 Season: Spring")
        }
        
        for label in self.stats_labels.values():
            self.stats_layout.addWidget(label)
        
        stats_group.setLayout(self.stats_layout)
        layout.addWidget(stats_group)
        
        layout.addStretch()
        return panel
    
    def create_display_panel(self):
        """Create the display panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Tab widget
        tabs = QTabWidget()
        
        # Log tab
        log_widget = QWidget()
        log_layout = QVBoxLayout(log_widget)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier", 10))
        log_layout.addWidget(self.log_text)
        
        tabs.addTab(log_widget, "📋 Event Log")
        
        # Animals tab
        animals_widget = QWidget()
        animals_layout = QVBoxLayout(animals_widget)
        
        self.animals_table = QTableWidget()
        self.animals_table.setColumnCount(5)
        self.animals_table.setHorizontalHeaderLabels(["Species", "Name", "Energy", "Age", "Genes"])
        self.animals_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        animals_layout.addWidget(self.animals_table)
        
        tabs.addTab(animals_widget, "🐾 Animals")
        
        # Statistics tab
        stats_widget = QWidget()
        stats_layout = QVBoxLayout(stats_widget)
        
        self.stats_table = QTableWidget()
        self.stats_table.setColumnCount(2)
        self.stats_table.setHorizontalHeaderLabels(["Statistic", "Value"])
        self.stats_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        stats_layout.addWidget(self.stats_table)
        
        tabs.addTab(stats_widget, "📊 Statistics")
        
        layout.addWidget(tabs)
        
        return panel
    
    def apply_dark_theme(self):
        """Apply dark theme to the application"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2b2b2b;
            }
            QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
                font-size: 12px;
            }
            QGroupBox {
                border: 2px solid #555;
                border-radius: 5px;
                margin-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QPushButton {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 5px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #4a4a4a;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
            QTextEdit {
                background-color: #1e1e1e;
                border: 1px solid #555;
                border-radius: 3px;
            }
            QTableWidget {
                background-color: #1e1e1e;
                border: 1px solid #555;
                gridline-color: #555;
            }
            QHeaderView::section {
                background-color: #3c3c3c;
                padding: 5px;
                border: 1px solid #555;
            }
            QSpinBox {
                background-color: #1e1e1e;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 2px;
            }
            QProgressBar {
                border: 1px solid #555;
                border-radius: 3px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #4a90e2;
                border-radius: 2px;
            }
        """)
    
    def initialize_forest(self):
        """Initialize a new forest"""
        self.simulator = ForestSimulator()
        self.simulator.initialize_forest()
        self.update_display()
        self.log_text.append("🌳 New forest initialized!")
    
    def start_simulation(self):
        """Start the simulation"""
        if not self.simulator.forest:
            self.initialize_forest()
        
        self.start_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.stop_btn.setEnabled(True)
        self.init_btn.setEnabled(False)
        self.step_btn.setEnabled(False)
        
        # Create and start worker thread
        self.worker = SimulationWorker(self.simulator)
        self.worker.update_signal.connect(self.add_log)
        self.worker.status_signal.connect(self.update_stats)
        self.worker.finished.connect(self.simulation_finished)
        
        # Set speed
        self.worker.speed = self.speed_slider.value()
        
        # Start in separate thread
        from threading import Thread
        self.thread = Thread(target=self.worker.run)
        self.thread.start()
    
    def pause_simulation(self):
        """Pause/resume the simulation"""
        if self.worker:
            self.worker.pause()
            self.pause_btn.setText("▶ Resume" if self.worker.paused else "⏸ Pause")
    
    def stop_simulation(self):
        """Stop the simulation"""
        if self.worker:
            self.worker.stop()
    
    def step_day(self):
        """Run one day of simulation"""
        if self.simulator.forest:
            reports = self.simulator.simulate_day()
            for report in reports:
                self.add_log(report)
            self.update_display()
    
    def simulation_finished(self):
        """Called when simulation finishes"""
        self.start_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.stop_btn.setEnabled(False)
        self.init_btn.setEnabled(True)
        self.step_btn.setEnabled(True)
        
        self.add_log("\n🏁 Simulation finished!")
        self.add_log(self.simulator.get_final_stats())
    
    def add_log(self, message):
        """Add message to log"""
        self.log_text.append(message)
        # Scroll to bottom
        cursor = self.log_text.textCursor()
        cursor.movePosition(cursor.End)
        self.log_text.setTextCursor(cursor)
    
    def update_display(self):
        """Update all display elements"""
        self.update_stats(self.simulator.get_status_dict())
        self.update_animals_table()
        self.update_stats_table()
    
    def update_stats(self, stats):
        """Update statistics display"""
        self.stats_labels['day'].setText(f"Day: {stats['day']}")
        self.stats_labels['rabbits'].setText(f"🐰 Rabbits: {stats['rabbits']}")
        self.stats_labels['lions'].setText(f"🦁 Lions: {stats['lions']}")
        self.stats_labels['wolves'].setText(f"🐺 Wolves: {stats['wolves']}")
        self.stats_labels['deer'].setText(f"🦌 Deer: {stats['deer']}")
        self.stats_labels['plants'].setText(f"🌱 Plants: {stats['plants']}")
        self.stats_labels['weather'].setText(f"☀️ Weather: {stats['weather']}")
        self.stats_labels['season'].setText(f"🌸 Season: {stats['season']}")
    
    def update_animals_table(self):
        """Update the animals table"""
        self.animals_table.setRowCount(len(self.simulator.forest))
        
        for i, animal in enumerate(self.simulator.forest):
            species_item = QTableWidgetItem(animal.species)
            name_item = QTableWidgetItem(animal.name)
            energy_item = QTableWidgetItem(str(animal.energy))
            age_item = QTableWidgetItem(str(animal.age))
            
            # Color code energy
            if animal.energy < 20:
                energy_item.setForeground(QColor(255, 100, 100))
            elif animal.energy > 50:
                energy_item.setForeground(QColor(100, 255, 100))
            
            genes = animal.genes.to_dict()
            genes_str = f"S:{genes['speed']:.1f} St:{genes['strength']:.1f} F:{genes['fertility']:.1f}"
            genes_item = QTableWidgetItem(genes_str)
            
            self.animals_table.setItem(i, 0, species_item)
            self.animals_table.setItem(i, 1, name_item)
            self.animals_table.setItem(i, 2, energy_item)
            self.animals_table.setItem(i, 3, age_item)
            self.animals_table.setItem(i, 4, genes_item)
    
    def update_stats_table(self):
        """Update the statistics table"""
        stats = self.simulator.stats
        self.stats_table.setRowCount(15)
        
        stat_items = [
            ("Total Days", str(self.simulator.day)),
            ("Total Births", str(stats['rabbits_born'] + stats.get('lions_born', 0))),
            ("Total Deaths", str(stats['deaths'])),
            ("Starvation Deaths", str(stats['starvation_deaths'])),
            ("Old Age Deaths", str(stats['old_age_deaths'])),
            ("Successful Hunts", str(stats['hunts_successful'])),
            ("Failed Hunts", str(stats['hunts_failed'])),
            ("Plant Consumption", str(stats['plant_consumption'])),
            ("Clear Days", str(stats['weather_events']['clear'])),
            ("Rainy Days", str(stats['weather_events']['rain'])),
            ("Drought Days", str(stats['weather_events']['drought'])),
            ("Storm Days", str(stats['weather_events']['storm'])),
            ("Mild Days", str(stats['weather_events']['mild']))
        ]
        
        for i, (label, value) in enumerate(stat_items):
            self.stats_table.setItem(i, 0, QTableWidgetItem(label))
            self.stats_table.setItem(i, 1, QTableWidgetItem(value))
    
    def save_simulation(self):
        """Save the simulation state"""
        filename = "simulation_save.pkl"
        self.simulator.save_simulation(filename)
        self.add_log(f"💾 Simulation saved to {filename}")
    
    def load_simulation(self):
        """Load a saved simulation"""
        filename = "simulation_save.pkl"
        try:
            self.simulator = ForestSimulator.load_simulation(filename)
            self.update_display()
            self.add_log(f"📂 Simulation loaded from {filename}")
        except FileNotFoundError:
            self.add_log("❌ No saved simulation found!")

# ==================== MAIN SIMULATOR CLASS ====================

class ForestSimulator:
    """Main simulator class"""
    
    def __init__(self):
        self.forest = []
        self.environment = Environment("Enchanted Forest")
        self.day = 0
        self.event_manager = EventManager()
        self.optimized_forest = OptimizedForest()
        self.stats = {
            "rabbits_born": 0,
            "lions_born": 0,
            "hunts_successful": 0,
            "hunts_failed": 0,
            "deaths": 0,
            "rabbit_deaths": 0,
            "lion_deaths": 0,
            "starvation_deaths": 0,
            "old_age_deaths": 0,
            "weather_events": {"clear": 0, "rain": 0, "drought": 0, "storm": 0, "mild": 0},
            "plant_consumption": 0
        }
    
    def initialize_forest(self):
        """Initialize the forest with animals"""
        # Add lions
        num_lions = random.randint(1, 2)
        for i in range(num_lions):
            lion = AnimalFactory.create_animal("Lion")
            lion.age = random.randint(1, 5)
            self.forest.append(lion)
        
        # Add rabbits
        num_rabbits = random.randint(5, 12)
        for i in range(num_rabbits):
            rabbit = AnimalFactory.create_animal("Rabbit")
            rabbit.age = random.randint(1, 3)
            self.forest.append(rabbit)
        
        # Add wolves (optional)
        if random.random() < 0.3:
            num_wolves = random.randint(0, 1)
            for i in range(num_wolves):
                wolf = AnimalFactory.create_animal("Wolf")
                wolf.age = random.randint(1, 4)
                self.forest.append(wolf)
        
        # Add deer (optional)
        if random.random() < 0.4:
            num_deer = random.randint(0, 2)
            for i in range(num_deer):
                deer = AnimalFactory.create_animal("Deer")
                deer.age = random.randint(1, 3)
                self.forest.append(deer)
        
        # Assign territories
        for animal in self.forest:
            self.environment.assign_territory(animal)
    
    def simulate_day(self):
        """Simulate one day"""
        self.day += 1
        weather = self.environment.update_weather()
        self.stats["weather_events"][weather.value] += 1
        
        daily_report = [f"\n{'='*50}", f"DAY {self.day} - {self.environment}", f"{'='*50}"]
        
        # Check for random events
        event_reports = self.event_manager.check_events(self)
        daily_report.extend(event_reports)
        
        # Apply weather to all animals
        weather_effects = []
        for animal in self.forest[:]:
            effect = self.environment.apply_weather_effects(animal)
            if effect > 0:
                weather_effects.append(f"{animal.species} {animal.name} gained {effect} energy")
            elif effect < 0:
                weather_effects.append(f"{animal.species} {animal.name} lost {-effect} energy")
        
        if weather_effects:
            daily_report.append("\n🌤️ WEATHER EFFECTS:")
            daily_report.extend(weather_effects)
        
        # Rabbits and deer can eat plants
        herbivores = [a for a in self.forest if isinstance(a, (Rabbit, Deer))]
        for herbivore in herbivores:
            plant_food = self.environment.get_plant_food()
            if plant_food > 0:
                herbivore.eat(plant_food)
                self.stats["plant_consumption"] += plant_food
                daily_report.append(f"🌿 {herbivore.name} ate {plant_food} plants")
        
        # Process daily actions
        new_animals = []
        
        # Shuffle to prevent order bias
        random.shuffle(self.forest)
        
        for animal in self.forest[:]:
            if isinstance(animal, (Lion, Wolf)):
                result, reports = animal.daily_action(self.forest)
                daily_report.extend(reports)
                
                if isinstance(animal, Lion):
                    if result == "hunt_success":
                        self.stats["hunts_successful"] += 1
                    elif result == "hunt_fail":
                        self.stats["hunts_failed"] += 1
                    
            elif isinstance(animal, (Rabbit, Deer)):
                baby, reports = animal.daily_action(self.forest)
                daily_report.extend(reports)
                
                if baby:
                    new_animals.append(baby)
                    if isinstance(baby, Rabbit):
                        self.stats["rabbits_born"] += 1
        
        # Add newborns to forest
        self.forest.extend(new_animals)
        
        # Check for deaths
        alive_animals = []
        for animal in self.forest:
            if animal.is_alive():
                alive_animals.append(animal)
            else:
                self.stats["deaths"] += 1
                death_reason = "old age" if animal.age >= 50 else "starvation"
                
                if death_reason == "starvation":
                    self.stats["starvation_deaths"] += 1
                else:
                    self.stats["old_age_deaths"] += 1
                
                if isinstance(animal, Lion):
                    self.stats["lion_deaths"] = self.stats.get("lion_deaths", 0) + 1
                    daily_report.append(f"💀 {animal.name} the Lion died ({death_reason})")
                elif isinstance(animal, Rabbit):
                    self.stats["rabbit_deaths"] += 1
                    daily_report.append(f"💀 {animal.name} the Rabbit died ({death_reason})")
                elif isinstance(animal, Wolf):
                    daily_report.append(f"💀 {animal.name} the Wolf died ({death_reason})")
                elif isinstance(animal, Deer):
                    daily_report.append(f"💀 {animal.name} the Deer died ({death_reason})")
        
        self.forest = alive_animals
        
        return daily_report
    
    def get_status_dict(self):
        """Get current status as dictionary"""
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        wolves = sum(1 for a in self.forest if isinstance(a, Wolf))
        deer = sum(1 for a in self.forest if isinstance(a, Deer))
        
        return {
            'day': self.day,
            'rabbits': rabbits,
            'lions': lions,
            'wolves': wolves,
            'deer': deer,
            'plants': self.environment.food_available,
            'weather': self.environment.weather.value,
            'season': self.environment.season.value
        }
    
    def get_final_stats(self):
        """Get final statistics as string"""
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        wolves = sum(1 for a in self.forest if isinstance(a, Wolf))
        deer = sum(1 for a in self.forest if isinstance(a, Deer))
        
        stats = f"""
{'='*50}
🏆 FINAL STATISTICS
{'='*50}
Days simulated: {self.day}

Final population:
  🐰 Rabbits: {rabbits}
  🦁 Lions:   {lions}
  🐺 Wolves:  {wolves}
  🦌 Deer:    {deer}

Births:
  🐰 Rabbits born: {self.stats['rabbits_born']}

Deaths:
  💀 Total: {self.stats['deaths']}
  💀 Starvation: {self.stats['starvation_deaths']}
  💀 Old age: {self.stats['old_age_deaths']}

Hunting:
  🎯 Successful: {self.stats['hunts_successful']}
  ❌ Failed: {self.stats['hunts_failed']}
"""
        return stats
    
    def save_simulation(self, filename="simulation_save.pkl"):
        """Save simulation state"""
        with open(filename, 'wb') as f:
            pickle.dump({
                'forest': self.forest,
                'environment': self.environment,
                'day': self.day,
                'stats': self.stats
            }, f)
    
    @classmethod
    def load_simulation(cls, filename="simulation_save.pkl"):
        """Load simulation state"""
        with open(filename, 'rb') as f:
            data = pickle.load(f)
            simulator = cls()
            simulator.forest = data['forest']
            simulator.environment = data['environment']
            simulator.day = data['day']
            simulator.stats = data['stats']
            return simulator

# ==================== MAIN ====================

def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    
    # Create and show GUI
    gui = ForestSimulatorGUI()
    gui.show()
    
    # Initialize forest
    gui.initialize_forest()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()