import random

# Base Animal class
class Animal:
    def __init__(self, name, energy):
        self.name = name  # Animal's name
        self.energy = energy  # Energy level
    
    def move(self):
        # Moving consumes energy
        loss = random.randint(1, 5)
        self.energy -= loss
        return loss
    
    def eat(self):
        # Eating restores energy
        gain = random.randint(5, 10)
        self.energy += gain
        return gain
    
    def is_alive(self):
        return self.energy > 0

# Lion class: can hunt
class Lion(Animal):
    def hunt(self, rabbit):
        # chance to successfully hunt
        if random.random() < 0.5:
            self.energy += rabbit.energy
            return True
        return False

# Rabbit class: can reproduce
class Rabbit(Animal):
    def reproduce(self):
        # chance to give birth
        if random.random() < 0.3:
            new_name = f"Rabbit_{random.randint(100,999)}"
            return Rabbit(new_name, 10)
        return None

# Random lion name generator
def random_lion_name():
    return f"Lion_{random.randint(000,999)}"

# Simulation function
def simulate_forest(days):
    # Initialize forest with random number of lions and rabbits
    forest = []
    for _ in range(random.randint(1,3)):
        forest.append(Lion(random_lion_name(), random.randint(15,25)))
    for _ in range(random.randint(3,6)):
        forest.append(Rabbit(f"Rabbit_{random.randint(000,999)}", 10))
    
    print("Initial Forest:")
    for animal in forest:
        print(f"{animal.name} - Energy: {animal.energy}")
    
    # Daily simulation
    for day in range(1, days + 1):
        print(f"\n=== Day {day} ===")
        
        # Random weather event
        if random.random() < 0.2:
            print("It rained! All animals gained some energy.")
            for a in forest:
                a.energy += random.randint(1,5)
        
        new_animals = []
        for animal in forest[:]:  # iterate over a copy
            if isinstance(animal, Lion):
                rabbits = [a for a in forest if isinstance(a, Rabbit)]
                if rabbits:
                    target = random.choice(rabbits)
                    if animal.hunt(target):
                        forest.remove(target)
                        print(f"{animal.name} hunted {target.name}! Energy: {animal.energy}")
                    else:
                        loss = animal.move()
                        print(f"{animal.name} failed to hunt and moved. Energy lost: {loss}, Energy: {animal.energy}")
                else:
                    loss = animal.move()
                    print(f"{animal.name} found no rabbits and moved. Energy lost: {loss}, Energy: {animal.energy}")
            elif isinstance(animal, Rabbit):
                loss = animal.move()
                print(f"{animal.name} moved. Energy lost: {loss}, Energy: {animal.energy}")
                baby = animal.reproduce()
                if baby:
                    new_animals.append(baby)
                    print(f"{animal.name} gave birth to {baby.name}")
        
        forest.extend(new_animals)
        
        # Remove dead animals
        forest = [a for a in forest if a.is_alive()]
        
        # End of day report
        print(f"Forest status at end of Day {day}:")
        for a in forest:
            print(f"{a.name} - Energy: {a.energy}")
        
        if not any(isinstance(a, Rabbit) for a in forest):
            print("All rabbits are dead, simulation ends!")
            break
        if not any(isinstance(a, Lion) for a in forest):
            print("All lions are dead, rabbits are safe, simulation ends!")
            break

# Run simulation for specified days
simulate_forest(5)