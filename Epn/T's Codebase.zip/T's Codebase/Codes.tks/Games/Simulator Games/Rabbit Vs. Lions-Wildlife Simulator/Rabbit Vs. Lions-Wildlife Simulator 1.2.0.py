import random

# Base Animal class with polymorphism
class Animal:
    def __init__(self, name, energy, species):
        self.name = name
        self.energy = energy
        self.species = species
        self.age = 0
        self.max_energy = 100
    
    def move(self):
        loss = random.randint(1, 5)
        self.energy = max(0, self.energy - loss)
        return loss
    
    def eat(self, food_energy=0):
        if food_energy > 0:
            self.energy = min(self.max_energy, self.energy + food_energy)
        else:
            gain = random.randint(5, 10)
            self.energy = min(self.max_energy, self.energy + gain)
        return gain
    
    def is_alive(self):
        return self.energy > 0 and self.age < 50  # Max age 50 days
    
    def daily_action(self, forest):
        """Polymorphic method - different for each animal type"""
        self.age += 1
        pass
    
    def __str__(self):
        return f"{self.name} ({self.species}) - Energy: {self.energy}, Age: {self.age}"

# Enhanced Lion class with realistic hunting
class Lion(Animal):
    def __init__(self, name, energy):
        super().__init__(name, energy, "Lion")
        self.hunt_success_rate = 0.5
        self.hunger_threshold = 15
        self.pride = None
    
    def daily_action(self, forest):
        rabbits = [a for a in forest if isinstance(a, Rabbit)]
        action_report = []
        
        if rabbits and self.energy < self.hunger_threshold:
            # Hungry lions hunt more aggressively
            target = random.choice(rabbits)
            success = random.random() < (self.hunt_success_rate + 0.2)
            
            if success:
                forest.remove(target)
                self.eat(target.energy)
                action_report.append(f"🦁 {self.name} hunted {target.name}! Energy now: {self.energy}")
                return "hunt_success", action_report
            else:
                loss = self.move()
                action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                return "hunt_fail", action_report
        elif rabbits:
            # Well-fed lions may still hunt occasionally
            if random.random() < 0.3:
                target = random.choice(rabbits)
                if random.random() < self.hunt_success_rate:
                    forest.remove(target)
                    self.eat(target.energy)
                    action_report.append(f"🦁 {self.name} hunted {target.name}! Energy: {self.energy}")
                    return "hunt_success", action_report
                else:
                    loss = self.move()
                    action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                    return "hunt_fail", action_report
            else:
                loss = self.move()
                action_report.append(f"🦁 {self.name} rested. Lost {loss} energy. Energy: {self.energy}")
                return "rest", action_report
        else:
            loss = self.move()
            action_report.append(f"🦁 {self.name} found no prey. Lost {loss} energy. Energy: {self.energy}")
            return "no_prey", action_report

# Enhanced Rabbit class with hiding behavior
class Rabbit(Animal):
    def __init__(self, name, energy):
        super().__init__(name, energy, "Rabbit")
        self.reproduction_rate = 0.3
        self.hidden = False
        self.hiding_spot = None
    
    def daily_action(self, forest):
        action_report = []
        lions_present = any(isinstance(a, Lion) for a in forest)
        
        if lions_present and random.random() < 0.4:
            # Rabbits can hide from lions
            self.hidden = True
            self.hiding_spot = f"spot_{random.randint(1,10)}"
            action_report.append(f"🐰 {self.name} is hiding in {self.hiding_spot}!")
        else:
            self.hidden = False
            self.hiding_spot = None
            loss = self.move()
            action_report.append(f"🐰 {self.name} moved. Lost {loss} energy. Energy: {self.energy}")
        
        # Reproduce only if enough energy and safe
        baby = None
        if self.energy > 15 and random.random() < self.reproduction_rate and not self.hidden:
            baby_energy = random.randint(5, 10)
            baby = Rabbit(f"Rabbit_{random.randint(100,999)}", baby_energy)
            action_report.append(f"🐰 {self.name} gave birth to {baby.name}!")
        
        return baby, action_report

# Environment class with weather and seasons
class Environment:
    def __init__(self, name):
        self.name = name
        self.food_available = 100
        self.weather = "clear"
        self.season = "spring"
        self.day = 0
        self.weather_events = ["clear", "rain", "drought", "storm", "mild"]
        self.seasons = ["spring", "summer", "autumn", "winter"]
    
    def update_weather(self):
        self.day += 1
        
        # Update season every 10 days
        if self.day % 10 == 0:
            season_index = (self.day // 10) % 4
            self.season = self.seasons[season_index]
        
        # Weather probabilities based on season
        if self.season == "spring":
            weights = [0.3, 0.4, 0.1, 0.1, 0.1]
        elif self.season == "summer":
            weights = [0.5, 0.1, 0.3, 0.05, 0.05]
        elif self.season == "autumn":
            weights = [0.3, 0.3, 0.1, 0.2, 0.1]
        else:  # winter
            weights = [0.2, 0.2, 0.1, 0.3, 0.2]
        
        self.weather = random.choices(self.weather_events, weights)[0]
        
        # Update food availability based on season and weather
        if self.season == "spring":
            self.food_available += random.randint(5, 10)
        elif self.season == "summer":
            self.food_available += random.randint(0, 5)
        elif self.season == "autumn":
            self.food_available += random.randint(-5, 10)
        else:  # winter
            self.food_available -= random.randint(5, 15)
        
        self.food_available = max(20, min(200, self.food_available))
        
        return self.weather
    
    def apply_weather_effects(self, animal):
        effect = 0
        if self.weather == "rain":
            effect = random.randint(1, 3)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        elif self.weather == "drought":
            effect = -random.randint(0, 2)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == "storm":
            effect = -random.randint(1, 4)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == "mild":
            effect = random.randint(0, 1)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        
        return effect
    
    def get_plant_food(self):
        # Rabbits can eat plants
        if self.food_available > 0:
            food = min(random.randint(1, 5), self.food_available)
            self.food_available -= food
            return food
        return 0
    
    def __str__(self):
        return f"Weather: {self.weather}, Season: {self.season}, Plants: {self.food_available}"

# Random name generators
def random_lion_name():
    names = ["Simba", "Leo", "Aslan", "Mufasa", "Scar", "Nala", "Kiara", "Kovu", "Vitani", "Zira"]
    return f"{random.choice(names)}_{random.randint(10,99)}"

# Enhanced Forest Simulator with visualization and stats
class ForestSimulator:
    def __init__(self):
        self.forest = []
        self.environment = Environment("Enchanted Forest")
        self.day = 0
        self.stats = {
            "lions_born": 0,
            "rabbits_born": 0,
            "hunts_successful": 0,
            "hunts_failed": 0,
            "deaths": 0,
            "rabbit_deaths": 0,
            "lion_deaths": 0,
            "weather_events": {"clear": 0, "rain": 0, "drought": 0, "storm": 0, "mild": 0},
            "population_history": [],
            "energy_history": []
        }
    
    def initialize_forest(self):
        # More realistic initialization with balanced ecosystem
        num_lions = random.randint(1, 2)
        num_rabbits = random.randint(5, 12)
        
        for i in range(num_lions):
            energy = random.randint(25, 35)
            name = random_lion_name()
            self.forest.append(Lion(name, energy))
        
        for i in range(num_rabbits):
            energy = random.randint(8, 15)
            self.forest.append(Rabbit(f"Rabbit_{100+i}", energy))
        
        print("\n🌳 FOREST INITIALIZED 🌳")
        print("="*50)
        self.visualize_ecosystem()
    
    def simulate_day(self):
        self.day += 1
        weather = self.environment.update_weather()
        self.stats["weather_events"][weather] += 1
        
        daily_report = [f"\n{'='*50}", f"DAY {self.day} - {self.environment}", f"{'='*50}"]
        
        # Apply weather to all animals
        weather_effects = []
        for animal in self.forest[:]:
            effect = self.environment.apply_weather_effects(animal)
            if effect > 0:
                weather_effects.append(f"{animal.species} {animal.name} gained {effect} energy from weather")
            elif effect < 0:
                weather_effects.append(f"{animal.species} {animal.name} lost {-effect} energy from weather")
        
        if weather_effects:
            daily_report.append("\n🌤️ WEATHER EFFECTS:")
            daily_report.extend(weather_effects)
        
        # Rabbits can eat plants
        rabbits = [a for a in self.forest if isinstance(a, Rabbit)]
        for rabbit in rabbits[:]:
            plant_food = self.environment.get_plant_food()
            if plant_food > 0:
                rabbit.eat(plant_food)
                daily_report.append(f"🐰 {rabbit.name} ate {plant_food} plants. Energy: {rabbit.energy}")
        
        # Process daily actions
        new_animals = []
        hunt_results = []
        
        for animal in self.forest[:]:
            if isinstance(animal, Lion):
                result, reports = animal.daily_action(self.forest)
                daily_report.extend(reports)
                
                if result == "hunt_success":
                    self.stats["hunts_successful"] += 1
                elif result == "hunt_fail":
                    self.stats["hunts_failed"] += 1
                    
            elif isinstance(animal, Rabbit):
                baby, reports = animal.daily_action(self.forest)
                daily_report.extend(reports)
                
                if baby:
                    new_animals.append(baby)
                    self.stats["rabbits_born"] += 1
        
        # Add newborns to forest
        self.forest.extend(new_animals)
        
        # Check for deaths
        alive_animals = []
        for animal in self.forest:
            if animal.is_alive():
                alive_animals.append(animal)
            else:
                self.stats["deaths"] += 1
                if isinstance(animal, Lion):
                    self.stats["lion_deaths"] += 1
                    daily_report.append(f"💀 {animal.name} the Lion has died at age {animal.age}")
                else:
                    self.stats["rabbit_deaths"] += 1
                    daily_report.append(f"💀 {animal.name} the Rabbit has died at age {animal.age}")
        
        self.forest = alive_animals
        
        # Record history
        self.record_history()
        
        return daily_report
    
    def record_history(self):
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        self.stats["population_history"].append((self.day, rabbits, lions))
        self.stats["energy_history"].append(sum(a.energy for a in self.forest))
    
    def visualize_ecosystem(self):
        rabbit_count = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lion_count = sum(1 for a in self.forest if isinstance(a, Lion))
        total_energy = sum(a.energy for a in self.forest)
        
        print("\n" + "🌳" * 15)
        print("FOREST ECOSYSTEM STATUS")
        print("🌳" * 15)
        print(f"🐰 Rabbits: {'🐰' * min(rabbit_count, 20)} ({rabbit_count})")
        print(f"🦁 Lions:   {'🦁' * min(lion_count, 10)} ({lion_count})")
        print(f"🌤️ Weather: {self.environment.weather}")
        print(f"🌿 Season:  {self.environment.season}")
        print(f"🌱 Plants:  {'🌿' * (self.environment.food_available // 10)} ({self.environment.food_available})")
        print(f"⚡ Total Energy: {total_energy}")
        print("🌳" * 15)
    
    def print_status(self):
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        total_energy = sum(a.energy for a in self.forest)
        
        print(f"\n📊 STATUS REPORT - Day {self.day}")
        print("-" * 40)
        print(f"Population: {len(self.forest)} total")
        print(f"  🐰 Rabbits: {rabbits}")
        print(f"  🦁 Lions:   {lions}")
        print(f"  ⚡ Avg Energy: {total_energy/len(self.forest):.1f}" if self.forest else "  ⚡ No animals")
        print(f"  🌱 Plants available: {self.environment.food_available}")
    
    def print_detailed_animal_status(self):
        if not self.forest:
            print("The forest is empty.")
            return
        
        print(f"\n📋 DETAILED ANIMAL STATUS - Day {self.day}")
        print("-" * 50)
        
        # Group by species
        lions = [a for a in self.forest if isinstance(a, Lion)]
        rabbits = [a for a in self.forest if isinstance(a, Rabbit)]
        
        if lions:
            print("🦁 LIONS:")
            for lion in sorted(lions, key=lambda x: x.energy, reverse=True):
                print(f"  {lion}")
        
        if rabbits:
            print("\n🐰 RABBITS:")
            for rabbit in sorted(rabbits, key=lambda x: x.energy, reverse=True):
                hidden_status = " (hiding)" if rabbit.hidden else ""
                print(f"  {rabbit}{hidden_status}")
    
    def print_final_stats(self):
        print("\n" + "🎯" * 25)
        print("FINAL SIMULATION STATISTICS")
        print("🎯" * 25)
        print(f"Days simulated: {self.day}")
        print(f"Final population: {len(self.forest)}")
        
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        print(f"  🐰 Rabbits: {rabbits}")
        print(f"  🦁 Lions:   {lions}")
        
        print(f"\n📈 LIFECYCLE STATISTICS:")
        print(f"  🐰 Rabbits born: {self.stats['rabbits_born']}")
        print(f"  🦁 Lions born:   {self.stats['lions_born']}")
        print(f"  💀 Total deaths:  {self.stats['deaths']}")
        print(f"    - Rabbit deaths: {self.stats['rabbit_deaths']}")
        print(f"    - Lion deaths:   {self.stats['lion_deaths']}")
        
        print(f"\n🦁 HUNTING STATISTICS:")
        total_hunts = self.stats['hunts_successful'] + self.stats['hunts_failed']
        if total_hunts > 0:
            success_rate = (self.stats['hunts_successful'] / total_hunts) * 100
            print(f"  Successful hunts: {self.stats['hunts_successful']}")
            print(f"  Failed hunts:      {self.stats['hunts_failed']}")
            print(f"  Success rate:      {success_rate:.1f}%")
        
        print(f"\n🌤️ WEATHER SUMMARY:")
        for weather, count in self.stats["weather_events"].items():
            if count > 0:
                percentage = (count / self.day) * 100
                print(f"  {weather.capitalize()}: {count} days ({percentage:.1f}%)")
        
        # Population trend
        if self.stats["population_history"]:
            print(f"\n📊 POPULATION TREND:")
            start_rabbits = self.stats["population_history"][0][1]
            start_lions = self.stats["population_history"][0][2]
            end_rabbits = self.stats["population_history"][-1][1]
            end_lions = self.stats["population_history"][-1][2]
            
            rabbit_change = end_rabbits - start_rabbits
            lion_change = end_lions - start_lions
            
            print(f"  Rabbits: {start_rabbits} → {end_rabbits} ({'+' if rabbit_change > 0 else ''}{rabbit_change})")
            print(f"  Lions:   {start_lions} → {end_lions} ({'+' if lion_change > 0 else ''}{lion_change})")
    
    def run_simulation(self, days):
        print("\n" + "🌟" * 20)
        print("RABBIT VS LIONS: WILDLIFE SIMULATOR")
        print("🌟" * 20)
        
        self.initialize_forest()
        
        for day in range(days):
            if not self.forest:
                print("\n💀 The forest has become silent... All animals are dead.")
                break
            
            daily_report = self.simulate_day()
            for line in daily_report:
                print(line)
            
            # Visualize every 5 days
            if self.day % 5 == 0:
                self.visualize_ecosystem()
            
            # Status report every 3 days
            if self.day % 3 == 0:
                self.print_status()
            
            # Check simulation end conditions
            rabbits = [a for a in self.forest if isinstance(a, Rabbit)]
            lions = [a for a in self.forest if isinstance(a, Lion)]
            
            if not rabbits:
                print("\n❌ All rabbits are dead! The lions will starve...")
                print("SIMULATION ENDED - Rabbits extinct")
                break
            if not lions:
                print("\n✅ All lions are dead! The rabbits are safe...")
                print("SIMULATION ENDED - Lions extinct")
                break
            
            # Add small delay for readability (optional)
            # import time; time.sleep(0.5)
        
        self.print_final_stats()
        
        # Final visualization
        if self.forest:
            print("\n🎉 FINAL ECOSYSTEM STATE:")
            self.visualize_ecosystem()
            self.print_detailed_animal_status()

# Main execution
if __name__ == "__main__":
    # Create and run simulator
    simulator = ForestSimulator()
    
    # Run for specified number of days
    simulator.run_simulation(30)
    
    # You can also run multiple simulations to see different outcomes
    print("\n" + "="*60)
    print("TIP: Run the simulation multiple times to see different outcomes!")
    print("="*60)