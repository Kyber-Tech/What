import random
import json
import pickle
import xml.etree.ElementTree as ET
import tomllib  # Python 3.11+ for TOML
import msgpack
import bson
import hjson
import yaml
from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Type
import sys
import types
import importlib.util
import traceback
from dataclasses import dataclass, asdict
from datetime import datetime
import socket
import threading
import time
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                               QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                               QSpinBox, QGroupBox, QGridLayout, QProgressBar,
                               QTabWidget, QTableWidget, QTableWidgetItem,
                               QHeaderView, QComboBox, QFileDialog, QMessageBox,
                               QSplitter, QFrame, QCheckBox, QLineEdit,
                               QDialog, QDialogButtonBox, QListWidget, QListWidgetItem,
                               QScrollArea, QFormLayout, QSlider, QDoubleSpinBox,
                               QRadioButton, QButtonGroup, QTreeWidget, QTreeWidgetItem,
                               QMenu, QMenuBar, QStatusBar, QToolBar, QAction,
                               QInputDialog, QColorDialog, QFontDialog)
from PySide6.QtCore import QTimer, Qt, Signal, QObject, QThread, QDateTime, QByteArray, QDataStream, QIODevice
from PySide6.QtNetwork import QTcpServer, QTcpSocket, QHostAddress
from PySide6.QtGui import QFont, QColor, QPalette, QIcon, QPixmap, QPainter, QBrush, QPen

# ==================== ENUMS AND CONSTANTS ====================

class Season(Enum):
    SPRING = "spring"
    SUMMER = "summer"
    AUTUMN = "autumn"
    WINTER = "winter"

class Weather(Enum):
    CLEAR = "clear"
    RAIN = "rain"
    DROUGHT = "drought"
    STORM = "storm"
    MILD = "mild"

class DietType(Enum):
    CARNIVORE = "carnivore"
    HERBIVORE = "herbivore"
    OMNIVORE = "omnivore"

class OutputFormat(Enum):
    JSON = "json"
    HJSON = "hjson"
    MESSAGEPACK = "msgpack"
    BSON = "bson"
    XML = "xml"
    TOML = "toml"
    YAML = "yaml"
    PICKLE = "pickle"

class AchievementRarity(Enum):
    COMMON = "Common"
    UNCOMMON = "Uncommon"
    RARE = "Rare"
    EPIC = "Epic"
    LEGENDARY = "Legendary"

class GameMode(Enum):
    SANDBOX = "Sandbox"
    SCENARIO = "Scenario"
    MULTIPLAYER = "Multiplayer"
    CHALLENGE = "Challenge"

# ==================== ACHIEVEMENT SYSTEM ====================

@dataclass
class Achievement:
    """Represents an achievement that can be unlocked"""
    id: str
    name: str
    description: str
    icon: str
    rarity: AchievementRarity
    condition: str  # Python expression to evaluate
    progress_max: Optional[int] = None
    secret: bool = False
    unlocked: bool = False
    progress: int = 0
    unlocked_at: Optional[int] = None

class AchievementManager:
    """Manages achievements and tracks progress"""
    
    def __init__(self):
        self.achievements: Dict[str, Achievement] = {}
        self.unlocked_achievements: List[str] = []
        self.listeners = []
        self._init_default_achievements()
    
    def _init_default_achievements(self):
        """Initialize default achievements"""
        default_achievements = [
            Achievement(
                id="first_step",
                name="First Steps",
                description="Run your first simulation day",
                icon="👣",
                rarity=AchievementRarity.COMMON,
                condition="day >= 1"
            ),
            Achievement(
                id="rabbit_king",
                name="Rabbit King",
                description="Have 20 or more rabbits at once",
                icon="👑",
                rarity=AchievementRarity.UNCOMMON,
                condition="rabbits >= 20"
            ),
            Achievement(
                id="lion_tamer",
                name="Lion Tamer",
                description="Have 5 or more lions at once",
                icon="🦁",
                rarity=AchievementRarity.UNCOMMON,
                condition="lions >= 5"
            ),
            Achievement(
                id="perfect_balance",
                name="Perfect Balance",
                description="Have equal number of lions and rabbits",
                icon="⚖️",
                rarity=AchievementRarity.RARE,
                condition="lions == rabbits and lions > 0"
            ),
            Achievement(
                id="apocalypse",
                name="Apocalypse",
                description="Wipe out all animals",
                icon="💀",
                rarity=AchievementRarity.RARE,
                condition="total == 0 and day > 10",
                secret=True
            ),
            Achievement(
                id="survivor",
                name="Survivor",
                description="Reach day 100",
                icon="🏆",
                rarity=AchievementRarity.RARE,
                condition="day >= 100"
            ),
            Achievement(
                id="genetic_master",
                name="Genetic Master",
                description="Have an animal with all traits above 1.8",
                icon="🧬",
                rarity=AchievementRarity.EPIC,
                condition="has_super_animal"
            ),
            Achievement(
                id="mod_master",
                name="Mod Master",
                description="Load and play with 5 different mods",
                icon="📦",
                rarity=AchievementRarity.UNCOMMON,
                condition="mods_loaded >= 5",
                progress_max=5
            ),
            Achievement(
                id="eternal_forest",
                name="Eternal Forest",
                description="Reach day 365 (1 year)",
                icon="🌳",
                rarity=AchievementRarity.EPIC,
                condition="day >= 365"
            ),
            Achievement(
                id="hunting_party",
                name="Hunting Party",
                description="Successfully hunt 50 animals",
                icon="🎯",
                rarity=AchievementRarity.RARE,
                condition="hunts_successful >= 50",
                progress_max=50
            ),
            Achievement(
                id="mass_extinction",
                name="Mass Extinction",
                description="Kill 30 animals in a single day",
                icon="☄️",
                rarity=AchievementRarity.EPIC,
                condition="deaths_single_day >= 30"
            ),
            Achievement(
                id="legendary_hunter",
                name="Legendary Hunter",
                description="Have a lion with 20+ successful hunts",
                icon="🏹",
                rarity=AchievementRarity.LEGENDARY,
                condition="has_legendary_hunter"
            ),
            Achievement(
                id="mod_creator",
                name="Mod Creator",
                description="Create and load your own mod",
                icon="🔧",
                rarity=AchievementRarity.EPIC,
                condition="has_custom_mod"
            ),
            Achievement(
                id="multiplayer_champion",
                name="Multiplayer Champion",
                description="Win a multiplayer game",
                icon="🌐",
                rarity=AchievementRarity.EPIC,
                condition="multiplayer_win"
            ),
            Achievement(
                id="scenario_master",
                name="Scenario Master",
                description="Complete all scenarios",
                icon="📜",
                rarity=AchievementRarity.LEGENDARY,
                condition="scenarios_completed >= 5",
                progress_max=5
            )
        ]
        
        for ach in default_achievements:
            self.achievements[ach.id] = ach
    
    def check_achievements(self, stats: Dict[str, Any]) -> List[Achievement]:
        """Check which achievements are unlocked based on current stats"""
        newly_unlocked = []
        
        for achievement in self.achievements.values():
            if achievement.unlocked:
                continue
            
            # Evaluate condition safely
            try:
                # Create safe locals for evaluation
                safe_locals = {**stats, 'has_super_animal': self._check_super_animal(stats),
                             'has_legendary_hunter': self._check_legendary_hunter(stats),
                             'has_custom_mod': self._check_custom_mod(stats)}
                
                if achievement.progress_max:
                    # Progress-based achievement
                    current_progress = stats.get(achievement.id + "_progress", 0)
                    achievement.progress = min(current_progress, achievement.progress_max)
                    if achievement.progress >= achievement.progress_max:
                        achievement.unlocked = True
                        achievement.unlocked_at = stats.get('day', 0)
                        newly_unlocked.append(achievement)
                else:
                    # Boolean condition
                    if eval(achievement.condition, {"__builtins__": {}}, safe_locals):
                        achievement.unlocked = True
                        achievement.unlocked_at = stats.get('day', 0)
                        newly_unlocked.append(achievement)
            except Exception as e:
                print(f"Error checking achievement {achievement.id}: {e}")
        
        return newly_unlocked
    
    def _check_super_animal(self, stats):
        """Check if any animal has all traits > 1.8"""
        # This would be implemented to check actual animal traits
        return stats.get('has_super_animal', False)
    
    def _check_legendary_hunter(self, stats):
        """Check if any lion has 20+ hunts"""
        return stats.get('has_legendary_hunter', False)
    
    def _check_custom_mod(self, stats):
        """Check if custom mod is loaded"""
        return stats.get('has_custom_mod', False)
    
    def add_listener(self, callback):
        """Add a listener for achievement unlocks"""
        self.listeners.append(callback)
    
    def notify_unlock(self, achievement):
        """Notify all listeners of achievement unlock"""
        for listener in self.listeners:
            listener(achievement)
    
    def save_progress(self, filename="achievements.json"):
        """Save achievement progress"""
        data = {
            ach.id: {
                'unlocked': ach.unlocked,
                'progress': ach.progress,
                'unlocked_at': ach.unlocked_at
            }
            for ach in self.achievements.values()
        }
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_progress(self, filename="achievements.json"):
        """Load achievement progress"""
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
                for ach_id, values in data.items():
                    if ach_id in self.achievements:
                        self.achievements[ach_id].unlocked = values['unlocked']
                        self.achievements[ach_id].progress = values['progress']
                        self.achievements[ach_id].unlocked_at = values['unlocked_at']
        except FileNotFoundError:
            pass

# ==================== SCENARIO SYSTEM ====================

@dataclass
class ScenarioObjective:
    """Objective for a scenario"""
    type: str  # 'population', 'survival', 'hunt', 'time', 'custom'
    target: Any
    current: Any = 0
    completed: bool = False
    description: str = ""

@dataclass
class Scenario:
    """Represents a playable scenario"""
    id: str
    name: str
    description: str
    difficulty: str  # Easy, Medium, Hard, Expert
    initial_setup: Dict[str, Any]
    objectives: List[ScenarioObjective]
    time_limit: Optional[int] = None  # Days
    special_rules: List[str] = None
    rewards: List[str] = None
    completed: bool = False
    best_time: Optional[int] = None
    
class ScenarioManager:
    """Manages scenarios and tracks progress"""
    
    def __init__(self):
        self.scenarios: Dict[str, Scenario] = {}
        self.current_scenario: Optional[Scenario] = None
        self.completed_scenarios: List[str] = []
        self._init_default_scenarios()
    
    def _init_default_scenarios(self):
        """Initialize default scenarios"""
        scenarios = [
            Scenario(
                id="beginner_forest",
                name="Beginner's Forest",
                description="Learn the basics by maintaining a balanced forest for 30 days",
                difficulty="Easy",
                initial_setup={
                    'lions': 1,
                    'rabbits': 5,
                    'plants': 100
                },
                objectives=[
                    ScenarioObjective('survival', 30, description="Survive for 30 days"),
                    ScenarioObjective('population', {'rabbits': 3}, description="Keep at least 3 rabbits alive")
                ],
                time_limit=30,
                special_rules=["No mods allowed"],
                rewards=["achievement:first_step", "unlock:quick_start"]
            ),
            Scenario(
                id="lion_kingdom",
                name="Lion Kingdom",
                description="Grow your lion pride to 5 members",
                difficulty="Medium",
                initial_setup={
                    'lions': 2,
                    'rabbits': 10,
                    'plants': 150
                },
                objectives=[
                    ScenarioObjective('population', {'lions': 5}, description="Reach 5 lions"),
                    ScenarioObjective('hunt', 20, description="Successfully hunt 20 rabbits")
                ],
                special_rules=["Rabbits reproduce slower"],
                rewards=["achievement:lion_tamer", "unlock:genetics"]
            ),
            Scenario(
                id="apocalypse_survivor",
                name="Apocalypse Survivor",
                description="Survive the great drought with limited resources",
                difficulty="Hard",
                initial_setup={
                    'lions': 1,
                    'rabbits': 3,
                    'plants': 50
                },
                objectives=[
                    ScenarioObjective('survival', 50, description="Survive for 50 days"),
                    ScenarioObjective('population', {'total': 2}, description="Keep at least 2 animals alive")
                ],
                special_rules=["Drought occurs every 5 days", "Plants regrow slowly"],
                rewards=["achievement:survivor", "unlock:hard_mode"]
            ),
            Scenario(
                id="genetic_wonder",
                name="Genetic Wonder",
                description="Breed animals with superior genetics",
                difficulty="Expert",
                initial_setup={
                    'lions': 2,
                    'rabbits': 8,
                    'deer': 2,
                    'plants': 200
                },
                objectives=[
                    ScenarioObjective('custom', {'min_trait': 1.8}, description="Breed an animal with all traits above 1.8"),
                    ScenarioObjective('population', 15, description="Maintain population above 15 for 10 days")
                ],
                time_limit=100,
                special_rules=["Genetics enabled", "Higher mutation rate"],
                rewards=["achievement:genetic_master", "unlock:evolution"]
            ),
            Scenario(
                id="multiplayer_challenge",
                name="Multiplayer Challenge",
                description="Win against another player in a competitive match",
                difficulty="Expert",
                initial_setup={
                    'lions': 1,
                    'rabbits': 5,
                    'plants': 100
                },
                objectives=[
                    ScenarioObjective('custom', {'win': True}, description="Be the winner"),
                    ScenarioObjective('time', 60, description="Complete within 60 days")
                ],
                special_rules=["Multiplayer only", "No pauses"],
                rewards=["achievement:multiplayer_champion", "unlock:ranked_mode"]
            )
        ]
        
        for scenario in scenarios:
            self.scenarios[scenario.id] = scenario
    
    def start_scenario(self, scenario_id: str) -> Optional[Scenario]:
        """Start a scenario"""
        if scenario_id in self.scenarios:
            self.current_scenario = self.scenarios[scenario_id]
            return self.current_scenario
        return None
    
    def check_objectives(self, simulator) -> List[ScenarioObjective]:
        """Check scenario objectives"""
        if not self.current_scenario:
            return []
        
        completed = []
        for objective in self.current_scenario.objectives:
            if objective.completed:
                continue
            
            if objective.type == 'survival':
                if simulator.day >= objective.target:
                    objective.completed = True
                    completed.append(objective)
            
            elif objective.type == 'population':
                if isinstance(objective.target, dict):
                    all_met = True
                    for species, count in objective.target.items():
                        actual = sum(1 for a in simulator.forest 
                                   if a.species.lower() == species.lower())
                        if actual < count:
                            all_met = False
                    if all_met:
                        objective.completed = True
                        completed.append(objective)
                else:
                    if len(simulator.forest) >= objective.target:
                        objective.completed = True
                        completed.append(objective)
            
            elif objective.type == 'hunt':
                if simulator.stats.get('hunts_successful', 0) >= objective.target:
                    objective.completed = True
                    completed.append(objective)
            
            elif objective.type == 'time':
                if objective.current >= objective.target:
                    objective.completed = True
                    completed.append(objective)
                else:
                    objective.current += 1
        
        # Check if all objectives completed
        if all(o.completed for o in self.current_scenario.objectives):
            self.current_scenario.completed = True
            if self.current_scenario.id not in self.completed_scenarios:
                self.completed_scenarios.append(self.current_scenario.id)
            if not self.current_scenario.best_time or simulator.day < self.current_scenario.best_time:
                self.current_scenario.best_time = simulator.day
        
        return completed
    
    def get_scenario_status(self) -> Dict:
        """Get current scenario status"""
        if not self.current_scenario:
            return {}
        
        return {
            'name': self.current_scenario.name,
            'difficulty': self.current_scenario.difficulty,
            'objectives': [
                {
                    'description': obj.description,
                    'completed': obj.completed,
                    'current': obj.current if hasattr(obj, 'current') else None,
                    'target': obj.target
                }
                for obj in self.current_scenario.objectives
            ],
            'time_remaining': (self.current_scenario.time_limit - self.day 
                             if self.current_scenario.time_limit else None)
        }

# ==================== CONFIGURATION EDITOR DIALOG ====================

class ConfigurationEditorDialog(QDialog):
    """Full-featured configuration editor"""
    
    def __init__(self, config: 'Configuration', parent=None):
        super().__init__(parent)
        self.config = config
        self.modified_config = config.config.copy()
        self.setWindowTitle("⚙ Configuration Editor")
        self.setGeometry(200, 200, 900, 700)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Toolbar
        toolbar = QHBoxLayout()
        
        self.save_btn = QPushButton("💾 Save")
        self.save_btn.clicked.connect(self.save_config)
        toolbar.addWidget(self.save_btn)
        
        self.load_btn = QPushButton("📂 Load")
        self.load_btn.clicked.connect(self.load_config)
        toolbar.addWidget(self.load_btn)
        
        self.reset_btn = QPushButton("🔄 Reset to Defaults")
        self.reset_btn.clicked.connect(self.reset_config)
        toolbar.addWidget(self.reset_btn)
        
        toolbar.addStretch()
        
        self.format_combo = QComboBox()
        for fmt in OutputFormat:
            self.format_combo.addItem(fmt.value)
        self.format_combo.setCurrentText(self.config.format.value)
        toolbar.addWidget(QLabel("Format:"))
        toolbar.addWidget(self.format_combo)
        
        layout.addLayout(toolbar)
        
        # Main editor area (tree view for hierarchical editing)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Key", "Value", "Type"])
        self.tree.setColumnWidth(0, 300)
        self.tree.setColumnWidth(1, 400)
        self.tree.setColumnWidth(2, 100)
        self.tree.itemDoubleClicked.connect(self.edit_item)
        
        self.populate_tree(self.modified_config)
        
        layout.addWidget(self.tree)
        
        # Button box
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def populate_tree(self, data: Dict, parent: QTreeWidgetItem = None):
        """Populate tree with configuration data"""
        if parent is None:
            self.tree.clear()
            parent = self.tree.invisibleRootItem()
        
        for key, value in sorted(data.items()):
            if isinstance(value, dict):
                item = QTreeWidgetItem([key, "", "dict"])
                self.populate_tree(value, item)
            elif isinstance(value, list):
                item = QTreeWidgetItem([key, json.dumps(value), "list"])
            elif isinstance(value, bool):
                item = QTreeWidgetItem([key, str(value), "bool"])
            elif isinstance(value, (int, float)):
                item = QTreeWidgetItem([key, str(value), type(value).__name__])
            elif value is None:
                item = QTreeWidgetItem([key, "null", "null"])
            else:
                item = QTreeWidgetItem([key, str(value), "str"])
            
            parent.addChild(item)
    
    def edit_item(self, item: QTreeWidgetItem, column: int):
        """Edit an item's value"""
        if column != 1 or item.text(2) == "dict":
            return
        
        key_path = self.get_key_path(item)
        current_value = item.text(1)
        value_type = item.text(2)
        
        # Create appropriate editor based on type
        if value_type in ["int", "float"]:
            value, ok = QInputDialog.getDouble(self, "Edit Value", 
                                              f"Enter new value for {key_path}:",
                                              float(current_value) if current_value != "null" else 0)
            if ok:
                new_value = str(value)
                item.setText(1, new_value)
                self.update_config_value(key_path, value if value_type == "float" else int(value))
        
        elif value_type == "bool":
            value, ok = QInputDialog.getItem(self, "Edit Value",
                                           f"Select new value for {key_path}:",
                                           ["True", "False"], 0, False)
            if ok:
                item.setText(1, value)
                self.update_config_value(key_path, value == "True")
        
        elif value_type == "list":
            text, ok = QInputDialog.getMultiLineText(self, "Edit List",
                                                     f"Edit list for {key_path} (JSON format):",
                                                     current_value)
            if ok:
                try:
                    value = json.loads(text)
                    item.setText(1, text)
                    self.update_config_value(key_path, value)
                except:
                    QMessageBox.warning(self, "Error", "Invalid JSON format")
        
        else:  # string
            text, ok = QInputDialog.getText(self, "Edit Value",
                                           f"Enter new value for {key_path}:",
                                           QLineEdit.Normal, current_value if current_value != "null" else "")
            if ok:
                item.setText(1, text)
                self.update_config_value(key_path, text)
    
    def get_key_path(self, item: QTreeWidgetItem) -> str:
        """Get dot notation path for an item"""
        path = []
        current = item
        while current:
            if current.text(0):  # Skip root
                path.insert(0, current.text(0))
            current = current.parent()
        return ".".join(path)
    
    def update_config_value(self, key_path: str, value: Any):
        """Update a value in the modified config"""
        keys = key_path.split('.')
        config = self.modified_config
        
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        
        config[keys[-1]] = value
    
    def save_config(self):
        """Save configuration to file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Configuration", "config",
            f"JSON (*.json);;HJSON (*.hjson);;MessagePack (*.msgpack);;BSON (*.bson);;XML (*.xml);;TOML (*.toml);;YAML (*.yaml);;Pickle (*.pkl)"
        )
        
        if file_path:
            format_str = self.format_combo.currentText()
            format_enum = OutputFormat(format_str)
            
            # Update config with tree values
            self.config.config = self.modified_config
            if self.config.save(file_path, format_enum):
                QMessageBox.information(self, "Success", f"Configuration saved to {file_path}")
            else:
                QMessageBox.warning(self, "Error", "Failed to save configuration")
    
    def load_config(self):
        """Load configuration from file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Configuration", "",
            "Config Files (*.json *.hjson *.msgpack *.bson *.xml *.toml *.yaml *.yml);;All Files (*)"
        )
        
        if file_path:
            if self.config.load(file_path):
                self.modified_config = self.config.config.copy()
                self.populate_tree(self.modified_config)
                QMessageBox.information(self, "Success", f"Configuration loaded from {file_path}")
            else:
                QMessageBox.warning(self, "Error", "Failed to load configuration")
    
    def reset_config(self):
        """Reset to default configuration"""
        reply = QMessageBox.question(self, "Confirm Reset",
                                   "Reset all configuration values to defaults?",
                                   QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.config.config = self.config.DEFAULT_CONFIG.copy()
            self.modified_config = self.config.config.copy()
            self.populate_tree(self.modified_config)

# ==================== CONFIGURATION SYSTEM ====================

class Configuration:
    """Flexible configuration system supporting multiple formats"""
    
    DEFAULT_CONFIG = {
        'simulation': {
            'max_days': 1000,
            'default_speed': 5,
            'log_level': 'info',
            'auto_save': True,
            'auto_save_interval': 10
        },
        'mods': {
            'enabled': True,
            'mods_directory': 'mods',
            'auto_load': True,
            'safe_mode': True
        },
        'initial_population': {
            'min_lions': 1,
            'max_lions': 2,
            'min_rabbits': 5,
            'max_rabbits': 12,
            'min_wolves': 0,
            'max_wolves': 2,
            'min_deer': 0,
            'max_deer': 3,
            'wolf_spawn_chance': 0.3,
            'deer_spawn_chance': 0.4
        },
        'animals': {
            'rabbit': {
                'reproduction_rate': 0.3,
                'base_energy': 12,
                'energy_range': [8, 15],
                'max_age': 1000,
                'hunger_threshold': 10,
                'hiding_chance': 0.4
            },
            'lion': {
                'hunt_success_rate': 0.5,
                'base_energy': 30,
                'energy_range': [25, 35],
                'max_age': 2000,
                'hunger_threshold': 15,
                'pack_bonus': 0.1
            },
            'wolf': {
                'hunt_success_rate': 0.4,
                'base_energy': 25,
                'energy_range': [20, 30],
                'max_age': 1500,
                'pack_bonus': 0.15,
                'hunger_threshold': 20
            },
            'deer': {
                'reproduction_rate': 0.2,
                'base_energy': 20,
                'energy_range': [15, 25],
                'max_age': 1800,
                'speed_bonus': 1.5
            }
        },
        'environment': {
            'initial_plants': 100,
            'min_plants': 20,
            'max_plants': 200,
            'territories': [
                {'name': 'Meadow', 'size': 10, 'food_density': 8},
                {'name': 'Forest', 'size': 15, 'food_density': 6},
                {'name': 'River Valley', 'size': 12, 'food_density': 7},
                {'name': 'Hilltop', 'size': 8, 'food_density': 5},
                {'name': 'Deep Woods', 'size': 20, 'food_density': 4}
            ]
        },
        'genetics': {
            'enabled': True,
            'mutation_rate': 0.1,
            'trait_min': 0.3,
            'trait_max': 2.0,
            'inheritance_method': 'average'  # 'average' or 'dominant'
        },
        'events': {
            'enabled': True,
            'forest_fire': {'probability': 0.01, 'enabled': True},
            'disease_outbreak': {'probability': 0.02, 'enabled': True},
            'mating_season': {'probability': 0.1, 'enabled': True},
            'migrating_herd': {'probability': 0.05, 'enabled': True}
        },
        'display': {
            'dark_theme': True,
            'show_genetics': True,
            'refresh_rate': 100,
            'log_lines': 1000
        },
        'achievements': {
            'enabled': True,
            'notifications': True,
            'save_progress': True
        },
        'multiplayer': {
            'default_port': 9999,
            'max_players': 4,
            'timeout': 30,
            'compression': True
        },
        'video_export': {
            'default_fps': 10,
            'quality': 'high',
            'include_ui': True
        }
    }
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self.DEFAULT_CONFIG.copy()
        self.config_path = config_path
        self.format = OutputFormat.JSON
        
        if config_path and Path(config_path).exists():
            self.load(config_path)
    
    def load(self, path: str) -> bool:
        """Load configuration from file (auto-detect format)"""
        try:
            self.config_path = path
            suffix = Path(path).suffix.lower()
            
            # Map file extensions to formats
            format_map = {
                '.json': OutputFormat.JSON,
                '.hjson': OutputFormat.HJSON,
                '.msgpack': OutputFormat.MESSAGEPACK,
                '.bson': OutputFormat.BSON,
                '.xml': OutputFormat.XML,
                '.toml': OutputFormat.TOML,
                '.yaml': OutputFormat.YAML,
                '.yml': OutputFormat.YAML,
                '.pkl': OutputFormat.PICKLE
            }
            
            self.format = format_map.get(suffix, OutputFormat.JSON)
            
            with open(path, 'rb') as f:
                if self.format == OutputFormat.JSON:
                    loaded_config = json.load(f)
                elif self.format == OutputFormat.HJSON:
                    loaded_config = hjson.load(f)
                elif self.format == OutputFormat.MESSAGEPACK:
                    loaded_config = msgpack.unpackb(f.read())
                elif self.format == OutputFormat.BSON:
                    loaded_config = bson.decode(f.read())
                elif self.format == OutputFormat.YAML:
                    loaded_config = yaml.safe_load(f)
                elif self.format == OutputFormat.XML:
                    loaded_config = self._load_xml(f)
                elif self.format == OutputFormat.TOML:
                    loaded_config = tomllib.load(f)
                elif self.format == OutputFormat.PICKLE:
                    loaded_config = pickle.load(f)
            
            # Merge with defaults
            self.config = self._merge_configs(self.DEFAULT_CONFIG, loaded_config)
            return True
            
        except Exception as e:
            print(f"Error loading config: {e}")
            traceback.print_exc()
            return False
    
    def save(self, path: str, format: OutputFormat = OutputFormat.JSON) -> bool:
        """Save configuration to file"""
        try:
            suffix = format.value
            if not path.endswith(f'.{suffix}'):
                path = f"{path}.{suffix}"
            
            with open(path, 'wb') as f:
                if format == OutputFormat.JSON:
                    json.dump(self.config, f, indent=2)
                elif format == OutputFormat.HJSON:
                    hjson.dump(self.config, f, indent=2)
                elif format == OutputFormat.MESSAGEPACK:
                    f.write(msgpack.packb(self.config))
                elif format == OutputFormat.BSON:
                    f.write(bson.encode(self.config))
                elif format == OutputFormat.YAML:
                    yaml.dump(self.config, f)
                elif format == OutputFormat.XML:
                    f.write(self._save_xml())
                elif format == OutputFormat.TOML:
                    self._save_toml(f)
                elif format == OutputFormat.PICKLE:
                    pickle.dump(self.config, f)
            
            self.format = format
            self.config_path = path
            return True
            
        except Exception as e:
            print(f"Error saving config: {e}")
            traceback.print_exc()
            return False
    
    def _load_xml(self, file) -> Dict:
        """Load XML configuration"""
        tree = ET.parse(file)
        root = tree.getroot()
        return self._xml_to_dict(root)
    
    def _xml_to_dict(self, element) -> Dict:
        """Convert XML element to dictionary"""
        result = {}
        for child in element:
            if len(child):
                result[child.tag] = self._xml_to_dict(child)
            else:
                text = child.text
                if text is None:
                    result[child.tag] = None
                elif text.isdigit():
                    result[child.tag] = int(text)
                elif text.replace('.', '').isdigit():
                    result[child.tag] = float(text)
                elif text.lower() in ['true', 'false']:
                    result[child.tag] = text.lower() == 'true'
                else:
                    result[child.tag] = text
        return result
    
    def _save_xml(self) -> bytes:
        """Save configuration as XML"""
        root = ET.Element("configuration")
        self._dict_to_xml(root, self.config)
        tree = ET.ElementTree(root)
        import io
        buffer = io.BytesIO()
        tree.write(buffer, encoding='utf-8', xml_declaration=True)
        return buffer.getvalue()
    
    def _dict_to_xml(self, parent, data: Dict):
        """Convert dictionary to XML elements"""
        for key, value in data.items():
            if isinstance(value, dict):
                elem = ET.SubElement(parent, key)
                self._dict_to_xml(elem, value)
            else:
                elem = ET.SubElement(parent, key)
                elem.text = str(value)
    
    def _save_toml(self, file):
        """Save TOML configuration"""
        try:
            import toml
            toml.dump(self.config, file)
        except ImportError:
            import tomli_w
            tomli_w.dump(self.config, file)
    
    def _merge_configs(self, default: Dict, custom: Dict) -> Dict:
        """Recursively merge configurations"""
        result = default.copy()
        
        for key, value in custom.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        
        return result
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value using dot notation"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value using dot notation"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value

# ==================== GENETIC TRAITS ====================

class GeneticTraits:
    """Genetic traits that can be inherited and evolve"""
    
    def __init__(self, config: Configuration, parent1=None, parent2=None):
        self.config = config
        
        if parent1 and parent2 and config.get('genetics.enabled', True):
            # Inherit from parents with mutation
            self.speed = self._inherit_trait(parent1.speed, parent2.speed)
            self.strength = self._inherit_trait(parent1.strength, parent2.strength)
            self.fertility = self._inherit_trait(parent1.fertility, parent2.fertility)
            self.longevity = self._inherit_trait(parent1.longevity, parent2.longevity)
            self.metabolism = self._inherit_trait(parent1.metabolism, parent2.metabolism)
        else:
            # Random initial traits
            self.speed = random.uniform(0.5, 1.5)
            self.strength = random.uniform(0.5, 1.5)
            self.fertility = random.uniform(0.5, 1.5)
            self.longevity = random.uniform(0.5, 1.5)
            self.metabolism = random.uniform(0.5, 1.5)
    
    def _inherit_trait(self, trait1, trait2):
        """Inherit trait with mutation"""
        inheritance = self.config.get('genetics.inheritance_method', 'average')
        
        if inheritance == 'average':
            trait = (trait1 + trait2) / 2
        else:  # dominant
            trait = max(trait1, trait2)
        
        # Mutation
        if random.random() < self.config.get('genetics.mutation_rate', 0.1):
            trait *= random.uniform(0.8, 1.2)
        
        # Keep within bounds
        trait_min = self.config.get('genetics.trait_min', 0.3)
        trait_max = self.config.get('genetics.trait_max', 2.0)
        return max(trait_min, min(trait_max, trait))
    
    def to_dict(self):
        return {
            'speed': round(self.speed, 2),
            'strength': round(self.strength, 2),
            'fertility': round(self.fertility, 2),
            'longevity': round(self.longevity, 2),
            'metabolism': round(self.metabolism, 2)
        }

# ==================== ABSTRACT BASE CLASSES ====================

class Animal(ABC):
    """Abstract base class for all animals"""
    
    def __init__(self, name, energy, species, config: Configuration):
        self.name = name
        self.energy = energy
        self.species = species
        self.age = 0
        self.max_energy = 100
        self.days_since_last_meal = 0
        self.config = config
        self.genes = GeneticTraits(config)
        self.territory = None
        self.home_range = []
        self.diet_type = DietType.CARNIVORE  # Default, overridden by subclasses
    
    def move(self):
        loss = int(random.randint(1, 5) * self.genes.metabolism)
        self.energy = max(0, self.energy - loss)
        return loss
    
    def eat(self, food_energy=0):
        if food_energy > 0:
            gain = food_energy
            self.energy = min(self.max_energy, self.energy + food_energy)
            self.days_since_last_meal = 0
        else:
            gain = random.randint(5, 10)
            self.energy = min(self.max_energy, self.energy + gain)
            self.days_since_last_meal = 0
        return gain
    
    def is_alive(self):
        # Die from starvation if no food for 5 days
        if self.days_since_last_meal > 5:
            return False
        # Max age from config, influenced by genetics
        species_config = self.config.get(f'animals.{self.species.lower()}', {})
        base_max_age = species_config.get('max_age', 1000)
        max_age = int(base_max_age * self.genes.longevity)
        return self.energy > 0 and self.age < max_age
    
    @abstractmethod
    def daily_action(self, forest):
        """Polymorphic method - different for each animal type"""
        self.age += 1
        self.days_since_last_meal += 1
        pass
    
    @abstractmethod
    def reproduce(self, partner=None):
        """Reproduction behavior"""
        pass
    
    def __str__(self):
        return f"{self.name} ({self.species}) - Energy: {self.energy}, Age: {self.age}"

# ==================== TERRITORY SYSTEM ====================

class Territory:
    """Territory that animals can claim and defend"""
    
    def __init__(self, name, size, food_density, config: Configuration):
        self.name = name
        self.size = size
        self.food_density = food_density
        self.occupants = []
        self.resources = size * food_density
        self.owner = None  # Alpha animal that owns the territory
        self.config = config
    
    def add_occupant(self, animal):
        if animal not in self.occupants:
            self.occupants.append(animal)
            animal.territory = self
    
    def remove_occupant(self, animal):
        if animal in self.occupants:
            self.occupants.remove(animal)
            animal.territory = None
            if self.owner == animal:
                self.owner = None
    
    def claim(self, animal):
        """Claim territory (if strong enough)"""
        if self.owner is None:
            self.owner = animal
            return True
        elif animal.genes.strength > self.owner.genes.strength:
            # Challenge existing owner
            self.owner = animal
            return True
        return False
    
    def regenerate_resources(self, season):
        """Regenerate resources based on season"""
        season_multiplier = {
            Season.SPRING: 1.5,
            Season.SUMMER: 1.2,
            Season.AUTUMN: 1.0,
            Season.WINTER: 0.5
        }
        self.resources = min(self.size * self.food_density * 2,
                           self.resources + self.size * season_multiplier[season])

# ==================== NATIVE ANIMAL CLASSES ====================

class Lion(Animal):
    """Lion class with pack behavior"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Lion", config)
        species_config = config.get('animals.lion', {})
        self.hunt_success_rate = species_config.get('hunt_success_rate', 0.5) * self.genes.strength
        self.hunger_threshold = species_config.get('hunger_threshold', 15)
        self.pride = []
        self.hunts_successful = 0
        self.hunts_failed = 0
        self.pack_size = 1
        self.diet_type = DietType.CARNIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        prey = [a for a in forest if a.diet_type in [DietType.HERBIVORE, DietType.OMNIVORE]]
        action_report = []
        
        # Update pack size (lions in same territory)
        if self.territory:
            self.pack_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Lion))
        
        # Hunting bonus from pack
        pack_bonus = min(0.3, self.pack_size * self.config.get('animals.lion.pack_bonus', 0.1))
        
        if prey and self.energy < self.hunger_threshold:
            # Hungry lions hunt more aggressively
            target = random.choice(prey)
            success = random.random() < (self.hunt_success_rate + pack_bonus)
            
            if success:
                forest.remove(target)
                self.eat(target.energy)
                self.hunts_successful += 1
                action_report.append(f"🦁 {self.name} hunted {target.name}! Energy now: {self.energy}")
                return "hunt_success", action_report
            else:
                loss = self.move()
                self.hunts_failed += 1
                action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                return "hunt_fail", action_report
        elif prey:
            # Well-fed lions may still hunt occasionally
            if random.random() < 0.3:
                target = random.choice(prey)
                if random.random() < (self.hunt_success_rate + pack_bonus):
                    forest.remove(target)
                    self.eat(target.energy)
                    self.hunts_successful += 1
                    action_report.append(f"🦁 {self.name} hunted {target.name}! Energy: {self.energy}")
                    return "hunt_success", action_report
                else:
                    loss = self.move()
                    self.hunts_failed += 1
                    action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                    return "hunt_fail", action_report
            else:
                loss = self.move()
                action_report.append(f"🦁 {self.name} rested. Lost {loss} energy. Energy: {self.energy}")
                return "rest", action_report
        else:
            loss = self.move()
            action_report.append(f"🦁 {self.name} found no prey. Lost {loss} energy. Energy: {self.energy}")
            return "no_prey", action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Lion):
            cub = Lion(f"Cub_{random.randint(100,999)}", 
                      random.randint(15, 25), self.config)
            cub.genes = GeneticTraits(self.config, self.genes, partner.genes)
            cub.age = 0
            return [cub]
        return None

class Rabbit(Animal):
    """Rabbit class with hiding behavior"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Rabbit", config)
        species_config = config.get('animals.rabbit', {})
        self.reproduction_rate = species_config.get('reproduction_rate', 0.3) * self.genes.fertility
        self.hidden = False
        self.hiding_spot = None
        self.children_born = 0
        self.herd_size = 1
        self.hiding_chance = species_config.get('hiding_chance', 0.4)
        self.diet_type = DietType.HERBIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        action_report = []
        predators = [a for a in forest if a.diet_type in [DietType.CARNIVORE, DietType.OMNIVORE]]
        
        # Update herd size (rabbits in same territory)
        if self.territory:
            self.herd_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Rabbit))
        
        # Safety in numbers - less likely to hide in large herds
        hiding_chance = self.hiding_chance / max(1, self.herd_size * 0.5)
        
        if predators and random.random() < hiding_chance:
            # Rabbits can hide from predators
            self.hidden = True
            self.hiding_spot = f"spot_{random.randint(1,10)}"
            action_report.append(f"🐰 {self.name} is hiding in {self.hiding_spot}!")
        else:
            self.hidden = False
            self.hiding_spot = None
            loss = self.move()
            action_report.append(f"🐰 {self.name} moved. Lost {loss} energy. Energy: {self.energy}")
        
        # Eat plants
        if self.territory and self.territory.resources > 0 and not self.hidden:
            food = min(5, self.territory.resources)
            self.territory.resources -= food
            self.eat(food)
            action_report.append(f"🐰 {self.name} ate {food} plants.")
        
        # Reproduce only if enough energy and safe
        baby = None
        if self.energy > 15 and random.random() < self.reproduction_rate and not self.hidden:
            baby_energy = random.randint(5, 10)
            baby = Rabbit(f"Rabbit_{random.randint(100,999)}", baby_energy, self.config)
            baby.genes = GeneticTraits(self.config, self.genes, self.genes)
            baby.age = 0
            self.children_born += 1
            action_report.append(f"🐰 {self.name} gave birth to {baby.name}!")
        
        return baby, action_report
    
    def reproduce(self, partner=None):
        if random.random() < self.reproduction_rate:
            baby = Rabbit(f"Rabbit_{random.randint(100,999)}", 
                         random.randint(5, 10), self.config)
            if partner and isinstance(partner, Rabbit):
                baby.genes = GeneticTraits(self.config, self.genes, partner.genes)
            else:
                baby.genes = GeneticTraits(self.config, self.genes, self.genes)
            return [baby]
        return None

class Wolf(Animal):
    """Wolf class - hunts in packs"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Wolf", config)
        species_config = config.get('animals.wolf', {})
        self.pack_size = 1
        self.pack_bonus = species_config.get('pack_bonus', 0.15)
        self.hunt_success_rate = species_config.get('hunt_success_rate', 0.4) * self.genes.strength
        self.hunger_threshold = species_config.get('hunger_threshold', 20)
        self.hunts_successful = 0
        self.hunts_failed = 0
        self.diet_type = DietType.CARNIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        prey = [a for a in forest if a.diet_type in [DietType.HERBIVORE, DietType.OMNIVORE]]
        action_report = []
        
        # Update pack size
        if self.territory:
            self.pack_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Wolf))
        
        pack_bonus = min(0.5, self.pack_size * self.pack_bonus)
        
        if prey and self.energy < self.hunger_threshold:
            target = random.choice(prey)
            success = random.random() < (self.hunt_success_rate + pack_bonus)
            
            if success:
                forest.remove(target)
                self.eat(target.energy)
                self.hunts_successful += 1
                action_report.append(f"🐺 {self.name} hunted {target.name}! Energy: {self.energy}")
            else:
                loss = self.move()
                self.hunts_failed += 1
                action_report.append(f"🐺 {self.name} failed to hunt. Lost {loss} energy")
        else:
            loss = self.move()
            action_report.append(f"🐺 {self.name} roamed. Lost {loss} energy")
        
        return None, action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Wolf):
            pup = Wolf(f"Wolf_{random.randint(100,999)}", random.randint(10, 20), self.config)
            pup.genes = GeneticTraits(self.config, self.genes, partner.genes)
            return [pup]
        return None

class Deer(Animal):
    """Deer class - fast herbivore"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Deer", config)
        species_config = config.get('animals.deer', {})
        self.herd_size = 1
        self.speed_bonus = species_config.get('speed_bonus', 1.5) * self.genes.speed
        self.reproduction_rate = species_config.get('reproduction_rate', 0.2) * self.genes.fertility
        self.diet_type = DietType.HERBIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        action_report = []
        
        # Update herd size
        if self.territory:
            self.herd_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Deer))
        
        # Deer are fast - they move more but can escape better
        loss = self.move()
        action_report.append(f"🦌 {self.name} grazed. Lost {loss} energy")
        
        # Eat plants
        if self.territory and self.territory.resources > 0:
            food = min(8, self.territory.resources)
            self.territory.resources -= food
            self.eat(food)
            action_report.append(f"🦌 {self.name} ate {food} plants.")
        
        # Reproduction
        baby = None
        if self.energy > 25 and random.random() < self.reproduction_rate:
            baby = Deer(f"Deer_{random.randint(100,999)}", random.randint(10, 15), self.config)
            baby.genes = GeneticTraits(self.config, self.genes, self.genes)
            action_report.append(f"🦌 {self.name} gave birth to a fawn!")
        
        return baby, action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Deer):
            fawn = Deer(f"Deer_{random.randint(100,999)}", random.randint(10, 15), self.config)
            fawn.genes = GeneticTraits(self.config, self.genes, partner.genes)
            return [fawn]
        return None

# ==================== ANIMAL FACTORY ====================

class AnimalFactory:
    """Factory for creating animals (native and modded)"""
    
    _native_classes = {
        "Lion": Lion,
        "Rabbit": Rabbit,
        "Wolf": Wolf,
        "Deer": Deer
    }
    
    _mod_classes = {}
    _mod_configs = {}
    
    @classmethod
    def register_mod_animal(cls, species_id: str, animal_class: Type, mod_data: dict):
        """Register a mod animal class"""
        cls._mod_classes[species_id] = animal_class
        cls._mod_configs[species_id] = mod_data
    
    @classmethod
    def get_available_species(cls) -> List[str]:
        """Get list of all available species"""
        return list(cls._native_classes.keys()) + list(cls._mod_classes.keys())
    
    @classmethod
    def create_animal(cls, species, config: Configuration, name=None, energy=None):
        """Create an animal of the specified species"""
        # Check native classes first
        if species in cls._native_classes:
            animal_class = cls._native_classes[species]
            species_config = config.get(f'animals.{species.lower()}', {})
            
            if name is None:
                if species == "Lion":
                    name = cls._random_lion_name()
                else:
                    name = f"{species}_{random.randint(100,999)}"
            
            if energy is None:
                energy_range = species_config.get('energy_range', [25, 35])
                energy = random.randint(energy_range[0], energy_range[1])
            
            return animal_class(name, energy, config)
        
        # Check mod classes
        elif species in cls._mod_classes:
            animal_class = cls._mod_classes[species]
            mod_data = cls._mod_configs[species]
            
            if name is None:
                name = f"{mod_data['name']}_{random.randint(100,999)}"
            
            if energy is None:
                energy_range = mod_data['base_stats']['energy_range']
                energy = random.randint(energy_range[0], energy_range[1])
            
            return animal_class(name, energy, config)
        
        else:
            raise ValueError(f"Unknown species: {species}")
    
    @classmethod
    def _random_lion_name(cls):
        male_names = ["Leo", "Leon", "Aslan", "Simba", "Mufasa", "Scar", "Kimba"]
        female_names = ["Nala", "Sarabi", "Kiara", "Cleopatra", "Nefertiti", "Zara"]
        all_names = male_names + female_names
        return f"{random.choice(all_names)}_{random.randint(10,99)}"

# ==================== MOD SYSTEM ====================

class ModError(Exception):
    """Exception raised for mod-related errors"""
    pass

class SafeScriptExecutor:
    """Execute mod scripts in a sandboxed environment"""
    
    ALLOWED_MODULES = ['random', 'math', 'itertools']
    FORBIDDEN_KEYWORDS = ['__import__', 'eval', 'exec', 'open', 'file', 'system', 
                         'subprocess', 'os.', 'sys.', 'globals', 'locals']
    
    @classmethod
    def create_safe_globals(cls, animal, forest):
        """Create safe execution environment"""
        safe_globals = {
            'random': random,
            'animal': animal,
            'forest': forest,
            'len': len,
            'range': range,
            'int': int,
            'float': float,
            'str': str,
            'list': list,
            'dict': dict,
            'min': min,
            'max': max,
            'sum': sum,
            'abs': abs,
            'round': round,
            'enumerate': enumerate,
            'zip': zip,
            'sorted': sorted,
            'any': any,
            'all': all
        }
        
        # Add allowed modules
        for module_name in cls.ALLOWED_MODULES:
            try:
                safe_globals[module_name] = __import__(module_name)
            except ImportError:
                pass
        
        return safe_globals
    
    @classmethod
    def validate_script(cls, script):
        """Check script for dangerous operations"""
        if not script:
            return True
            
        for keyword in cls.FORBIDDEN_KEYWORDS:
            if keyword in script:
                raise ModError(f"Forbidden keyword in script: {keyword}")
        
        # Check for dangerous patterns
        dangerous_patterns = ['__', 'exec(', 'eval(', 'open(', 'write(', 'os.', 'sys.']
        for pattern in dangerous_patterns:
            if pattern in script:
                raise ModError(f"Dangerous pattern in script: {pattern}")
        
        return True
    
    @classmethod
    def execute_function(cls, script, func_name, animal, forest, *args, **kwargs):
        """Execute a function from script safely"""
        if not script:
            return None
            
        try:
            # Validate script first
            cls.validate_script(script)
            
            # Create safe globals
            safe_globals = cls.create_safe_globals(animal, forest)
            
            # Compile and execute script
            code = compile(script, '<mod_script>', 'exec')
            exec(code, safe_globals)
            
            # Get function if it exists
            if func_name in safe_globals and callable(safe_globals[func_name]):
                func = safe_globals[func_name]
                # Create bound method if it's a function that expects self
                if func_name == 'special_action':
                    # Bind method to animal instance
                    bound_func = types.MethodType(func, animal)
                    return bound_func(forest, *args, **kwargs)
                return func(animal, forest, *args, **kwargs)
            
            return None
            
        except Exception as e:
            print(f"Error executing mod script: {e}")
            traceback.print_exc()
            return f"❌ Script error: {str(e)}"

@dataclass
class ModInfo:
    """Information about a loaded mod"""
    id: str
    name: str
    file_path: str
    format: OutputFormat
    data: dict
    animal_class: Type = None
    enabled: bool = True
    load_time: float = 0
    error: str = None

class ModLoader:
    """Discovers and loads mod files from multiple formats"""
    
    SUPPORTED_FORMATS = {
        '.yaml': OutputFormat.YAML,
        '.yml': OutputFormat.YAML,
        '.hjson': OutputFormat.HJSON,
        '.msgpack': OutputFormat.MESSAGEPACK,
        '.bson': OutputFormat.BSON,
        '.xml': OutputFormat.XML,
        '.toml': OutputFormat.TOML,
        '.json': OutputFormat.JSON,
        '.pkl': OutputFormat.PICKLE
    }
    
    def __init__(self, mods_directory="mods"):
        self.mods_directory = Path(mods_directory)
        self.mods_directory.mkdir(exist_ok=True)
        self.loaded_mods: Dict[str, ModInfo] = {}
        self.animal_classes: Dict[str, Type] = {}
        self.mod_errors = []
    
    def discover_mods(self):
        """Scan mods directory for supported files"""
        mod_files = []
        for ext in self.SUPPORTED_FORMATS.keys():
            mod_files.extend(self.mods_directory.glob(f"*{ext}"))
        return mod_files
    
    def load_mod(self, filepath: Union[str, Path]) -> Optional[ModInfo]:
        """Load a single mod file (auto-detect format)"""
        filepath = Path(filepath)
        try:
            # Detect format
            ext = filepath.suffix.lower()
            if ext not in self.SUPPORTED_FORMATS:
                raise ModError(f"Unsupported file format: {ext}")
            
            format_type = self.SUPPORTED_FORMATS[ext]
            
            # Parse file
            data = self._parse_file(filepath, format_type)
            
            # Validate mod data
            self._validate_mod_data(data)
            
            # Create mod info
            mod_id = data.get('species_id', data['name'].lower().replace(' ', '_'))
            mod_info = ModInfo(
                id=mod_id,
                name=data['name'],
                file_path=str(filepath),
                format=format_type,
                data=data
            )
            
            self.loaded_mods[mod_id] = mod_info
            return mod_info
            
        except Exception as e:
            error_msg = f"Failed to load mod {filepath.name}: {str(e)}"
            print(error_msg)
            traceback.print_exc()
            self.mod_errors.append((filepath.name, str(e)))
            return None
    
    def _parse_file(self, filepath: Path, format_type: OutputFormat) -> dict:
        """Parse file based on format"""
        with open(filepath, 'rb') as f:
            if format_type == OutputFormat.JSON:
                return json.load(f)
            elif format_type == OutputFormat.HJSON:
                return hjson.load(f)
            elif format_type == OutputFormat.MESSAGEPACK:
                return msgpack.unpackb(f.read())
            elif format_type == OutputFormat.BSON:
                return bson.decode(f.read())
            elif format_type == OutputFormat.YAML:
                return yaml.safe_load(f)
            elif format_type == OutputFormat.XML:
                return self._parse_xml(f)
            elif format_type == OutputFormat.TOML:
                return tomllib.load(f)
            elif format_type == OutputFormat.PICKLE:
                return pickle.load(f)
    
    def _parse_xml(self, file) -> dict:
        """Parse XML to dict"""
        tree = ET.parse(file)
        root = tree.getroot()
        return self._xml_to_dict(root)
    
    def _xml_to_dict(self, element) -> dict:
        """Convert XML element to dictionary"""
        result = {}
        for child in element:
            if len(child):
                result[child.tag] = self._xml_to_dict(child)
            else:
                # Try to convert to appropriate type
                text = child.text
                if text is None:
                    result[child.tag] = None
                elif text.isdigit():
                    result[child.tag] = int(text)
                elif text.replace('.', '').isdigit():
                    result[child.tag] = float(text)
                elif text.lower() in ['true', 'false']:
                    result[child.tag] = text.lower() == 'true'
                else:
                    result[child.tag] = text
        return result
    
    def _validate_mod_data(self, data: dict):
        """Validate mod data has required fields"""
        required_fields = ['name', 'diet_type', 'base_stats']
        
        for field in required_fields:
            if field not in data:
                raise ModError(f"Missing required field: {field}")
        
        # Validate diet type
        if data['diet_type'] not in [dt.value for dt in DietType]:
            raise ModError(f"Invalid diet type: {data['diet_type']}")
        
        # Validate base stats
        base_stats = data['base_stats']
        if 'energy_range' not in base_stats:
            raise ModError("Missing energy_range in base_stats")
        
        # Validate script if present
        if 'special_ability' in data and 'script' in data['special_ability']:
            SafeScriptExecutor.validate_script(data['special_ability']['script'])
    
    def unload_mod(self, mod_id: str):
        """Unload a mod"""
        if mod_id in self.loaded_mods:
            # Remove animal class
            if mod_id in self.animal_classes:
                del self.animal_classes[mod_id]
            # Remove mod info
            del self.loaded_mods[mod_id]
            return True
        return False
    
    def get_all_mods(self) -> List[ModInfo]:
        """Get all loaded mods"""
        return list(self.loaded_mods.values())
    
    def reload_mod(self, mod_id: str) -> Optional[ModInfo]:
        """Reload a mod from its file"""
        if mod_id in self.loaded_mods:
            file_path = self.loaded_mods[mod_id].file_path
            self.unload_mod(mod_id)
            return self.load_mod(file_path)
        return None

class ModAnimalFactory:
    """Creates animal classes from mod definitions"""
    
    @staticmethod
    def create_animal_class(mod_info: ModInfo) -> Type:
        """Dynamically create a new animal class from mod data"""
        
        data = mod_info.data
        class_name = data['name'].replace(' ', '').replace('-', '_')
        diet_type = DietType(data['diet_type'])
        
        # Define the new class
        class ModAnimal(Animal):
            mod_info = mod_info  # Attach mod info to class
            
            def __init__(self, name, energy, config):
                super().__init__(name, energy, data['name'], config)
                
                # Set stats from mod
                self.icon = data.get('icon', '🐾')
                self.diet_type = diet_type
                self.special_ability_cooldown = 0
                self.mod_data = data
                
                # Load base stats
                base_stats = data.get('base_stats', {})
                self.metabolism_rate = base_stats.get('metabolism_rate', 1.0)
                self.base_energy = base_stats.get('base_energy', 30)
                
                # Load behavior stats
                behavior = data.get('behavior', {})
                self.hunt_success_rate = behavior.get('hunt_success_rate', 0.5)
                self.pack_bonus = behavior.get('pack_bonus', 0.0)
                self.hunger_threshold = behavior.get('hunger_threshold', 15)
                self.territorial = behavior.get('territorial', True)
                self.herd_animal = behavior.get('herd_animal', False)
                self.flee_chance = behavior.get('flee_chance', 0.5)
                self.can_fly = behavior.get('can_fly', False)
                self.hibernation = behavior.get('hibernation', False)
                
                # Load reproduction data
                self.reproduction_data = data.get('reproduction', {})
                
                # Load special ability
                self.special_ability_data = data.get('special_ability', {})
                if self.special_ability_data and 'script' in self.special_ability_data:
                    self.ability_script = self.special_ability_data['script']
                    self.ability_name = self.special_ability_data.get('name', 'Special Ability')
                    self.ability_cooldown = self.special_ability_data.get('cooldown', 5)
                else:
                    self.ability_script = None
                    self.ability_name = None
                    self.ability_cooldown = 0
            
            def move(self):
                """Override move with metabolism rate"""
                loss = int(random.randint(1, 5) * self.metabolism_rate)
                self.energy = max(0, self.energy - loss)
                return loss
            
            def daily_action(self, forest):
                """Execute daily behavior based on diet type"""
                super().daily_action(forest)
                action_report = []
                
                # Handle special ability cooldown
                if self.special_ability_cooldown > 0:
                    self.special_ability_cooldown -= 1
                
                # Check for special ability use
                if self.ability_script and self.special_ability_cooldown == 0:
                    ability_result = self.use_special_ability(forest)
                    if ability_result:
                        action_report.append(ability_result)
                
                # Diet-specific behavior
                if self.diet_type == DietType.CARNIVORE:
                    result = self._carnivore_action(forest)
                    if result:
                        action_report.append(result)
                elif self.diet_type == DietType.HERBIVORE:
                    result = self._herbivore_action(forest)
                    if result:
                        action_report.append(result)
                else:  # omnivore
                    result = self._omnivore_action(forest)
                    if result:
                        action_report.append(result)
                
                return None, action_report
            
            def _carnivore_action(self, forest):
                """Carnivore behavior - hunt prey"""
                # Find potential prey (animals that are not this species)
                prey = [a for a in forest 
                       if a.species != self.species and 
                       a.energy < self.energy * 1.2]  # Hunt weaker or similar animals
                
                if prey and self.energy < self.hunger_threshold:
                    target = random.choice(prey)
                    success = random.random() < self.hunt_success_rate
                    
                    if success:
                        forest.remove(target)
                        self.eat(target.energy)
                        return f"{self.icon} {self.name} hunted {target.name}!"
                    else:
                        loss = self.move()
                        return f"{self.icon} {self.name} failed to hunt. Lost {loss} energy."
                
                # If not hunting, just move
                loss = self.move()
                return f"{self.icon} {self.name} roamed. Lost {loss} energy."
            
            def _herbivore_action(self, forest):
                """Herbivore behavior - eat plants and hide"""
                # Check for predators
                predators = [a for a in forest if a.diet_type in [DietType.CARNIVORE, DietType.OMNIVORE]]
                
                if predators and random.random() < self.flee_chance:
                    # Try to hide or flee
                    if self.can_fly:
                        return f"{self.icon} {self.name} flew away from danger!"
                    else:
                        loss = self.move() * 2  # Fleeing costs more energy
                        return f"{self.icon} {self.name} fled from predators! Lost {loss} energy."
                
                # Look for plants in territory
                if self.territory and self.territory.resources > 0:
                    food = min(10, self.territory.resources)
                    self.territory.resources -= food
                    self.eat(food)
                    return f"{self.icon} {self.name} grazed on {food} plants."
                
                # No plants, just move
                loss = self.move()
                return f"{self.icon} {self.name} searched for food. Lost {loss} energy."
            
            def _omnivore_action(self, forest):
                """Omnivore behavior - can do both"""
                # 50% chance to hunt or graze, depending on energy
                if self.energy < self.hunger_threshold:
                    # Hungry - more likely to hunt
                    if random.random() < 0.7:
                        return self._carnivore_action(forest)
                    else:
                        return self._herbivore_action(forest)
                else:
                    # Not hungry - more likely to graze
                    if random.random() < 0.3:
                        return self._carnivore_action(forest)
                    else:
                        return self._herbivore_action(forest)
            
            def use_special_ability(self, forest):
                """Use special ability from script"""
                if not self.ability_script:
                    return None
                
                result = SafeScriptExecutor.execute_function(
                    self.ability_script,
                    'special_action',
                    self,
                    forest
                )
                
                if result:
                    self.special_ability_cooldown = self.ability_cooldown
                
                return result
            
            def reproduce(self, partner=None):
                """Reproduction based on mod settings"""
                if not self.reproduction_data:
                    return None
                
                rate = self.reproduction_data.get('rate', 0.1)
                if random.random() >= rate:
                    return None
                
                # Check energy requirement
                min_energy = self.reproduction_data.get('min_energy', 20)
                if self.energy < min_energy:
                    return None
                
                # Determine offspring count
                offspring_range = self.reproduction_data.get('offspring_count', [1, 1])
                if isinstance(offspring_range, list):
                    count = random.randint(offspring_range[0], offspring_range[1])
                else:
                    count = 1
                
                offspring = []
                for i in range(count):
                    # Create baby
                    energy_range = self.mod_data['base_stats']['energy_range']
                    baby_energy = random.randint(energy_range[0] // 2, energy_range[1] // 2)
                    
                    baby = ModAnimal(
                        f"{self.mod_data['name']}_{random.randint(100,999)}",
                        baby_energy,
                        self.config
                    )
                    
                    # Inherit genes
                    if partner and isinstance(partner, ModAnimal):
                        baby.genes = GeneticTraits(self.config, self.genes, partner.genes)
                    else:
                        baby.genes = GeneticTraits(self.config, self.genes, self.genes)
                    
                    offspring.append(baby)
                
                return offspring
            
            def __str__(self):
                status = f"{self.icon} {self.name} ({self.species})"
                status += f" - Energy: {self.energy}, Age: {self.age}"
                if self.special_ability_cooldown > 0:
                    status += f" [Ability cooldown: {self.special_ability_cooldown}]"
                return status
        
        # Set class name for proper identification
        ModAnimal.__name__ = class_name
        return ModAnimal

# ==================== EVENT SYSTEM ====================

class Event(ABC):
    """Base class for random events"""
    
    def __init__(self, name, config_key, config: Configuration):
        self.name = name
        self.config_key = config_key
        self.config = config
        event_config = config.get(f'events.{config_key}', {})
        self.probability = event_config.get('probability', 0.01)
        self.enabled = event_config.get('enabled', True)
    
    @abstractmethod
    def apply(self, simulator):
        """Apply the event to the simulator"""
        pass
    
    def __str__(self):
        return self.name

class ForestFire(Event):
    """Forest fire event - reduces plants and harms animals"""
    
    def __init__(self, config: Configuration):
        super().__init__("🔥 Forest Fire", 'forest_fire', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Reduce plant food by half
        simulator.environment.food_available = int(simulator.environment.food_available * 0.5)
        
        # Harm all animals
        casualties = []
        for animal in simulator.forest[:]:
            if random.random() < 0.3:  # 30% chance of death/injury
                animal.energy = int(animal.energy * 0.7)
                casualties.append(animal.name)
        
        return f"🔥 FOREST FIRE! Plants halved. {len(casualties)} animals injured."

class DiseaseOutbreak(Event):
    """Disease outbreak - affects specific species"""
    
    def __init__(self, config: Configuration):
        super().__init__("🦠 Disease Outbreak", 'disease_outbreak', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Choose random species from all available (including mods)
        all_species = AnimalFactory.get_available_species()
        if not all_species:
            return None
            
        species = random.choice(all_species)
        casualties = []
        
        for animal in simulator.forest[:]:
            if animal.species == species and random.random() < 0.4:
                simulator.forest.remove(animal)
                casualties.append(animal.name)
        
        return f"🦠 DISEASE OUTBREAK! {len(casualties)} {species}s died."

class MatingSeason(Event):
    """Mating season - boosts reproduction"""
    
    def __init__(self, config: Configuration):
        super().__init__("💕 Mating Season", 'mating_season', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Boost reproduction for one day
        newborns = 0
        for animal in simulator.forest[:]:
            if hasattr(animal, 'reproduction_rate'):
                # Boost reproduction rate temporarily
                original_rate = animal.reproduction_rate
                animal.reproduction_rate *= 2
                
                # Try to reproduce
                offspring = animal.reproduce()
                if offspring:
                    for baby in offspring:
                        simulator.forest.append(baby)
                        newborns += 1
                
                # Restore original rate
                animal.reproduction_rate = original_rate
        
        return f"💕 MATING SEASON! {newborns} babies born today!"

class MigratingHerd(Event):
    """Migrating herd - adds new animals"""
    
    def __init__(self, config: Configuration):
        super().__init__("🦌 Migrating Herd", 'migrating_herd', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Add new animals (could be modded species)
        new_animals = []
        all_species = AnimalFactory.get_available_species()
        herbivores = [s for s in all_species if s in ["Rabbit", "Deer"] or 
                     (s in AnimalFactory._mod_configs and 
                      AnimalFactory._mod_configs[s].get('diet_type') in ['herbivore', 'omnivore'])]
        
        if herbivores:
            for _ in range(random.randint(1, 3)):
                species = random.choice(herbivores)
                try:
                    animal = AnimalFactory.create_animal(species, simulator.config)
                    new_animals.append(animal)
                except:
                    pass
        
        simulator.forest.extend(new_animals)
        names = ", ".join([a.name for a in new_animals])
        return f"🦌 MIGRATING HERD! New arrivals: {names}"

class EventManager:
    """Manages random events in the simulation"""
    
    def __init__(self, config: Configuration):
        self.config = config
        self.events = [
            ForestFire(config),
            DiseaseOutbreak(config),
            MatingSeason(config),
            MigratingHerd(config)
        ]
        self.event_history = []
    
    def check_events(self, simulator):
        """Check and apply random events"""
        if not self.config.get('events.enabled', True):
            return []
            
        reports = []
        for event in self.events:
            if event.enabled and random.random() < event.probability:
                result = event.apply(simulator)
                if result:
                    reports.append(result)
                    self.event_history.append((simulator.day, event.name))
        return reports

# ==================== ENVIRONMENT ====================

class Environment:
    """Environment with seasons and weather"""
    
    def __init__(self, name, config: Configuration):
        self.name = name
        self.config = config
        self.food_available = config.get('environment.initial_plants', 100)
        self.weather = Weather.CLEAR
        self.season = Season.SPRING
        self.day = 0
        self.territories = self._create_territories()
    
    def _create_territories(self):
        """Create territories from config"""
        territories = []
        territory_configs = self.config.get('environment.territories', [])
        
        for t_config in territory_configs:
            territory = Territory(
                t_config['name'],
                t_config['size'],
                t_config['food_density'],
                self.config
            )
            territories.append(territory)
        
        return territories
    
    def update_weather(self):
        self.day += 1
        
        # Update season every 10 days
        if self.day % 10 == 0:
            season_index = (self.day // 10) % 4
            self.season = list(Season)[season_index]
        
        # Weather probabilities based on season
        weights = {
            Season.SPRING: [0.3, 0.4, 0.1, 0.1, 0.1],
            Season.SUMMER: [0.5, 0.1, 0.3, 0.05, 0.05],
            Season.AUTUMN: [0.3, 0.3, 0.1, 0.2, 0.1],
            Season.WINTER: [0.2, 0.2, 0.1, 0.3, 0.2]
        }
        
        self.weather = random.choices(list(Weather), weights[self.season])[0]
        
        # Update food availability
        season_food_modifier = {
            Season.SPRING: 8,
            Season.SUMMER: 3,
            Season.AUTUMN: 2,
            Season.WINTER: -10
        }
        
        weather_food_modifier = {
            Weather.CLEAR: 0,
            Weather.RAIN: 5,
            Weather.DROUGHT: -5,
            Weather.STORM: -3,
            Weather.MILD: 2
        }
        
        self.food_available += season_food_modifier[self.season] + weather_food_modifier[self.weather]
        
        min_plants = self.config.get('environment.min_plants', 20)
        max_plants = self.config.get('environment.max_plants', 200)
        self.food_available = max(min_plants, min(max_plants, self.food_available))
        
        # Regenerate territories
        for territory in self.territories:
            territory.regenerate_resources(self.season)
        
        return self.weather
    
    def apply_weather_effects(self, animal):
        if animal is None:
            return 0
            
        effect = 0
        if self.weather == Weather.RAIN:
            effect = random.randint(1, 3)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        elif self.weather == Weather.DROUGHT:
            effect = -random.randint(0, 2)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == Weather.STORM:
            effect = -random.randint(1, 4)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == Weather.MILD:
            effect = random.randint(0, 1)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        
        return effect
    
    def get_plant_food(self):
        if self.food_available > 0:
            max_food = 3 if self.season == Season.WINTER else 5
            food = min(random.randint(1, max_food), self.food_available)
            self.food_available -= food
            return food
        return 0
    
    def assign_territory(self, animal):
        """Assign animal to a territory"""
        if not animal.territory and hasattr(animal, 'territorial') and animal.territorial:
            # Find territory with space
            available = [t for t in self.territories if len(t.occupants) < t.size]
            if available:
                territory = random.choice(available)
                territory.add_occupant(animal)
                
                # Try to claim territory
                if random.random() < 0.3:  # 30% chance to claim
                    territory.claim(animal)
                
                return territory
        return animal.territory
    
    def __str__(self):
        return f"Weather: {self.weather.value}, Season: {self.season.value}, Plants: {self.food_available}"

# ==================== MULTIPLAYER SERVER (FULLY IMPLEMENTED) ====================

class MultiplayerServer(QThread):
    """Multiplayer server for hosting games using QtNetwork"""
    
    client_connected = Signal(str)
    client_disconnected = Signal(str)
    game_started = Signal()
    game_ended = Signal()
    data_received = Signal(dict)
    
    def __init__(self, host="127.0.0.1", port=9999, max_players=4):
        super().__init__()
        self.host = host
        self.port = port
        self.max_players = max_players
        self.server = QTcpServer()
        self.clients = {}  # socket -> player_id
        self.player_info = {}  # player_id -> name
        self.game_in_progress = False
        self.mode = "cooperative"
        
        self.server.newConnection.connect(self.handle_new_connection)
    
    def run(self):
        """Start the server"""
        if self.server.listen(QHostAddress(self.host), self.port):
            print(f"Server listening on {self.host}:{self.port}")
        else:
            print("Failed to start server")
    
    def handle_new_connection(self):
        """Handle new client connection"""
        socket = self.server.nextPendingConnection()
        
        if len(self.clients) >= self.max_players:
            # Reject connection
            socket.write(b"Server full")
            socket.disconnectFromHost()
            return
        
        # Assign player ID
        player_id = f"Player_{len(self.clients) + 1}"
        self.clients[socket] = player_id
        
        # Set up socket signals
        socket.readyRead.connect(lambda: self.handle_client_data(socket))
        socket.disconnected.connect(lambda: self.handle_client_disconnect(socket))
        
        # Send welcome message
        self.send_to_client(socket, {
            "type": "welcome",
            "player_id": player_id,
            "message": "Connected to server"
        })
        
        self.client_connected.emit(player_id)
        self.broadcast({
            "type": "system",
            "message": f"{player_id} joined the game"
        })
    
    def handle_client_data(self, socket):
        """Handle data from client"""
        try:
            data = socket.readAll()
            stream = QDataStream(data)
            stream.setVersion(QDataStream.Qt_6_0)
            
            message = stream.readQVariant()
            
            if isinstance(message, dict):
                player_id = self.clients.get(socket)
                if message.get("type") == "game_state":
                    # Broadcast game state to all clients
                    self.broadcast({
                        "type": "game_state_update",
                        "player": player_id,
                        "state": message.get("state")
                    }, exclude=socket)
                elif message.get("type") == "chat":
                    self.broadcast({
                        "type": "chat",
                        "player": player_id,
                        "message": message.get("message")
                    })
                elif message.get("type") == "ready":
                    self.player_info[player_id] = {
                        "ready": True,
                        "name": message.get("name", player_id)
                    }
                    
                    # Check if all players ready
                    if len(self.player_info) == len(self.clients) and all(p.get("ready") for p in self.player_info.values()):
                        self.start_game()
        
        except Exception as e:
            print(f"Error handling client data: {e}")
    
    def handle_client_disconnect(self, socket):
        """Handle client disconnection"""
        player_id = self.clients.pop(socket, None)
        if player_id:
            self.player_info.pop(player_id, None)
            self.client_disconnected.emit(player_id)
            self.broadcast({
                "type": "system",
                "message": f"{player_id} left the game"
            })
    
    def send_to_client(self, socket, data):
        """Send data to a specific client"""
        try:
            stream = QDataStream(socket)
            stream.setVersion(QDataStream.Qt_6_0)
            stream.writeQVariant(data)
            socket.flush()
        except Exception as e:
            print(f"Error sending to client: {e}")
    
    def broadcast(self, data, exclude=None):
        """Broadcast data to all clients"""
        for socket in self.clients:
            if exclude and socket == exclude:
                continue
            self.send_to_client(socket, data)
    
    def start_game(self):
        """Start the multiplayer game"""
        self.game_in_progress = True
        self.broadcast({
            "type": "game_start",
            "mode": self.mode
        })
        self.game_started.emit()
    
    def end_game(self):
        """End the multiplayer game"""
        self.game_in_progress = False
        self.broadcast({"type": "game_end"})
        self.game_ended.emit()
    
    def stop(self):
        """Stop the server"""
        self.broadcast({"type": "shutdown"})
        for socket in list(self.clients.keys()):
            socket.disconnectFromHost()
        self.server.close()

# ==================== MULTIPLAYER CLIENT (FULLY IMPLEMENTED) ====================

class MultiplayerClient(QThread):
    """Multiplayer client for connecting to games"""
    
    connected = Signal()
    disconnected = Signal()
    game_started = Signal(dict)
    game_ended = Signal()
    state_received = Signal(dict)
    chat_received = Signal(str, str)
    system_message = Signal(str)
    
    def __init__(self, host="127.0.0.1", port=9999):
        super().__init__()
        self.host = host
        self.port = port
        self.socket = QTcpSocket()
        self.player_id = None
        self.game_state = {}
        self.connected = False
        
        # Connect signals
        self.socket.connected.connect(self.on_connected)
        self.socket.disconnected.connect(self.on_disconnected)
        self.socket.readyRead.connect(self.on_data_received)
        self.socket.errorOccurred.connect(self.on_error)
    
    def run(self):
        """Connect to server"""
        self.socket.connectToHost(self.host, self.port)
    
    def on_connected(self):
        """Handle successful connection"""
        self.connected = True
        self.connected.emit()
    
    def on_disconnected(self):
        """Handle disconnection"""
        self.connected = False
        self.disconnected.emit()
    
    def on_data_received(self):
        """Handle incoming data"""
        try:
            stream = QDataStream(self.socket)
            stream.setVersion(QDataStream.Qt_6_0)
            
            while not stream.atEnd():
                message = stream.readQVariant()
                
                if isinstance(message, dict):
                    msg_type = message.get("type")
                    
                    if msg_type == "welcome":
                        self.player_id = message.get("player_id")
                        self.system_message.emit(message.get("message"))
                    
                    elif msg_type == "game_start":
                        self.game_started.emit(message)
                    
                    elif msg_type == "game_end":
                        self.game_ended.emit()
                    
                    elif msg_type == "game_state_update":
                        self.state_received.emit(message)
                    
                    elif msg_type == "chat":
                        self.chat_received.emit(
                            message.get("player"),
                            message.get("message")
                        )
                    
                    elif msg_type == "system":
                        self.system_message.emit(message.get("message"))
                    
                    elif msg_type == "shutdown":
                        self.disconnect()
        
        except Exception as e:
            print(f"Error receiving data: {e}")
    
    def on_error(self, error):
        """Handle socket error"""
        self.system_message.emit(f"Error: {self.socket.errorString()}")
    
    def send_game_state(self, state):
        """Send game state to server"""
        if self.socket.state() == QTcpSocket.ConnectedState:
            self.send_data({
                "type": "game_state",
                "state": state
            })
    
    def send_chat(self, message):
        """Send chat message"""
        if self.socket.state() == QTcpSocket.ConnectedState:
            self.send_data({
                "type": "chat",
                "message": message
            })
    
    def send_ready(self, name):
        """Send ready status"""
        if self.socket.state() == QTcpSocket.ConnectedState:
            self.send_data({
                "type": "ready",
                "name": name
            })
    
    def send_data(self, data):
        """Send data to server"""
        try:
            stream = QDataStream(self.socket)
            stream.setVersion(QDataStream.Qt_6_0)
            stream.writeQVariant(data)
            self.socket.flush()
        except Exception as e:
            print(f"Error sending data: {e}")
    
    def disconnect(self):
        """Disconnect from server"""
        self.socket.disconnectFromHost()

# ==================== MULTIPLAYER DIALOG (FULLY IMPLEMENTED) ====================

class MultiplayerDialog(QDialog):
    """Dialog for multiplayer setup"""
    
    join_game = Signal(str, int, str)  # host, port, player_name
    host_game = Signal(int, int, str)  # port, max_players, mode
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🌐 Multiplayer")
        self.setGeometry(200, 200, 500, 450)
        self.server = None
        self.client = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Mode selection
        mode_group = QGroupBox("Game Mode")
        mode_layout = QVBoxLayout()
        
        self.mode_coop = QRadioButton("Cooperative - Work together")
        self.mode_coop.setChecked(True)
        mode_layout.addWidget(self.mode_coop)
        
        self.mode_comp = QRadioButton("Competitive - Last ecosystem standing")
        mode_layout.addWidget(self.mode_comp)
        
        self.mode_team = QRadioButton("Team - 2v2")
        mode_layout.addWidget(self.mode_team)
        
        mode_group.setLayout(mode_layout)
        layout.addWidget(mode_group)
        
        # Host/Join tabs
        tabs = QTabWidget()
        
        # Host tab
        host_widget = QWidget()
        host_layout = QFormLayout(host_widget)
        
        self.host_port = QSpinBox()
        self.host_port.setRange(1024, 65535)
        self.host_port.setValue(9999)
        host_layout.addRow("Port:", self.host_port)
        
        self.max_players = QSpinBox()
        self.max_players.setRange(2, 8)
        self.max_players.setValue(4)
        host_layout.addRow("Max Players:", self.max_players)
        
        self.host_name = QLineEdit("Player 1")
        host_layout.addRow("Your Name:", self.host_name)
        
        self.host_btn = QPushButton("▶ Host Game")
        self.host_btn.clicked.connect(self.on_host_game)
        host_layout.addRow(self.host_btn)
        
        # Server status
        self.host_status = QLabel("Not hosting")
        host_layout.addRow(self.host_status)
        
        tabs.addTab(host_widget, "Host Game")
        
        # Join tab
        join_widget = QWidget()
        join_layout = QFormLayout(join_widget)
        
        self.join_ip = QLineEdit("127.0.0.1")
        join_layout.addRow("Server IP:", self.join_ip)
        
        self.join_port = QSpinBox()
        self.join_port.setRange(1024, 65535)
        self.join_port.setValue(9999)
        join_layout.addRow("Port:", self.join_port)
        
        self.join_name = QLineEdit("Player 2")
        join_layout.addRow("Your Name:", self.join_name)
        
        self.join_btn = QPushButton("🔌 Join Game")
        self.join_btn.clicked.connect(self.on_join_game)
        join_layout.addRow(self.join_btn)
        
        # Connection status
        self.join_status = QLabel("Not connected")
        join_layout.addRow(self.join_status)
        
        tabs.addTab(join_widget, "Join Game")
        
        layout.addWidget(tabs)
        
        # Chat/Log area for multiplayer
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(150)
        layout.addWidget(QLabel("Event Log:"))
        layout.addWidget(self.log_text)
        
        # Close button
        button_box = QDialogButtonBox(QDialogButtonBox.Cancel)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def on_host_game(self):
        """Host a multiplayer game"""
        port = self.host_port.value()
        max_players = self.max_players.value()
        mode = "cooperative" if self.mode_coop.isChecked() else \
               "competitive" if self.mode_comp.isChecked() else "team"
        player_name = self.host_name.text()
        
        # Start server
        self.server = MultiplayerServer(port=port, max_players=max_players)
        self.server.client_connected.connect(lambda pid: self.add_log(f"✅ {pid} connected"))
        self.server.client_disconnected.connect(lambda pid: self.add_log(f"❌ {pid} disconnected"))
        self.server.game_started.connect(lambda: self.add_log("🎮 Game started!"))
        self.server.start()
        
        # Connect as client
        self.client = MultiplayerClient(port=port)
        self.client.connected.connect(lambda: self.on_client_connected(player_name))
        self.client.system_message.connect(self.add_log)
        self.client.chat_received.connect(self.on_chat_received)
        self.client.start()
        
        self.host_status.setText(f"Hosting on port {port}")
        self.add_log(f"🎮 Hosting game on port {port}")
        self.host_game.emit(port, max_players, mode)
    
    def on_join_game(self):
        """Join a multiplayer game"""
        host = self.join_ip.text()
        port = self.join_port.value()
        player_name = self.join_name.text()
        
        self.client = MultiplayerClient(host, port)
        self.client.connected.connect(lambda: self.on_client_connected(player_name))
        self.client.system_message.connect(self.add_log)
        self.client.chat_received.connect(self.on_chat_received)
        self.client.game_started.connect(lambda: self.add_log("🎮 Game started!"))
        self.client.start()
        
        self.join_status.setText(f"Connecting to {host}:{port}...")
        self.join_game.emit(host, port, player_name)
    
    def on_client_connected(self, player_name):
        """Handle client connected"""
        self.add_log("✅ Connected to server")
        if self.client:
            self.client.send_ready(player_name)
    
    def on_chat_received(self, player, message):
        """Handle chat message"""
        self.add_log(f"💬 {player}: {message}")
    
    def add_log(self, message):
        """Add message to log"""
        self.log_text.append(message)
        # Scroll to bottom
        cursor = self.log_text.textCursor()
        cursor.movePosition(cursor.End)
        self.log_text.setTextCursor(cursor)

# ==================== VIDEO EXPORTER (FULLY IMPLEMENTED) ====================

class VideoExporter(QThread):
    """Export simulation to video in background thread"""
    
    progress_signal = Signal(int)
    finished_signal = Signal(str)
    error_signal = Signal(str)
    
    def __init__(self, simulator, filename, fps=10, duration=None, quality='high', include_ui=True):
        super().__init__()
        self.simulator = simulator
        self.filename = filename
        self.fps = fps
        self.duration = duration  # in seconds, None for full simulation
        self.quality = quality
        self.include_ui = include_ui
        self.running = True
        self.frame_cache = []
        
        # Quality settings
        self.quality_settings = {
            'low': (640, 480, 500000),  # width, height, bitrate
            'medium': (1280, 720, 2000000),
            'high': (1920, 1080, 5000000),
            'ultra': (3840, 2160, 10000000)
        }
    
    def run(self):
        """Export video"""
        try:
            # Calculate frames
            total_frames = self.duration * self.fps if self.duration else self.simulator.day * self.fps
            width, height, bitrate = self.quality_settings.get(self.quality, (1280, 720, 2000000))
            
            # Initialize video writer
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(self.filename, fourcc, self.fps, (width, height))
            
            # Generate frames
            for day in range(1, self.simulator.day + 1):
                if not self.running:
                    break
                
                # Create frame for this day
                frame = self._create_frame(day, width, height)
                
                # Convert to correct format for OpenCV
                if frame.mode == 'RGBA':
                    frame = frame.convert('RGB')
                
                # Convert PIL to OpenCV
                frame_np = np.array(frame)
                frame_cv = cv2.cvtColor(frame_np, cv2.COLOR_RGB2BGR)
                
                # Write frame
                for _ in range(self.fps):  # Repeat frame for each second at given FPS
                    out.write(frame_cv)
                
                # Update progress
                progress = int((day / self.simulator.day) * 100)
                self.progress_signal.emit(progress)
            
            out.release()
            self.finished_signal.emit(f"Video saved to {self.filename}")
            
        except Exception as e:
            self.error_signal.emit(str(e))
    
    def _create_frame(self, day, width, height):
        """Create a single frame for the video"""
        # Create blank image
        img = Image.new('RGB', (width, height), color=(43, 43, 43))
        draw = ImageDraw.Draw(img)
        
        try:
            # Try to load a font, fall back to default
            font = ImageFont.truetype("arial.ttf", 24)
            small_font = ImageFont.truetype("arial.ttf", 18)
        except:
            font = ImageFont.load_default()
            small_font = ImageFont.load_default()
        
        # Draw title
        draw.text((10, 10), f"Wildlife Simulator - Day {day}", 
                 fill=(255, 255, 255), font=font)
        
        # Draw statistics
        stats = self._get_stats_for_day(day)
        y = 50
        for key, value in stats.items():
            draw.text((10, y), f"{key}: {value}", fill=(200, 200, 200), font=small_font)
            y += 25
        
        # Draw animal icons
        animals = self._get_animals_for_day(day)
        icons = {"Lion": "🦁", "Rabbit": "🐰", "Wolf": "🐺", "Deer": "🦌"}
        
        x = width // 2
        y = 50
        for species, count in animals.items():
            icon = icons.get(species, "🐾")
            draw.text((x, y), f"{icon} {species}: {count}", fill=(255, 255, 255), font=small_font)
            y += 25
        
        # Draw ecosystem visualization
        self._draw_ecosystem(draw, animals, width, height)
        
        # Draw timeline
        self._draw_timeline(draw, day, width, height)
        
        return img
    
    def _get_stats_for_day(self, day):
        """Get statistics for a specific day"""
        # In a real implementation, this would access historical data
        # For now, return simulated data
        return {
            "Population": len(self.simulator.forest),
            "Plants": self.simulator.environment.food_available,
            "Weather": self.simulator.environment.weather.value.capitalize(),
            "Season": self.simulator.environment.season.value.capitalize()
        }
    
    def _get_animals_for_day(self, day):
        """Get animal counts for a specific day"""
        animals = {}
        for animal in self.simulator.forest:
            species = animal.species
            animals[species] = animals.get(species, 0) + 1
        return animals
    
    def _draw_ecosystem(self, draw, animals, width, height):
        """Draw a simple ecosystem visualization"""
        # Draw ground
        ground_y = height - 100
        draw.rectangle([50, ground_y, width - 50, ground_y + 50], fill=(101, 67, 33))
        
        # Draw plants
        for i in range(10):
            x = 50 + i * ((width - 100) // 10)
            draw.rectangle([x, ground_y - 50, x + 10, ground_y], fill=(34, 139, 34))
            draw.ellipse([x - 10, ground_y - 70, x + 20, ground_y - 30], fill=(50, 205, 50))
        
        # Draw animals based on counts
        colors = {
            "Lion": (255, 200, 0),
            "Rabbit": (255, 255, 255),
            "Wolf": (128, 128, 128),
            "Deer": (139, 69, 19)
        }
        
        x_positions = {
            "Lion": width // 4,
            "Rabbit": width // 2,
            "Wolf": 3 * width // 4,
            "Deer": width - 100
        }
        
        for species, count in animals.items():
            if count > 0 and species in x_positions:
                x = x_positions[species]
                color = colors.get(species, (255, 255, 255))
                
                # Draw up to 5 animals per species
                for i in range(min(count, 5)):
                    y = ground_y - 30 - i * 20
                    draw.ellipse([x - 15 + i*20, y - 15, x + 15 + i*20, y + 15], 
                               fill=color, outline=(0, 0, 0))
    
    def _draw_timeline(self, draw, day, width, height):
        """Draw a timeline at the bottom"""
        timeline_y = height - 30
        timeline_width = width - 100
        
        # Draw timeline bar
        draw.rectangle([50, timeline_y, 50 + timeline_width, timeline_y + 10], 
                      fill=(100, 100, 100))
        
        # Draw progress
        if self.duration:
            progress = min(1.0, day / (self.duration * self.fps))
        else:
            progress = day / self.simulator.day if self.simulator.day > 0 else 0
        
        progress_width = int(timeline_width * progress)
        draw.rectangle([50, timeline_y, 50 + progress_width, timeline_y + 10], 
                      fill=(74, 144, 226))
    
    def stop(self):
        """Stop video generation"""
        self.running = False

# ==================== VIDEO EXPORT DIALOG (FULLY IMPLEMENTED) ====================

class VideoExportDialog(QDialog):
    """Dialog for video export settings"""
    
    def __init__(self, simulator, parent=None):
        super().__init__(parent)
        self.simulator = simulator
        self.exporter = None
        self.setWindowTitle("🎥 Export to Video")
        self.setGeometry(200, 200, 400, 350)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Settings
        settings_group = QGroupBox("Export Settings")
        settings_layout = QFormLayout()
        
        self.fps_spin = QSpinBox()
        self.fps_spin.setRange(1, 60)
        self.fps_spin.setValue(10)
        settings_layout.addRow("FPS:", self.fps_spin)
        
        self.duration_spin = QSpinBox()
        self.duration_spin.setRange(0, 3600)
        self.duration_spin.setSpecialValueText("Full Simulation")
        self.duration_spin.setValue(0)
        settings_layout.addRow("Duration (seconds):", self.duration_spin)
        
        self.quality_combo = QComboBox()
        self.quality_combo.addItems(["low", "medium", "high", "ultra"])
        self.quality_combo.setCurrentIndex(2)
        settings_layout.addRow("Quality:", self.quality_combo)
        
        self.include_ui = QCheckBox("Include UI elements")
        self.include_ui.setChecked(True)
        settings_layout.addRow(self.include_ui)
        
        settings_group.setLayout(settings_layout)
        layout.addWidget(settings_group)
        
        # File selection
        file_layout = QHBoxLayout()
        file_layout.addWidget(QLabel("Filename:"))
        
        self.filename_edit = QLineEdit("simulation.mp4")
        file_layout.addWidget(self.filename_edit)
        
        self.browse_btn = QPushButton("Browse...")
        self.browse_btn.clicked.connect(self.browse_file)
        file_layout.addWidget(self.browse_btn)
        
        layout.addLayout(file_layout)
        
        # Info label
        self.info_label = QLabel(f"Total days: {self.simulator.day}")
        layout.addWidget(self.info_label)
        
        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.export_btn = QPushButton("🎥 Export")
        self.export_btn.clicked.connect(self.export_video)
        button_layout.addWidget(self.export_btn)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.cancel_btn)
        
        layout.addLayout(button_layout)
    
    def browse_file(self):
        """Browse for output file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Video", "simulation.mp4", "MP4 Videos (*.mp4)"
        )
        if file_path:
            self.filename_edit.setText(file_path)
    
    def export_video(self):
        """Start video export"""
        filename = self.filename_edit.text()
        fps = self.fps_spin.value()
        duration = self.duration_spin.value() if self.duration_spin.value() > 0 else None
        quality = self.quality_combo.currentText()
        include_ui = self.include_ui.isChecked()
        
        # Create and start exporter
        self.exporter = VideoExporter(self.simulator, filename, fps, duration, quality, include_ui)
        self.exporter.progress_signal.connect(self.update_progress)
        self.exporter.finished_signal.connect(self.export_finished)
        self.exporter.error_signal.connect(self.export_error)
        
        self.progress_bar.setVisible(True)
        self.export_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)
        
        self.exporter.start()
    
    def update_progress(self, value):
        """Update progress bar"""
        self.progress_bar.setValue(value)
    
    def export_finished(self, message):
        """Handle export finished"""
        self.progress_bar.setVisible(False)
        self.export_btn.setEnabled(True)
        self.cancel_btn.setEnabled(True)
        QMessageBox.information(self, "Success", message)
        self.accept()
    
    def export_error(self, error):
        """Handle export error"""
        self.progress_bar.setVisible(False)
        self.export_btn.setEnabled(True)
        self.cancel_btn.setEnabled(True)
        QMessageBox.critical(self, "Error", f"Export failed: {error}")

# ==================== SIMULATION WORKER ====================

class SimulationWorker(QObject):
    """Worker object for running simulation in separate thread"""
    
    update_signal = Signal(str)
    status_signal = Signal(dict)
    achievement_signal = Signal(object)
    finished = Signal()
    paused_signal = Signal()
    
    def __init__(self, simulator):
        super().__init__()
        self.simulator = simulator
        self.running = False
        self.paused = False
        self.speed = 5
        self.pause_menu_shown = False
    
    def run(self):
        """Run the simulation"""
        self.running = True
        while self.running and self.simulator.forest:
            if self.paused:
                if not self.pause_menu_shown:
                    self.paused_signal.emit()
                    self.pause_menu_shown = True
                QThread.msleep(100)  # Sleep while paused
                continue
            
            # Run one day
            reports = self.simulator.simulate_day()
            
            # Check achievements
            if self.simulator.config.get('achievements.enabled', True):
                stats = self.simulator.get_stats_dict()
                new_achievements = self.simulator.achievement_manager.check_achievements(stats)
                for ach in new_achievements:
                    self.achievement_signal.emit(ach)
                    if self.simulator.config.get('achievements.notifications', True):
                        reports.append(f"🏆 Achievement Unlocked: {ach.name}!")
            
            # Check scenario objectives
            if self.simulator.scenario_manager.current_scenario:
                completed = self.simulator.scenario_manager.check_objectives(self.simulator)
                for obj in completed:
                    reports.append(f"✅ Objective Completed: {obj.description}")
            
            # Send updates
            for report in reports:
                self.update_signal.emit(report)
            
            # Send status
            self.status_signal.emit(self.simulator.get_status_dict())
            
            # Auto-save if enabled
            if (self.simulator.config.get('simulation.auto_save', True) and 
                self.simulator.day % self.simulator.config.get('simulation.auto_save_interval', 10) == 0):
                self.simulator.save_simulation("autosave.pkl")
                self.update_signal.emit("💾 Auto-saved simulation")
            
            # Wait based on speed
            QThread.msleep(int(1000 / self.speed))
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
    
    def pause(self):
        self.paused = not self.paused
        self.pause_menu_shown = False

# ==================== ACHIEVEMENTS DIALOG ====================

class AchievementsDialog(QDialog):
    """Dialog showing achievements"""
    
    def __init__(self, achievement_manager: AchievementManager, parent=None):
        super().__init__(parent)
        self.achievement_manager = achievement_manager
        self.setWindowTitle("🏆 Achievements")
        self.setGeometry(200, 200, 600, 500)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Stats summary
        total = len(self.achievement_manager.achievements)
        unlocked = sum(1 for a in self.achievement_manager.achievements.values() if a.unlocked)
        
        summary_layout = QHBoxLayout()
        summary_layout.addWidget(QLabel(f"Progress: {unlocked}/{total} achievements unlocked"))
        
        progress_bar = QProgressBar()
        progress_bar.setRange(0, total)
        progress_bar.setValue(unlocked)
        summary_layout.addWidget(progress_bar)
        
        layout.addLayout(summary_layout)
        
        # Achievement list
        tabs = QTabWidget()
        
        # All achievements tab
        all_widget = QWidget()
        all_layout = QVBoxLayout(all_widget)
        
        self.all_table = QTableWidget()
        self.all_table.setColumnCount(5)
        self.all_table.setHorizontalHeaderLabels(["Icon", "Achievement", "Description", "Rarity", "Progress"])
        self.all_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        self._populate_table(self.all_table, all_achievements=True)
        all_layout.addWidget(self.all_table)
        tabs.addTab(all_widget, "All")
        
        # Unlocked tab
        unlocked_widget = QWidget()
        unlocked_layout = QVBoxLayout(unlocked_widget)
        
        self.unlocked_table = QTableWidget()
        self.unlocked_table.setColumnCount(5)
        self.unlocked_table.setHorizontalHeaderLabels(["Icon", "Achievement", "Description", "Rarity", "Unlocked Day"])
        
        self._populate_table(self.unlocked_table, unlocked_only=True)
        unlocked_layout.addWidget(self.unlocked_table)
        tabs.addTab(unlocked_widget, "Unlocked")
        
        # Locked tab
        locked_widget = QWidget()
        locked_layout = QVBoxLayout(locked_widget)
        
        self.locked_table = QTableWidget()
        self.locked_table.setColumnCount(4)
        self.locked_table.setHorizontalHeaderLabels(["Icon", "Achievement", "Description", "Rarity"])
        
        self._populate_table(self.locked_table, locked_only=True)
        locked_layout.addWidget(self.locked_table)
        tabs.addTab(locked_widget, "Locked")
        
        layout.addWidget(tabs)
        
        # Close button
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(self.accept)
        layout.addWidget(button_box)
    
    def _populate_table(self, table, all_achievements=False, unlocked_only=False, locked_only=False):
        """Populate table with achievements"""
        achievements = []
        
        for ach in self.achievement_manager.achievements.values():
            if unlocked_only and not ach.unlocked:
                continue
            if locked_only and ach.unlocked:
                continue
            if ach.secret and not ach.unlocked:
                continue  # Hide secret locked achievements
            achievements.append(ach)
        
        table.setRowCount(len(achievements))
        
        for i, ach in enumerate(achievements):
            # Icon
            icon_item = QTableWidgetItem(ach.icon)
            icon_item.setTextAlignment(Qt.AlignCenter)
            table.setItem(i, 0, icon_item)
            
            # Name
            name_item = QTableWidgetItem(ach.name)
            if ach.unlocked:
                name_item.setForeground(QColor(255, 215, 0))  # Gold
            table.setItem(i, 1, name_item)
            
            # Description
            desc = ach.description
            if ach.secret and not ach.unlocked:
                desc = "???"  # Hide secret descriptions
            table.setItem(i, 2, QTableWidgetItem(desc))
            
            # Rarity
            rarity_item = QTableWidgetItem(ach.rarity.value)
            rarity_colors = {
                AchievementRarity.COMMON: QColor(200, 200, 200),
                AchievementRarity.UNCOMMON: QColor(0, 255, 0),
                AchievementRarity.RARE: QColor(0, 0, 255),
                AchievementRarity.EPIC: QColor(128, 0, 128),
                AchievementRarity.LEGENDARY: QColor(255, 215, 0)
            }
            rarity_item.setForeground(rarity_colors.get(ach.rarity, QColor(255, 255, 255)))
            table.setItem(i, 3, rarity_item)
            
            # Progress/Unlocked day
            if unlocked_only:
                progress_item = QTableWidgetItem(f"Day {ach.unlocked_at}" if ach.unlocked_at else "Unknown")
            else:
                if ach.progress_max:
                    progress = f"{ach.progress}/{ach.progress_max}"
                else:
                    progress = "✓" if ach.unlocked else "✗"
                progress_item = QTableWidgetItem(progress)
            table.setItem(i, 4, progress_item)

# ==================== SCENARIO DIALOG ====================

class ScenarioDialog(QDialog):
    """Dialog for selecting and starting scenarios"""
    
    scenario_selected = Signal(str)
    
    def __init__(self, scenario_manager: ScenarioManager, parent=None):
        super().__init__(parent)
        self.scenario_manager = scenario_manager
        self.setWindowTitle("📜 Scenario Selector")
        self.setGeometry(200, 200, 800, 600)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Splitter
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Scenario list
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        
        left_layout.addWidget(QLabel("Available Scenarios:"))
        
        self.scenario_list = QListWidget()
        for scenario_id, scenario in self.scenario_manager.scenarios.items():
            item = QListWidgetItem(f"{scenario.name} ({scenario.difficulty})")
            item.setData(Qt.UserRole, scenario_id)
            if scenario.completed:
                item.setForeground(QColor(0, 255, 0))
                item.setText(f"✓ {item.text()}")
            self.scenario_list.addItem(item)
        
        self.scenario_list.currentItemChanged.connect(self.on_scenario_selected)
        left_layout.addWidget(self.scenario_list)
        
        splitter.addWidget(left_widget)
        
        # Right panel - Scenario details
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        
        # Scenario info
        self.info_group = QGroupBox("Scenario Details")
        info_layout = QFormLayout()
        
        self.name_label = QLabel()
        info_layout.addRow("Name:", self.name_label)
        
        self.difficulty_label = QLabel()
        info_layout.addRow("Difficulty:", self.difficulty_label)
        
        self.desc_label = QLabel()
        self.desc_label.setWordWrap(True)
        info_layout.addRow("Description:", self.desc_label)
        
        self.time_label = QLabel()
        info_layout.addRow("Time Limit:", self.time_label)
        
        self.info_group.setLayout(info_layout)
        right_layout.addWidget(self.info_group)
        
        # Objectives
        self.objectives_group = QGroupBox("Objectives")
        objectives_layout = QVBoxLayout()
        
        self.objectives_list = QListWidget()
        objectives_layout.addWidget(self.objectives_list)
        
        self.objectives_group.setLayout(objectives_layout)
        right_layout.addWidget(self.objectives_group)
        
        # Special rules
        self.rules_group = QGroupBox("Special Rules")
        rules_layout = QVBoxLayout()
        
        self.rules_list = QListWidget()
        rules_layout.addWidget(self.rules_list)
        
        self.rules_group.setLayout(rules_layout)
        right_layout.addWidget(self.rules_group)
        
        # Rewards
        self.rewards_group = QGroupBox("Rewards")
        rewards_layout = QVBoxLayout()
        
        self.rewards_list = QListWidget()
        rewards_layout.addWidget(self.rewards_list)
        
        self.rewards_group.setLayout(rewards_layout)
        right_layout.addWidget(self.rewards_group)
        
        splitter.addWidget(right_widget)
        layout.addWidget(splitter)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("▶ Start Scenario")
        self.start_btn.clicked.connect(self.start_scenario)
        self.start_btn.setEnabled(False)
        button_layout.addWidget(self.start_btn)
        
        button_layout.addStretch()
        
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.reject)
        button_layout.addWidget(self.close_btn)
        
        layout.addLayout(button_layout)
        
        splitter.setSizes([300, 500])
    
    def on_scenario_selected(self, current, previous):
        """Handle scenario selection"""
        if not current:
            return
            
        scenario_id = current.data(Qt.UserRole)
        scenario = self.scenario_manager.scenarios[scenario_id]
        
        # Update info
        self.name_label.setText(scenario.name)
        self.difficulty_label.setText(scenario.difficulty)
        self.desc_label.setText(scenario.description)
        self.time_label.setText(f"{scenario.time_limit} days" if scenario.time_limit else "No limit")
        
        # Update objectives
        self.objectives_list.clear()
        for obj in scenario.objectives:
            item = QListWidgetItem(f"• {obj.description}")
            if obj.completed:
                item.setForeground(QColor(0, 255, 0))
                item.setText(f"✓ {item.text()}")
            self.objectives_list.addItem(item)
        
        # Update rules
        self.rules_list.clear()
        if scenario.special_rules:
            for rule in scenario.special_rules:
                self.rules_list.addItem(f"• {rule}")
        else:
            self.rules_list.addItem("• None")
        
        # Update rewards
        self.rewards_list.clear()
        if scenario.rewards:
            for reward in scenario.rewards:
                self.rewards_list.addItem(f"• {reward}")
        else:
            self.rewards_list.addItem("• None")
        
        self.start_btn.setEnabled(True)
    
    def start_scenario(self):
        """Start the selected scenario"""
        current = self.scenario_list.currentItem()
        if current:
            scenario_id = current.data(Qt.UserRole)
            self.scenario_selected.emit(scenario_id)
            self.accept()

# ==================== MOD MANAGER DIALOG ====================

class ModManagerDialog(QDialog):
    """Dialog for managing mods at runtime"""
    
    mods_changed = Signal()
    
    def __init__(self, mod_loader: ModLoader, config: Configuration, parent=None):
        super().__init__(parent)
        self.mod_loader = mod_loader
        self.config = config
        self.setWindowTitle("📦 Mod Manager")
        self.setGeometry(200, 200, 800, 600)
        self.init_ui()
        self.refresh_mod_list()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Mods directory info
        dir_layout = QHBoxLayout()
        dir_layout.addWidget(QLabel(f"Mods Directory:"))
        dir_layout.addWidget(QLabel(str(self.mod_loader.mods_directory)))
        dir_layout.addStretch()
        layout.addLayout(dir_layout)
        
        # Mod list
        list_group = QGroupBox("Installed Mods")
        list_layout = QVBoxLayout()
        
        self.mod_table = QTableWidget()
        self.mod_table.setColumnCount(5)
        self.mod_table.setHorizontalHeaderLabels(["Mod", "Species", "Diet", "Format", "Status"])
        self.mod_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.mod_table.setSelectionBehavior(QTableWidget.SelectRows)
        list_layout.addWidget(self.mod_table)
        
        list_group.setLayout(list_layout)
        layout.addWidget(list_group)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        self.load_btn = QPushButton("📂 Load Mod")
        self.load_btn.clicked.connect(self.load_mod)
        btn_layout.addWidget(self.load_btn)
        
        self.unload_btn = QPushButton("❌ Unload Mod")
        self.unload_btn.clicked.connect(self.unload_mod)
        self.unload_btn.setEnabled(False)
        btn_layout.addWidget(self.unload_btn)
        
        self.reload_btn = QPushButton("🔄 Reload Mod")
        self.reload_btn.clicked.connect(self.reload_mod)
        self.reload_btn.setEnabled(False)
        btn_layout.addWidget(self.reload_btn)
        
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh_mod_list)
        btn_layout.addWidget(self.refresh_btn)
        
        layout.addLayout(btn_layout)
        
        # Mod details
        details_group = QGroupBox("Mod Details")
        details_layout = QFormLayout()
        
        self.details_text = QTextEdit()
        self.details_text.setReadOnly(True)
        self.details_text.setMaximumHeight(150)
        details_layout.addRow(self.details_text)
        
        details_group.setLayout(details_layout)
        layout.addWidget(details_group)
        
        # Dialog buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        # Connect selection change
        self.mod_table.itemSelectionChanged.connect(self.on_mod_selected)
    
    def refresh_mod_list(self):
        """Refresh the mod list"""
        mods = self.mod_loader.get_all_mods()
        
        self.mod_table.setRowCount(len(mods))
        for i, mod in enumerate(mods):
            self.mod_table.setItem(i, 0, QTableWidgetItem(mod.name))
            self.mod_table.setItem(i, 1, QTableWidgetItem(mod.id))
            self.mod_table.setItem(i, 2, QTableWidgetItem(mod.data.get('diet_type', 'unknown')))
            self.mod_table.setItem(i, 3, QTableWidgetItem(mod.format.value))
            
            status_widget = QWidget()
            status_layout = QHBoxLayout(status_widget)
            status_layout.setContentsMargins(0,0,0,0)
            
            enabled_cb = QCheckBox()
            enabled_cb.setChecked(mod.enabled)
            enabled_cb.stateChanged.connect(lambda state, m=mod: self.toggle_mod(m, state))
            status_layout.addWidget(enabled_cb)
            
            if mod.error:
                error_label = QLabel("⚠️")
                error_label.setToolTip(mod.error)
                status_layout.addWidget(error_label)
            
            status_layout.addStretch()
            self.mod_table.setCellWidget(i, 4, status_widget)
    
    def toggle_mod(self, mod: ModInfo, state):
        """Toggle mod enabled state"""
        mod.enabled = (state == Qt.Checked)
        if mod.enabled:
            # Try to create animal class if not exists
            if mod.id not in self.mod_loader.animal_classes:
                try:
                    animal_class = ModAnimalFactory.create_animal_class(mod)
                    self.mod_loader.animal_classes[mod.id] = animal_class
                    AnimalFactory.register_mod_animal(mod.id, animal_class, mod.data)
                    mod.error = None
                except Exception as e:
                    mod.error = str(e)
                    mod.enabled = False
        else:
            # Remove animal class
            if mod.id in self.mod_loader.animal_classes:
                del self.mod_loader.animal_classes[mod.id]
    
    def load_mod(self):
        """Load a new mod from file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Mod", str(self.mod_loader.mods_directory),
            "Mod Files (*.json *.hjson *.msgpack *.bson *.xml *.toml *.yaml *.yml);;All Files (*)"
        )
        
        if file_path:
            mod_info = self.mod_loader.load_mod(file_path)
            if mod_info:
                # Create animal class
                try:
                    animal_class = ModAnimalFactory.create_animal_class(mod_info)
                    self.mod_loader.animal_classes[mod_info.id] = animal_class
                    AnimalFactory.register_mod_animal(mod_info.id, animal_class, mod_info.data)
                    QMessageBox.information(self, "Success", f"Mod '{mod_info.name}' loaded successfully!")
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to create animal class: {e}")
                
                self.refresh_mod_list()
                self.mods_changed.emit()
            else:
                QMessageBox.warning(self, "Error", "Failed to load mod!")
    
    def unload_mod(self):
        """Unload selected mod"""
        current_row = self.mod_table.currentRow()
        if current_row >= 0:
            mod_id = self.mod_table.item(current_row, 1).text()
            reply = QMessageBox.question(self, "Confirm Unload", 
                                       f"Unload mod '{mod_id}'? This will remove all animals of this species.")
            if reply == QMessageBox.Yes:
                self.mod_loader.unload_mod(mod_id)
                self.refresh_mod_list()
                self.mods_changed.emit()
    
    def reload_mod(self):
        """Reload selected mod"""
        current_row = self.mod_table.currentRow()
        if current_row >= 0:
            mod_id = self.mod_table.item(current_row, 1).text()
            mod_info = self.mod_loader.reload_mod(mod_id)
            if mod_info:
                # Recreate animal class
                try:
                    animal_class = ModAnimalFactory.create_animal_class(mod_info)
                    self.mod_loader.animal_classes[mod_id] = animal_class
                    AnimalFactory.register_mod_animal(mod_id, animal_class, mod_info.data)
                    QMessageBox.information(self, "Success", f"Mod '{mod_info.name}' reloaded!")
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to recreate animal class: {e}")
                
                self.refresh_mod_list()
                self.mods_changed.emit()
    
    def on_mod_selected(self):
        """Handle mod selection change"""
        current_row = self.mod_table.currentRow()
        has_selection = current_row >= 0
        
        self.unload_btn.setEnabled(has_selection)
        self.reload_btn.setEnabled(has_selection)
        
        if has_selection:
            mod_id = self.mod_table.item(current_row, 1).text()
            mod_info = self.mod_loader.loaded_mods.get(mod_id)
            if mod_info:
                # Display mod details
                details = f"ID: {mod_info.id}\n"
                details += f"Name: {mod_info.name}\n"
                details += f"File: {mod_info.file_path}\n"
                details += f"Format: {mod_info.format.value}\n"
                details += f"Diet: {mod_info.data.get('diet_type', 'unknown')}\n"
                details += f"Energy Range: {mod_info.data['base_stats']['energy_range']}\n"
                
                if 'behavior' in mod_info.data:
                    details += f"\nBehavior:\n"
                    for key, value in mod_info.data['behavior'].items():
                        details += f"  {key}: {value}\n"
                
                if 'special_ability' in mod_info.data:
                    details += f"\nSpecial Ability: {mod_info.data['special_ability'].get('name', 'Unknown')}\n"
                
                if mod_info.error:
                    details += f"\n⚠️ Error: {mod_info.error}\n"
                
                self.details_text.setText(details)

# ==================== PAUSE MENU DIALOG ====================

class PauseMenuDialog(QDialog):
    """Dialog shown when simulation is paused"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("⏸ Simulation Paused")
        self.setModal(True)
        self.setFixedSize(300, 300)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Simulation Paused")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: bold; margin: 10px;")
        layout.addWidget(title)
        
        # Buttons
        btn_style = "font-size: 14px; padding: 8px; margin: 2px;"
        
        self.resume_btn = QPushButton("▶ Resume Simulation")
        self.resume_btn.setStyleSheet(btn_style)
        self.resume_btn.clicked.connect(lambda: self.done(1))
        layout.addWidget(self.resume_btn)
        
        self.mods_btn = QPushButton("📦 Manage Mods")
        self.mods_btn.setStyleSheet(btn_style)
        self.mods_btn.clicked.connect(lambda: self.done(2))
        layout.addWidget(self.mods_btn)
        
        self.achievements_btn = QPushButton("🏆 View Achievements")
        self.achievements_btn.setStyleSheet(btn_style)
        self.achievements_btn.clicked.connect(lambda: self.done(5))
        layout.addWidget(self.achievements_btn)
        
        self.exit_btn = QPushButton("🚪 Exit to Main Menu")
        self.exit_btn.setStyleSheet(btn_style)
        self.exit_btn.clicked.connect(lambda: self.done(3))
        layout.addWidget(self.exit_btn)
        
        self.quit_btn = QPushButton("❌ Quit Game")
        self.quit_btn.setStyleSheet(btn_style)
        self.quit_btn.clicked.connect(lambda: self.done(4))
        layout.addWidget(self.quit_btn)
        
        # Status label
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("color: #888; margin-top: 10px;")
        layout.addWidget(self.status_label)

# ==================== MAIN SIMULATOR CLASS ====================

class ForestSimulator:
    """Main simulator class"""
    
    def __init__(self, config: Configuration = None):
        self.config = config or Configuration()
        self.mod_loader = ModLoader(self.config.get('mods.mods_directory', 'mods'))
        self.forest = []
        self.environment = Environment("Enchanted Forest", self.config)
        self.day = 0
        self.event_manager = EventManager(self.config)
        self.achievement_manager = AchievementManager()
        self.scenario_manager = ScenarioManager()
        self.stats = {
            "rabbits_born": 0,
            "lions_born": 0,
            "deer_born": 0,
            "wolves_born": 0,
            "hunts_successful": 0,
            "hunts_failed": 0,
            "deaths": 0,
            "rabbit_deaths": 0,
            "lion_deaths": 0,
            "deer_deaths": 0,
            "wolf_deaths": 0,
            "starvation_deaths": 0,
            "old_age_deaths": 0,
            "weather_events": {"clear": 0, "rain": 0, "drought": 0, "storm": 0, "mild": 0},
            "plant_consumption": 0,
            "deaths_single_day": 0,
            "mods_loaded": 0,
            "scenarios_completed": 0,
            "multiplayer_win": False
        }
        
        # Load mods if enabled
        if self.config.get('mods.auto_load', True):
            self.load_mods()
        
        # Load achievements
        if self.config.get('achievements.save_progress', True):
            self.achievement_manager.load_progress()
    
    def load_mods(self):
        """Load all mods from mods directory"""
        mod_files = self.mod_loader.discover_mods()
        for mod_file in mod_files:
            mod_info = self.mod_loader.load_mod(mod_file)
            if mod_info and self.config.get('mods.safe_mode', True):
                try:
                    # Create animal class
                    animal_class = ModAnimalFactory.create_animal_class(mod_info)
                    self.mod_loader.animal_classes[mod_info.id] = animal_class
                    AnimalFactory.register_mod_animal(mod_info.id, animal_class, mod_info.data)
                    self.stats['mods_loaded'] += 1
                    print(f"✅ Loaded mod: {mod_info.name}")
                except Exception as e:
                    print(f"❌ Failed to create animal class for {mod_info.name}: {e}")
    
    def initialize_forest(self):
        """Initialize the forest with animals"""
        # Check if we're in a scenario
        if self.scenario_manager.current_scenario:
            setup = self.scenario_manager.current_scenario.initial_setup
            # Apply scenario setup
            for species, count in setup.items():
                if species in ['lions', 'rabbits', 'wolves', 'deer']:
                    species_name = species[:-1].capitalize()  # Remove 's' and capitalize
                    for _ in range(count):
                        animal = AnimalFactory.create_animal(species_name, self.config)
                        animal.age = random.randint(1, 3)
                        self.forest.append(animal)
                elif species == 'plants':
                    self.environment.food_available = count
        else:
            # Normal initialization
            # Lions
            min_lions = self.config.get('initial_population.min_lions', 1)
            max_lions = self.config.get('initial_population.max_lions', 2)
            num_lions = random.randint(min_lions, max_lions)
            for i in range(num_lions):
                lion = AnimalFactory.create_animal("Lion", self.config)
                lion.age = random.randint(1, 5)
                self.forest.append(lion)
            
            # Rabbits
            min_rabbits = self.config.get('initial_population.min_rabbits', 5)
            max_rabbits = self.config.get('initial_population.max_rabbits', 12)
            num_rabbits = random.randint(min_rabbits, max_rabbits)
            for i in range(num_rabbits):
                rabbit = AnimalFactory.create_animal("Rabbit", self.config)
                rabbit.age = random.randint(1, 3)
                self.forest.append(rabbit)
            
            # Wolves (optional)
            wolf_chance = self.config.get('initial_population.wolf_spawn_chance', 0.3)
            if random.random() < wolf_chance:
                min_wolves = self.config.get('initial_population.min_wolves', 0)
                max_wolves = self.config.get('initial_population.max_wolves', 2)
                num_wolves = random.randint(min_wolves, max_wolves)
                for i in range(num_wolves):
                    wolf = AnimalFactory.create_animal("Wolf", self.config)
                    wolf.age = random.randint(1, 4)
                    self.forest.append(wolf)
            
            # Deer (optional)
            deer_chance = self.config.get('initial_population.deer_spawn_chance', 0.4)
            if random.random() < deer_chance:
                min_deer = self.config.get('initial_population.min_deer', 0)
                max_deer = self.config.get('initial_population.max_deer', 3)
                num_deer = random.randint(min_deer, max_deer)
                for i in range(num_deer):
                    deer = AnimalFactory.create_animal("Deer", self.config)
                    deer.age = random.randint(1, 3)
                    self.forest.append(deer)
        
        # Add mod animals if enabled
        if self.config.get('mods.enabled', True):
            for mod_id, animal_class in self.mod_loader.animal_classes.items():
                mod_info = self.mod_loader.loaded_mods.get(mod_id)
                if mod_info and mod_info.enabled:
                    # Random chance to spawn mod animals
                    spawn_chance = 0.3
                    if random.random() < spawn_chance:
                        count = random.randint(0, 2)
                        for _ in range(count):
                            try:
                                animal = AnimalFactory.create_animal(mod_id, self.config)
                                animal.age = random.randint(1, 3)
                                self.forest.append(animal)
                            except Exception as e:
                                print(f"Error spawning mod animal {mod_id}: {e}")
        
        # Assign territories
        for animal in self.forest:
            self.environment.assign_territory(animal)
    
    def simulate_day(self):
        """Simulate one day"""
        self.day += 1
        weather = self.environment.update_weather()
        self.stats["weather_events"][weather.value] += 1
        self.stats["deaths_single_day"] = 0
        
        daily_report = [f"\n{'='*50}", f"DAY {self.day} - {self.environment}", f"{'='*50}"]
        
        # Check for random events
        event_reports = self.event_manager.check_events(self)
        daily_report.extend(event_reports)
        
        # Apply weather to all animals
        weather_effects = []
        for animal in self.forest[:]:
            effect = self.environment.apply_weather_effects(animal)
            if effect > 0:
                weather_effects.append(f"{getattr(animal, 'icon', '🐾')} {animal.name} gained {effect} energy")
            elif effect < 0:
                weather_effects.append(f"{getattr(animal, 'icon', '🐾')} {animal.name} lost {-effect} energy")
        
        if weather_effects:
            daily_report.append("\n🌤️ WEATHER EFFECTS:")
            daily_report.extend(weather_effects)
        
        # Herbivores can eat plants
        herbivores = [a for a in self.forest if a.diet_type in [DietType.HERBIVORE, DietType.OMNIVORE]]
        for herbivore in herbivores:
            plant_food = self.environment.get_plant_food()
            if plant_food > 0:
                herbivore.eat(plant_food)
                self.stats["plant_consumption"] += plant_food
                icon = getattr(herbivore, 'icon', '🌿')
                daily_report.append(f"{icon} {herbivore.name} ate {plant_food} plants")
        
        # Process daily actions
        new_animals = []
        
        # Shuffle to prevent order bias
        random.shuffle(self.forest)
        
        for animal in self.forest[:]:
            if hasattr(animal, 'daily_action'):
                babies, reports = animal.daily_action(self.forest)
                daily_report.extend(reports)
                
                if babies:
                    if isinstance(babies, list):
                        new_animals.extend(babies)
                    else:
                        new_animals.append(babies)
                    
                    # Update birth stats
                    if isinstance(animal, Rabbit):
                        self.stats["rabbits_born"] += 1
                    elif isinstance(animal, Deer):
                        self.stats["deer_born"] = self.stats.get("deer_born", 0) + 1
                    elif isinstance(animal, Wolf):
                        self.stats["wolves_born"] = self.stats.get("wolves_born", 0) + 1
                    elif isinstance(animal, Lion):
                        self.stats["lions_born"] = self.stats.get("lions_born", 0) + 1
        
        # Add newborns to forest
        self.forest.extend(new_animals)
        
        # Check for deaths
        alive_animals = []
        for animal in self.forest:
            if animal.is_alive():
                alive_animals.append(animal)
            else:
                self.stats["deaths"] += 1
                self.stats["deaths_single_day"] += 1
                death_reason = "old age" if animal.age >= 50 else "starvation"
                
                if death_reason == "starvation":
                    self.stats["starvation_deaths"] += 1
                else:
                    self.stats["old_age_deaths"] += 1
                
                icon = getattr(animal, 'icon', '💀')
                
                if isinstance(animal, Lion):
                    self.stats["lion_deaths"] = self.stats.get("lion_deaths", 0) + 1
                    daily_report.append(f"{icon} {animal.name} the Lion died ({death_reason})")
                elif isinstance(animal, Rabbit):
                    self.stats["rabbit_deaths"] += 1
                    daily_report.append(f"{icon} {animal.name} the Rabbit died ({death_reason})")
                elif isinstance(animal, Wolf):
                    self.stats["wolf_deaths"] = self.stats.get("wolf_deaths", 0) + 1
                    daily_report.append(f"{icon} {animal.name} the Wolf died ({death_reason})")
                elif isinstance(animal, Deer):
                    self.stats["deer_deaths"] = self.stats.get("deer_deaths", 0) + 1
                    daily_report.append(f"{icon} {animal.name} the Deer died ({death_reason})")
                else:
                    # Mod animal
                    daily_report.append(f"{icon} {animal.name} the {animal.species} died ({death_reason})")
        
        self.forest = alive_animals
        
        return daily_report
    
    def get_stats_dict(self) -> Dict[str, Any]:
        """Get current statistics as dictionary for achievement checking"""
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        wolves = sum(1 for a in self.forest if isinstance(a, Wolf))
        deer = sum(1 for a in self.forest if isinstance(a, Deer))
        
        # Check for super animal (all traits > 1.8)
        has_super_animal = any(
            all(getattr(a.genes, trait) > 1.8 for trait in ['speed', 'strength', 'fertility', 'longevity', 'metabolism'])
            for a in self.forest
        )
        
        # Check for legendary hunter (lion with 20+ hunts)
        has_legendary_hunter = any(
            isinstance(a, Lion) and a.hunts_successful >= 20
            for a in self.forest
        )
        
        return {
            'day': self.day,
            'rabbits': rabbits,
            'lions': lions,
            'wolves': wolves,
            'deer': deer,
            'total': len(self.forest),
            'has_super_animal': has_super_animal,
            'has_legendary_hunter': has_legendary_hunter,
            'has_custom_mod': self.stats['mods_loaded'] > 0,
            'hunts_successful': self.stats['hunts_successful'],
            'deaths_single_day': self.stats['deaths_single_day'],
            'mods_loaded': self.stats['mods_loaded'],
            'scenarios_completed': len(self.scenario_manager.completed_scenarios),
            'multiplayer_win': self.stats['multiplayer_win']
        }
    
    def get_status_dict(self):
        """Get current status as dictionary for GUI"""
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        wolves = sum(1 for a in self.forest if isinstance(a, Wolf))
        deer = sum(1 for a in self.forest if isinstance(a, Deer))
        mod_animals = sum(1 for a in self.forest if not isinstance(a, (Lion, Rabbit, Wolf, Deer)))
        
        return {
            'day': self.day,
            'rabbits': rabbits,
            'lions': lions,
            'wolves': wolves,
            'deer': deer,
            'mod_animals': mod_animals,
            'total': len(self.forest),
            'plants': self.environment.food_available,
            'weather': self.environment.weather.value,
            'season': self.environment.season.value
        }
    
    def get_final_stats(self):
        """Get final statistics as string"""
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        wolves = sum(1 for a in self.forest if isinstance(a, Wolf))
        deer = sum(1 for a in self.forest if isinstance(a, Deer))
        mod_animals = sum(1 for a in self.forest if not isinstance(a, (Lion, Rabbit, Wolf, Deer)))
        
        stats = f"""
{'='*50}
🏆 FINAL STATISTICS
{'='*50}
Days simulated: {self.day}

Final population:
  🐰 Rabbits: {rabbits}
  🦁 Lions:   {lions}
  🐺 Wolves:  {wolves}
  🦌 Deer:    {deer}
  📦 Mods:    {mod_animals}
  Total:      {len(self.forest)}

Births:
  🐰 Rabbits born: {self.stats.get('rabbits_born', 0)}
  🦌 Deer born:    {self.stats.get('deer_born', 0)}
  🐺 Wolves born:  {self.stats.get('wolves_born', 0)}
  🦁 Lions born:   {self.stats.get('lions_born', 0)}

Deaths:
  💀 Total: {self.stats.get('deaths', 0)}
  💀 Starvation: {self.stats.get('starvation_deaths', 0)}
  💀 Old age: {self.stats.get('old_age_deaths', 0)}

Hunting:
  🎯 Successful: {self.stats.get('hunts_successful', 0)}
  ❌ Failed: {self.stats.get('hunts_failed', 0)}
"""
        return stats
    
    def save_simulation(self, filename="simulation_save.pkl"):
        """Save simulation state"""
        with open(filename, 'wb') as f:
            pickle.dump({
                'forest': self.forest,
                'environment': self.environment,
                'day': self.day,
                'stats': self.stats,
                'config': self.config,
                'achievements': self.achievement_manager,
                'scenario': self.scenario_manager.current_scenario
            }, f)
    
    @classmethod
    def load_simulation(cls, filename="simulation_save.pkl"):
        """Load simulation state"""
        with open(filename, 'rb') as f:
            data = pickle.load(f)
            simulator = cls(data.get('config', Configuration()))
            simulator.forest = data['forest']
            simulator.environment = data['environment']
            simulator.day = data['day']
            simulator.stats = data['stats']
            if 'achievements' in data:
                simulator.achievement_manager = data['achievements']
            if 'scenario' in data and data['scenario']:
                simulator.scenario_manager.current_scenario = data['scenario']
            return simulator

# ==================== GUI MAIN WINDOW ====================

class ForestSimulatorGUI(QMainWindow):
    """Main GUI window for the forest simulator"""
    
    def __init__(self):
        super().__init__()
        self.config = Configuration()
        self.simulator = None
        self.worker = None
        self.thread = None
        self.pause_menu = None
        self.video_exporter = None
        self.multiplayer_server = None
        self.multiplayer_client = None
        self.init_ui()
        
        # Create mods directory
        mods_dir = Path(self.config.get('mods.mods_directory', 'mods'))
        mods_dir.mkdir(exist_ok=True)
        
        self.initialize_simulator()
    
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("🌳 Animals: Wildlife Simulator (V1.6.0)")
        self.setGeometry(100, 100, 1400, 900)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Left panel - Controls
        left_panel = self.create_control_panel()
        main_layout.addWidget(left_panel, 1)
        
        # Right panel - Display
        right_panel = self.create_display_panel()
        main_layout.addWidget(right_panel, 2)
        
        # Apply theme
        if self.config.get('display.dark_theme', True):
            self.apply_dark_theme()
    
    def create_control_panel(self):
        """Create the control panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Simulation controls group
        control_group = QGroupBox("Simulation Controls")
        control_layout = QVBoxLayout()
        
        # Day selection
        day_layout = QHBoxLayout()
        day_layout.addWidget(QLabel("Days to run:"))
        self.day_spinbox = QSpinBox()
        self.day_spinbox.setRange(1, self.config.get('simulation.max_days', 1000))
        self.day_spinbox.setValue(30)
        day_layout.addWidget(self.day_spinbox)
        control_layout.addLayout(day_layout)
        
        # Speed control
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("Speed:"))
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(1, 10)
        self.speed_slider.setValue(self.config.get('simulation.default_speed', 5))
        speed_layout.addWidget(QLabel("Slow"))
        speed_layout.addWidget(self.speed_slider)
        speed_layout.addWidget(QLabel("Fast"))
        control_layout.addLayout(speed_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.start_btn = QPushButton("▶ Start")
        self.start_btn.clicked.connect(self.start_simulation)
        button_layout.addWidget(self.start_btn)
        
        self.pause_btn = QPushButton("⏸ Pause")
        self.pause_btn.clicked.connect(self.pause_simulation)
        self.pause_btn.setEnabled(False)
        button_layout.addWidget(self.pause_btn)
        
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)
        
        control_layout.addLayout(button_layout)
        
        # Step button
        self.step_btn = QPushButton("⏩ Step Day")
        self.step_btn.clicked.connect(self.step_day)
        control_layout.addWidget(self.step_btn)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        # Game Mode group
        mode_group = QGroupBox("Game Mode")
        mode_layout = QVBoxLayout()
        
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["Sandbox", "Scenario", "Multiplayer", "Challenge"])
        self.mode_combo.currentTextChanged.connect(self.on_mode_changed)
        mode_layout.addWidget(self.mode_combo)
        
        self.scenario_btn = QPushButton("📜 Select Scenario")
        self.scenario_btn.clicked.connect(self.select_scenario)
        self.scenario_btn.setEnabled(False)
        mode_layout.addWidget(self.scenario_btn)
        
        self.multiplayer_btn = QPushButton("🌐 Multiplayer")
        self.multiplayer_btn.clicked.connect(self.multiplayer_setup)
        self.multiplayer_btn.setEnabled(False)
        mode_layout.addWidget(self.multiplayer_btn)
        
        mode_group.setLayout(mode_layout)
        layout.addWidget(mode_group)
        
        # Mods group
        mods_group = QGroupBox("Mods")
        mods_layout = QVBoxLayout()
        
        self.manage_mods_btn = QPushButton("📦 Manage Mods")
        self.manage_mods_btn.clicked.connect(self.manage_mods)
        mods_layout.addWidget(self.manage_mods_btn)
        
        self.mod_status_label = QLabel("Mods loaded: 0")
        mods_layout.addWidget(self.mod_status_label)
        
        mods_group.setLayout(mods_layout)
        layout.addWidget(mods_group)
        
        # Achievements group
        ach_group = QGroupBox("Achievements")
        ach_layout = QVBoxLayout()
        
        self.achievements_btn = QPushButton("🏆 View Achievements")
        self.achievements_btn.clicked.connect(self.show_achievements)
        ach_layout.addWidget(self.achievements_btn)
        
        ach_group.setLayout(ach_layout)
        layout.addWidget(ach_group)
        
        # Configuration group
        config_group = QGroupBox("Configuration")
        config_layout = QVBoxLayout()
        
        self.edit_config_btn = QPushButton("⚙ Edit Configuration")
        self.edit_config_btn.clicked.connect(self.edit_configuration)
        config_layout.addWidget(self.edit_config_btn)
        
        self.load_config_btn = QPushButton("📂 Load Config")
        self.load_config_btn.clicked.connect(self.load_configuration)
        config_layout.addWidget(self.load_config_btn)
        
        self.save_config_btn = QPushButton("💾 Save Config")
        self.save_config_btn.clicked.connect(self.save_configuration)
        config_layout.addWidget(self.save_config_btn)
        
        # Format selector
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel("Format:"))
        self.config_format = QComboBox()
        for fmt in OutputFormat:
            self.config_format.addItem(fmt.value)
        format_layout.addWidget(self.config_format)
        config_layout.addLayout(format_layout)
        
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # Initialization group
        init_group = QGroupBox("Initialize")
        init_layout = QVBoxLayout()
        
        self.init_btn = QPushButton("🌱 New Forest")
        self.init_btn.clicked.connect(self.initialize_simulator)
        init_layout.addWidget(self.init_btn)
        
        init_group.setLayout(init_layout)
        layout.addWidget(init_group)
        
        # Save/Load group
        save_group = QGroupBox("Save/Load Simulation")
        save_layout = QVBoxLayout()
        
        self.save_btn = QPushButton("💾 Save Simulation")
        self.save_btn.clicked.connect(self.save_simulation)
        save_layout.addWidget(self.save_btn)
        
        self.load_btn = QPushButton("📂 Load Simulation")
        self.load_btn.clicked.connect(self.load_simulation)
        save_layout.addWidget(self.load_btn)
        
        save_group.setLayout(save_layout)
        layout.addWidget(save_group)
        
        # Export group
        export_group = QGroupBox("Export")
        export_layout = QVBoxLayout()
        
        self.export_video_btn = QPushButton("🎥 Export to Video")
        self.export_video_btn.clicked.connect(self.export_video)
        export_layout.addWidget(self.export_video_btn)
        
        export_group.setLayout(export_layout)
        layout.addWidget(export_group)
        
        # Statistics display
        stats_group = QGroupBox("Current Statistics")
        self.stats_layout = QVBoxLayout()
        
        self.stats_labels = {
            'day': QLabel("Day: 0"),
            'rabbits': QLabel("🐰 Rabbits: 0"),
            'lions': QLabel("🦁 Lions: 0"),
            'wolves': QLabel("🐺 Wolves: 0"),
            'deer': QLabel("🦌 Deer: 0"),
            'mods': QLabel("📦 Mod Animals: 0"),
            'total': QLabel("📊 Total: 0"),
            'plants': QLabel("🌱 Plants: 100"),
            'weather': QLabel("☀️ Weather: Clear"),
            'season': QLabel("🌸 Season: Spring")
        }
        
        for label in self.stats_labels.values():
            self.stats_layout.addWidget(label)
        
        stats_group.setLayout(self.stats_layout)
        layout.addWidget(stats_group)
        
        layout.addStretch()
        return panel
    
    def create_display_panel(self):
        """Create the display panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Tab widget
        tabs = QTabWidget()
        
        # Log tab
        log_widget = QWidget()
        log_layout = QVBoxLayout(log_widget)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier", 10))
        self.log_text.setMaximumBlockCount(self.config.get('display.log_lines', 1000))
        log_layout.addWidget(self.log_text)
        
        tabs.addTab(log_widget, "📋 Event Log")
        
        # Animals tab
        animals_widget = QWidget()
        animals_layout = QVBoxLayout(animals_widget)
        
        self.animals_table = QTableWidget()
        self.animals_table.setColumnCount(8)
        self.animals_table.setHorizontalHeaderLabels(["Icon", "Species", "Name", "Energy", "Age", "Diet", "Territory", "Traits"])
        self.animals_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        animals_layout.addWidget(self.animals_table)
        
        tabs.addTab(animals_widget, "🐾 Animals")
        
        # Statistics tab
        stats_widget = QWidget()
        stats_layout = QVBoxLayout(stats_widget)
        
        self.stats_table = QTableWidget()
        self.stats_table.setColumnCount(2)
        self.stats_table.setHorizontalHeaderLabels(["Statistic", "Value"])
        self.stats_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        stats_layout.addWidget(self.stats_table)
        
        tabs.addTab(stats_widget, "📊 Statistics")
        
        # Territories tab
        territories_widget = QWidget()
        territories_layout = QVBoxLayout(territories_widget)
        
        self.territories_table = QTableWidget()
        self.territories_table.setColumnCount(5)
        self.territories_table.setHorizontalHeaderLabels(["Territory", "Size", "Occupants", "Resources", "Owner"])
        self.territories_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        territories_layout.addWidget(self.territories_table)
        
        tabs.addTab(territories_widget, "🗺 Territories")
        
        # Mods tab
        mods_widget = QWidget()
        mods_layout = QVBoxLayout(mods_widget)
        
        self.mods_table = QTableWidget()
        self.mods_table.setColumnCount(4)
        self.mods_table.setHorizontalHeaderLabels(["Mod", "Species", "Diet", "Status"])
        self.mods_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        mods_layout.addWidget(self.mods_table)
        
        tabs.addTab(mods_widget, "📦 Loaded Mods")
        
        # Achievements tab
        ach_widget = QWidget()
        ach_layout = QVBoxLayout(ach_widget)
        
        self.achievements_table = QTableWidget()
        self.achievements_table.setColumnCount(5)
        self.achievements_table.setHorizontalHeaderLabels(["Icon", "Achievement", "Description", "Rarity", "Progress"])
        self.achievements_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        ach_layout.addWidget(self.achievements_table)
        
        tabs.addTab(ach_widget, "🏆 Achievements")
        
        layout.addWidget(tabs)
        
        return panel
    
    def apply_dark_theme(self):
        """Apply dark theme to the application"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2b2b2b;
            }
            QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
                font-size: 12px;
            }
            QGroupBox {
                border: 2px solid #555;
                border-radius: 5px;
                margin-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QPushButton {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 5px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #4a4a4a;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
            QTextEdit {
                background-color: #1e1e1e;
                border: 1px solid #555;
                border-radius: 3px;
            }
            QTableWidget {
                background-color: #1e1e1e;
                border: 1px solid #555;
                gridline-color: #555;
            }
            QHeaderView::section {
                background-color: #3c3c3c;
                padding: 5px;
                border: 1px solid #555;
            }
            QSpinBox, QDoubleSpinBox, QComboBox, QLineEdit {
                background-color: #1e1e1e;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 2px;
                color: #ffffff;
            }
            QSlider::groove:horizontal {
                border: 1px solid #555;
                height: 8px;
                background: #1e1e1e;
                margin: 2px 0;
                border-radius: 4px;
            }
            QSlider::handle:horizontal {
                background: #4a90e2;
                border: 1px solid #5a5a5a;
                width: 18px;
                margin: -2px 0;
                border-radius: 9px;
            }
            QProgressBar {
                border: 1px solid #555;
                border-radius: 3px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #4a90e2;
                border-radius: 2px;
            }
            QTabWidget::pane {
                border: 1px solid #555;
                background-color: #2b2b2b;
            }
            QTabBar::tab {
                background-color: #3c3c3c;
                padding: 5px 10px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: #4a4a4a;
            }
            QDialog {
                background-color: #2b2b2b;
            }
            QRadioButton {
                color: #ffffff;
            }
            QCheckBox {
                color: #ffffff;
            }
        """)
    
    def on_mode_changed(self, mode):
        """Handle game mode change"""
        self.scenario_btn.setEnabled(mode == "Scenario")
        self.multiplayer_btn.setEnabled(mode == "Multiplayer")
    
    def select_scenario(self):
        """Open scenario selector"""
        if self.simulator:
            dialog = ScenarioDialog(self.simulator.scenario_manager, self)
            dialog.scenario_selected.connect(self.start_scenario)
            dialog.exec()
    
    def start_scenario(self, scenario_id):
        """Start a scenario"""
        if self.simulator:
            self.simulator.scenario_manager.start_scenario(scenario_id)
            self.initialize_simulator()
            self.add_log(f"📜 Starting scenario: {self.simulator.scenario_manager.current_scenario.name}")
    
    def multiplayer_setup(self):
        """Open multiplayer setup dialog"""
        dialog = MultiplayerDialog(self)
        dialog.join_game.connect(self.join_multiplayer)
        dialog.host_game.connect(self.host_multiplayer)
        if dialog.exec() == QDialog.Accepted:
            self.add_log("🌐 Starting multiplayer game...")
    
    def host_multiplayer(self, port, max_players, mode):
        """Host a multiplayer game"""
        self.multiplayer_server = MultiplayerServer(port=port, max_players=max_players)
        self.multiplayer_server.game_started.connect(lambda: self.add_log("🎮 Multiplayer game started!"))
        self.multiplayer_server.start()
        
        # Connect as client
        self.multiplayer_client = MultiplayerClient(port=port)
        self.multiplayer_client.system_message.connect(self.add_log)
        self.multiplayer_client.game_started.connect(self.on_multiplayer_game_started)
        self.multiplayer_client.start()
    
    def join_multiplayer(self, host, port, player_name):
        """Join a multiplayer game"""
        self.multiplayer_client = MultiplayerClient(host, port)
        self.multiplayer_client.system_message.connect(self.add_log)
        self.multiplayer_client.game_started.connect(self.on_multiplayer_game_started)
        self.multiplayer_client.chat_received.connect(self.on_chat_received)
        self.multiplayer_client.start()
    
    def on_multiplayer_game_started(self, config):
        """Handle multiplayer game started"""
        self.add_log("🎮 Connected to multiplayer game!")
        # Start simulation in multiplayer mode
        
    def on_chat_received(self, player, message):
        """Handle chat message"""
        self.add_log(f"💬 {player}: {message}")
    
    def show_achievements(self):
        """Show achievements dialog"""
        if self.simulator:
            dialog = AchievementsDialog(self.simulator.achievement_manager, self)
            dialog.exec()
    
    def export_video(self):
        """Export simulation to video"""
        if not self.simulator or self.simulator.day == 0:
            QMessageBox.warning(self, "Warning", "No simulation data to export!")
            return
        
        dialog = VideoExportDialog(self.simulator, self)
        dialog.exec()
    
    def initialize_simulator(self):
        """Initialize a new simulator with current config"""
        self.simulator = ForestSimulator(self.config)
        self.simulator.initialize_forest()
        self.update_display()
        self.update_mod_status()
        self.update_achievements_table()
        self.log_text.clear()
        self.add_log("🌳 New forest initialized!")
        self.add_log(f"Configuration loaded from: {self.config.config_path or 'defaults'}")
        self.add_log(f"Mods loaded: {len(self.simulator.mod_loader.loaded_mods)}")
        
        # Show scenario info if active
        if self.simulator.scenario_manager.current_scenario:
            scenario = self.simulator.scenario_manager.current_scenario
            self.add_log(f"📜 Scenario: {scenario.name}")
            self.add_log(f"🎯 Objectives:")
            for obj in scenario.objectives:
                self.add_log(f"  • {obj.description}")
    
    def update_mod_status(self):
        """Update mod status display"""
        if self.simulator:
            mod_count = len(self.simulator.mod_loader.loaded_mods)
            self.mod_status_label.setText(f"Mods loaded: {mod_count}")
            self.update_mods_table()
    
    def update_mods_table(self):
        """Update the mods table"""
        if not self.simulator:
            return
            
        mods = self.simulator.mod_loader.get_all_mods()
        self.mods_table.setRowCount(len(mods))
        
        for i, mod in enumerate(mods):
            self.mods_table.setItem(i, 0, QTableWidgetItem(mod.name))
            self.mods_table.setItem(i, 1, QTableWidgetItem(mod.id))
            self.mods_table.setItem(i, 2, QTableWidgetItem(mod.data.get('diet_type', 'unknown')))
            
            status = "✅ Enabled" if mod.enabled else "❌ Disabled"
            if mod.error:
                status += f" (⚠️ {mod.error})"
            self.mods_table.setItem(i, 3, QTableWidgetItem(status))
    
    def update_achievements_table(self):
        """Update the achievements table"""
        if not self.simulator:
            return
            
        achievements = list(self.simulator.achievement_manager.achievements.values())
        self.achievements_table.setRowCount(len(achievements))
        
        for i, ach in enumerate(achievements):
            # Icon
            icon_item = QTableWidgetItem(ach.icon)
            icon_item.setTextAlignment(Qt.AlignCenter)
            self.achievements_table.setItem(i, 0, icon_item)
            
            # Name
            name_item = QTableWidgetItem(ach.name)
            if ach.unlocked:
                name_item.setForeground(QColor(255, 215, 0))  # Gold
            self.achievements_table.setItem(i, 1, name_item)
            
            # Description
            desc = ach.description
            if ach.secret and not ach.unlocked:
                desc = "???"
            self.achievements_table.setItem(i, 2, QTableWidgetItem(desc))
            
            # Rarity
            rarity_item = QTableWidgetItem(ach.rarity.value)
            rarity_colors = {
                AchievementRarity.COMMON: QColor(200, 200, 200),
                AchievementRarity.UNCOMMON: QColor(0, 255, 0),
                AchievementRarity.RARE: QColor(0, 0, 255),
                AchievementRarity.EPIC: QColor(128, 0, 128),
                AchievementRarity.LEGENDARY: QColor(255, 215, 0)
            }
            rarity_item.setForeground(rarity_colors.get(ach.rarity, QColor(255, 255, 255)))
            self.achievements_table.setItem(i, 3, rarity_item)
            
            # Progress
            if ach.progress_max:
                progress = f"{ach.progress}/{ach.progress_max}"
            else:
                progress = "✓" if ach.unlocked else "✗"
            self.achievements_table.setItem(i, 4, QTableWidgetItem(progress))
    
    def manage_mods(self):
        """Open mod manager dialog"""
        if self.simulator:
            dialog = ModManagerDialog(self.simulator.mod_loader, self.config, self)
            dialog.mods_changed.connect(self.on_mods_changed)
            dialog.exec()
    
    def on_mods_changed(self):
        """Handle mods changed signal"""
        self.update_mod_status()
        self.add_log("📦 Mods updated!")
    
    def start_simulation(self):
        """Start the simulation"""
        if not self.simulator or not self.simulator.forest:
            self.initialize_simulator()
        
        self.start_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.stop_btn.setEnabled(True)
        self.init_btn.setEnabled(False)
        self.step_btn.setEnabled(False)
        self.manage_mods_btn.setEnabled(False)
        self.edit_config_btn.setEnabled(False)
        self.scenario_btn.setEnabled(False)
        self.multiplayer_btn.setEnabled(False)
        self.achievements_btn.setEnabled(False)
        
        # Create and start worker thread
        self.worker = SimulationWorker(self.simulator)
        self.worker.update_signal.connect(self.add_log)
        self.worker.status_signal.connect(self.update_stats)
        self.worker.achievement_signal.connect(self.on_achievement_unlocked)
        self.worker.finished.connect(self.simulation_finished)
        self.worker.paused_signal.connect(self.show_pause_menu)
        
        # Set speed
        self.worker.speed = self.speed_slider.value()
        
        # Start in separate thread
        self.thread = QThread()
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        
        self.thread.start()
    
    def on_achievement_unlocked(self, achievement):
        """Handle achievement unlocked"""
        self.update_achievements_table()
        if self.config.get('achievements.save_progress', True):
            self.simulator.achievement_manager.save_progress()
    
    def pause_simulation(self):
        """Pause/resume the simulation"""
        if self.worker:
            self.worker.pause()
            self.pause_btn.setText("▶ Resume" if self.worker.paused else "⏸ Pause")
    
    def show_pause_menu(self):
        """Show the pause menu dialog"""
        if not self.pause_menu:
            self.pause_menu = PauseMenuDialog(self)
            result = self.pause_menu.exec()
            self.handle_pause_menu_result(result)
            self.pause_menu = None
    
    def handle_pause_menu_result(self, result):
        """Handle pause menu result"""
        if result == 1:  # Resume
            self.worker.pause()  # Toggle pause off
            self.pause_btn.setText("⏸ Pause")
        elif result == 2:  # Manage Mods
            self.manage_mods()
            # Show pause menu again
            self.show_pause_menu()
        elif result == 3:  # Exit to Main Menu
            self.stop_simulation()
            self.initialize_simulator()
        elif result == 4:  # Quit Game
            self.close()
        elif result == 5:  # View Achievements
            self.show_achievements()
            self.show_pause_menu()
    
    def stop_simulation(self):
        """Stop the simulation"""
        if self.worker:
            self.worker.stop()
            if self.thread:
                self.thread.quit()
                self.thread.wait()
            
            self.start_btn.setEnabled(True)
            self.pause_btn.setEnabled(False)
            self.stop_btn.setEnabled(False)
            self.init_btn.setEnabled(True)
            self.step_btn.setEnabled(True)
            self.manage_mods_btn.setEnabled(True)
            self.edit_config_btn.setEnabled(True)
            self.scenario_btn.setEnabled(self.mode_combo.currentText() == "Scenario")
            self.multiplayer_btn.setEnabled(self.mode_combo.currentText() == "Multiplayer")
            self.achievements_btn.setEnabled(True)
            self.pause_btn.setText("⏸ Pause")
    
    def step_day(self):
        """Run one day of simulation"""
        if self.simulator and self.simulator.forest:
            reports = self.simulator.simulate_day()
            
            # Check achievements
            if self.config.get('achievements.enabled', True):
                stats = self.simulator.get_stats_dict()
                new_achievements = self.simulator.achievement_manager.check_achievements(stats)
                for ach in new_achievements:
                    self.on_achievement_unlocked(ach)
                    reports.append(f"🏆 Achievement Unlocked: {ach.name}!")
            
            for report in reports:
                self.add_log(report)
            self.update_display()
    
    def simulation_finished(self):
        """Called when simulation finishes"""
        self.start_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.stop_btn.setEnabled(False)
        self.init_btn.setEnabled(True)
        self.step_btn.setEnabled(True)
        self.manage_mods_btn.setEnabled(True)
        self.edit_config_btn.setEnabled(True)
        self.scenario_btn.setEnabled(self.mode_combo.currentText() == "Scenario")
        self.multiplayer_btn.setEnabled(self.mode_combo.currentText() == "Multiplayer")
        self.achievements_btn.setEnabled(True)
        self.pause_btn.setText("⏸ Pause")
        
        self.add_log("\n🏁 Simulation finished!")
        if self.simulator:
            self.add_log(self.simulator.get_final_stats())
            
            # Save achievements
            if self.config.get('achievements.save_progress', True):
                self.simulator.achievement_manager.save_progress()
    
    def add_log(self, message):
        """Add message to log"""
        self.log_text.append(message)
        # Scroll to bottom
        cursor = self.log_text.textCursor()
        cursor.movePosition(cursor.End)
        self.log_text.setTextCursor(cursor)
    
    def update_display(self):
        """Update all display elements"""
        if self.simulator:
            self.update_stats(self.simulator.get_status_dict())
            self.update_animals_table()
            self.update_stats_table()
            self.update_territories_table()
            self.update_mods_table()
            self.update_achievements_table()
    
    def update_stats(self, stats):
        """Update statistics display"""
        self.stats_labels['day'].setText(f"Day: {stats['day']}")
        self.stats_labels['rabbits'].setText(f"🐰 Rabbits: {stats['rabbits']}")
        self.stats_labels['lions'].setText(f"🦁 Lions: {stats['lions']}")
        self.stats_labels['wolves'].setText(f"🐺 Wolves: {stats['wolves']}")
        self.stats_labels['deer'].setText(f"🦌 Deer: {stats['deer']}")
        self.stats_labels['mods'].setText(f"📦 Mod Animals: {stats['mod_animals']}")
        self.stats_labels['total'].setText(f"📊 Total: {stats['total']}")
        self.stats_labels['plants'].setText(f"🌱 Plants: {stats['plants']}")
        self.stats_labels['weather'].setText(f"☀️ Weather: {stats['weather'].capitalize()}")
        self.stats_labels['season'].setText(f"🌸 Season: {stats['season'].capitalize()}")
    
    def update_animals_table(self):
        """Update the animals table"""
        if not self.simulator:
            return
            
        self.animals_table.setRowCount(len(self.simulator.forest))
        
        for i, animal in enumerate(self.simulator.forest):
            icon = getattr(animal, 'icon', '🐾')
            icon_item = QTableWidgetItem(icon)
            icon_item.setTextAlignment(Qt.AlignCenter)
            
            species_item = QTableWidgetItem(animal.species)
            name_item = QTableWidgetItem(animal.name)
            energy_item = QTableWidgetItem(str(animal.energy))
            age_item = QTableWidgetItem(str(animal.age))
            diet_item = QTableWidgetItem(animal.diet_type.value if hasattr(animal, 'diet_type') else 'unknown')
            
            # Color code energy
            if animal.energy < 20:
                energy_item.setForeground(QColor(255, 100, 100))
            elif animal.energy > 50:
                energy_item.setForeground(QColor(100, 255, 100))
            
            # Territory
            territory_item = QTableWidgetItem(animal.territory.name if animal.territory else "None")
            
            # Traits
            if hasattr(animal, 'genes') and self.config.get('display.show_genetics', True):
                traits = animal.genes.to_dict()
                traits_str = f"S:{traits['speed']:.1f} St:{traits['strength']:.1f} F:{traits['fertility']:.1f}"
            else:
                traits_str = "-"
            traits_item = QTableWidgetItem(traits_str)
            
            self.animals_table.setItem(i, 0, icon_item)
            self.animals_table.setItem(i, 1, species_item)
            self.animals_table.setItem(i, 2, name_item)
            self.animals_table.setItem(i, 3, energy_item)
            self.animals_table.setItem(i, 4, age_item)
            self.animals_table.setItem(i, 5, diet_item)
            self.animals_table.setItem(i, 6, territory_item)
            self.animals_table.setItem(i, 7, traits_item)
    
    def update_stats_table(self):
        """Update the statistics table"""
        if not self.simulator:
            return
            
        stats = self.simulator.stats
        self.stats_table.setRowCount(24)
        
        stat_items = [
            ("Total Days", str(self.simulator.day)),
            ("Total Animals", str(len(self.simulator.forest))),
            ("Total Births", str(stats.get('rabbits_born', 0) + stats.get('deer_born', 0) + stats.get('wolves_born', 0) + stats.get('lions_born', 0))),
            ("🐰 Rabbits Born", str(stats.get('rabbits_born', 0))),
            ("🦌 Deer Born", str(stats.get('deer_born', 0))),
            ("🐺 Wolves Born", str(stats.get('wolves_born', 0))),
            ("🦁 Lions Born", str(stats.get('lions_born', 0))),
            ("Total Deaths", str(stats.get('deaths', 0))),
            ("💀 Starvation", str(stats.get('starvation_deaths', 0))),
            ("💀 Old Age", str(stats.get('old_age_deaths', 0))),
            ("🎯 Successful Hunts", str(stats.get('hunts_successful', 0))),
            ("❌ Failed Hunts", str(stats.get('hunts_failed', 0))),
            ("🌱 Plant Consumption", str(stats.get('plant_consumption', 0))),
            ("☀️ Clear Days", str(stats.get('weather_events', {}).get('clear', 0))),
            ("🌧️ Rainy Days", str(stats.get('weather_events', {}).get('rain', 0))),
            ("🏜️ Drought Days", str(stats.get('weather_events', {}).get('drought', 0))),
            ("🌪️ Storm Days", str(stats.get('weather_events', {}).get('storm', 0))),
            ("😐 Mild Days", str(stats.get('weather_events', {}).get('mild', 0))),
            ("📦 Mods Loaded", str(stats.get('mods_loaded', 0))),
            ("🏆 Achievements Unlocked", str(sum(1 for a in self.simulator.achievement_manager.achievements.values() if a.unlocked))),
            ("📜 Scenarios Completed", str(len(self.simulator.scenario_manager.completed_scenarios))),
            ("📜 Scenario Active", "Yes" if self.simulator.scenario_manager.current_scenario else "No")
        ]
        
        for i, (label, value) in enumerate(stat_items):
            self.stats_table.setItem(i, 0, QTableWidgetItem(label))
            self.stats_table.setItem(i, 1, QTableWidgetItem(value))
    
    def update_territories_table(self):
        """Update the territories table"""
        if not self.simulator or not self.simulator.environment:
            return
            
        territories = self.simulator.environment.territories
        self.territories_table.setRowCount(len(territories))
        
        for i, territory in enumerate(territories):
            self.territories_table.setItem(i, 0, QTableWidgetItem(territory.name))
            self.territories_table.setItem(i, 1, QTableWidgetItem(str(territory.size)))
            self.territories_table.setItem(i, 2, QTableWidgetItem(str(len(territory.occupants))))
            self.territories_table.setItem(i, 3, QTableWidgetItem(str(int(territory.resources))))
            self.territories_table.setItem(i, 4, QTableWidgetItem(
                territory.owner.name if territory.owner else "Unowned"
            ))
    
    def edit_configuration(self):
        """Open configuration editor"""
        dialog = ConfigurationEditorDialog(self.config, self)
        if dialog.exec() == QDialog.Accepted:
            # Apply new config
            if self.config.get('display.dark_theme', True):
                self.apply_dark_theme()
            self.day_spinbox.setRange(1, self.config.get('simulation.max_days', 1000))
            self.speed_slider.setValue(self.config.get('simulation.default_speed', 5))
            self.add_log("⚙ Configuration updated")
    
    def load_configuration(self):
        """Load configuration from file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Configuration", "", 
            "Config Files (*.json *.hjson *.msgpack *.bson *.xml *.toml *.yaml *.yml);;All Files (*)"
        )
        
        if file_path:
            if self.config.load(file_path):
                self.add_log(f"✅ Configuration loaded from {file_path}")
                # Update UI with new config
                if self.config.get('display.dark_theme', True):
                    self.apply_dark_theme()
                self.day_spinbox.setRange(1, self.config.get('simulation.max_days', 1000))
                self.speed_slider.setValue(self.config.get('simulation.default_speed', 5))
            else:
                QMessageBox.warning(self, "Error", f"Failed to load configuration from {file_path}")
    
    def save_configuration(self):
        """Save configuration to file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Configuration", "config",
            f"JSON (*.json);;HJSON (*.hjson);;MessagePack (*.msgpack);;BSON (*.bson);;XML (*.xml);;TOML (*.toml);;YAML (*.yaml);;Pickle (*.pkl)"
        )
        
        if file_path:
            # Get selected format from file extension
            suffix = Path(file_path).suffix[1:]  # Remove the dot
            try:
                format_enum = OutputFormat(suffix)
            except ValueError:
                format_enum = OutputFormat.JSON
                file_path += '.json'
            
            if self.config.save(file_path, format_enum):
                self.add_log(f"✅ Configuration saved to {file_path}")
            else:
                QMessageBox.warning(self, "Error", f"Failed to save configuration to {file_path}")
    
    def save_simulation(self):
        """Save the simulation state"""
        if not self.simulator:
            return
            
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Simulation", "simulation", "Pickle Files (*.pkl)"
        )
        
        if file_path:
            self.simulator.save_simulation(file_path)
            self.add_log(f"💾 Simulation saved to {file_path}")
    
    def load_simulation(self):
        """Load a saved simulation"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Simulation", "", "Pickle Files (*.pkl)"
        )
        
        if file_path:
            try:
                self.simulator = ForestSimulator.load_simulation(file_path)
                self.config = self.simulator.config
                self.update_display()
                self.update_mod_status()
                self.update_achievements_table()
                self.add_log(f"📂 Simulation loaded from {file_path}")
                
                # Show scenario info if active
                if self.simulator.scenario_manager.current_scenario:
                    scenario = self.simulator.scenario_manager.current_scenario
                    self.add_log(f"📜 Scenario: {scenario.name}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load simulation: {e}")

# ==================== MAIN ====================

def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    
    # Create and show GUI
    gui = ForestSimulatorGUI()
    gui.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()