import random
import json
import pickle
import xml.etree.ElementTree as ET
import tomllib  # Python 3.11+ for TOML
import msgpack
import bson
import hjson
import yaml
from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Type
import sys
import types
import importlib.util
import traceback
from dataclasses import dataclass
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                               QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                               QSpinBox, QGroupBox, QGridLayout, QProgressBar,
                               QTabWidget, QTableWidget, QTableWidgetItem,
                               QHeaderView, QComboBox, QFileDialog, QMessageBox,
                               QSplitter, QFrame, QCheckBox, QLineEdit,
                               QDialog, QDialogButtonBox, QListWidget, QListWidgetItem,
                               QScrollArea, QFormLayout)
from PySide6.QtCore import QTimer, Qt, Signal, QObject, QThread
from PySide6.QtGui import QFont, QColor, QPalette, QIcon

# ==================== ENUMS AND CONSTANTS ====================

class Season(Enum):
    SPRING = "spring"
    SUMMER = "summer"
    AUTUMN = "autumn"
    WINTER = "winter"

class Weather(Enum):
    CLEAR = "clear"
    RAIN = "rain"
    DROUGHT = "drought"
    STORM = "storm"
    MILD = "mild"

class DietType(Enum):
    CARNIVORE = "carnivore"
    HERBIVORE = "herbivore"
    OMNIVORE = "omnivore"

class OutputFormat(Enum):
    JSON = "json"
    HJSON = "hjson"
    MESSAGEPACK = "msgpack"
    BSON = "bson"
    XML = "xml"
    TOML = "toml"
    YAML = "yaml"
    PICKLE = "pickle"

# ==================== MOD SYSTEM ====================

class ModError(Exception):
    """Exception raised for mod-related errors"""
    pass

class SafeScriptExecutor:
    """Execute mod scripts in a sandboxed environment"""
    
    ALLOWED_MODULES = ['random', 'math', 'itertools']
    FORBIDDEN_KEYWORDS = ['__import__', 'eval', 'exec', 'open', 'file', 'system', 
                         'subprocess', 'os.', 'sys.', 'globals', 'locals']
    
    @classmethod
    def create_safe_globals(cls, animal, forest):
        """Create safe execution environment"""
        safe_globals = {
            'random': random,
            'animal': animal,
            'forest': forest,
            'len': len,
            'range': range,
            'int': int,
            'float': float,
            'str': str,
            'list': list,
            'dict': dict,
            'min': min,
            'max': max,
            'sum': sum,
            'abs': abs,
            'round': round,
            'enumerate': enumerate,
            'zip': zip,
            'sorted': sorted,
            'any': any,
            'all': all
        }
        
        # Add allowed modules
        for module_name in cls.ALLOWED_MODULES:
            try:
                safe_globals[module_name] = __import__(module_name)
            except ImportError:
                pass
        
        return safe_globals
    
    @classmethod
    def validate_script(cls, script):
        """Check script for dangerous operations"""
        if not script:
            return True
            
        for keyword in cls.FORBIDDEN_KEYWORDS:
            if keyword in script:
                raise ModError(f"Forbidden keyword in script: {keyword}")
        
        # Check for dangerous patterns
        dangerous_patterns = ['__', 'exec(', 'eval(', 'open(', 'write(', 'os.', 'sys.']
        for pattern in dangerous_patterns:
            if pattern in script:
                raise ModError(f"Dangerous pattern in script: {pattern}")
        
        return True
    
    @classmethod
    def execute_function(cls, script, func_name, animal, forest, *args, **kwargs):
        """Execute a function from script safely"""
        if not script:
            return None
            
        try:
            # Validate script first
            cls.validate_script(script)
            
            # Create safe globals
            safe_globals = cls.create_safe_globals(animal, forest)
            
            # Compile and execute script
            code = compile(script, '<mod_script>', 'exec')
            exec(code, safe_globals)
            
            # Get function if it exists
            if func_name in safe_globals and callable(safe_globals[func_name]):
                func = safe_globals[func_name]
                # Create bound method if it's a function that expects self
                if func_name == 'special_action':
                    # Bind method to animal instance
                    bound_func = types.MethodType(func, animal)
                    return bound_func(forest, *args, **kwargs)
                return func(animal, forest, *args, **kwargs)
            
            return None
            
        except Exception as e:
            print(f"Error executing mod script: {e}")
            traceback.print_exc()
            return f"❌ Script error: {str(e)}"

@dataclass
class ModInfo:
    """Information about a loaded mod"""
    id: str
    name: str
    file_path: str
    format: OutputFormat
    data: dict
    animal_class: Type = None
    enabled: bool = True
    load_time: float = 0
    error: str = None

class ModLoader:
    """Discovers and loads mod files from multiple formats"""
    
    SUPPORTED_FORMATS = {
        '.yaml': OutputFormat.YAML,
        '.yml': OutputFormat.YAML,
        '.hjson': OutputFormat.HJSON,
        '.msgpack': OutputFormat.MESSAGEPACK,
        '.bson': OutputFormat.BSON,
        '.xml': OutputFormat.XML,
        '.toml': OutputFormat.TOML,
        '.json': OutputFormat.JSON,
        '.pkl': OutputFormat.PICKLE
    }
    
    def __init__(self, mods_directory="mods"):
        self.mods_directory = Path(mods_directory)
        self.mods_directory.mkdir(exist_ok=True)
        self.loaded_mods: Dict[str, ModInfo] = {}
        self.animal_classes: Dict[str, Type] = {}
        self.mod_errors = []
    
    def discover_mods(self):
        """Scan mods directory for supported files"""
        mod_files = []
        for ext in self.SUPPORTED_FORMATS.keys():
            mod_files.extend(self.mods_directory.glob(f"*{ext}"))
        return mod_files
    
    def load_mod(self, filepath: Union[str, Path]) -> Optional[ModInfo]:
        """Load a single mod file (auto-detect format)"""
        filepath = Path(filepath)
        try:
            # Detect format
            ext = filepath.suffix.lower()
            if ext not in self.SUPPORTED_FORMATS:
                raise ModError(f"Unsupported file format: {ext}")
            
            format_type = self.SUPPORTED_FORMATS[ext]
            
            # Parse file
            data = self._parse_file(filepath, format_type)
            
            # Validate mod data
            self._validate_mod_data(data)
            
            # Create mod info
            mod_id = data.get('species_id', data['name'].lower().replace(' ', '_'))
            mod_info = ModInfo(
                id=mod_id,
                name=data['name'],
                file_path=str(filepath),
                format=format_type,
                data=data
            )
            
            self.loaded_mods[mod_id] = mod_info
            return mod_info
            
        except Exception as e:
            error_msg = f"Failed to load mod {filepath.name}: {str(e)}"
            print(error_msg)
            traceback.print_exc()
            self.mod_errors.append((filepath.name, str(e)))
            return None
    
    def _parse_file(self, filepath: Path, format_type: OutputFormat) -> dict:
        """Parse file based on format"""
        with open(filepath, 'rb') as f:
            if format_type == OutputFormat.JSON:
                return json.load(f)
            elif format_type == OutputFormat.HJSON:
                return hjson.load(f)
            elif format_type == OutputFormat.MESSAGEPACK:
                return msgpack.unpackb(f.read())
            elif format_type == OutputFormat.BSON:
                return bson.decode(f.read())
            elif format_type == OutputFormat.YAML:
                return yaml.safe_load(f)
            elif format_type == OutputFormat.XML:
                return self._parse_xml(f)
            elif format_type == OutputFormat.TOML:
                return tomllib.load(f)
            elif format_type == OutputFormat.PICKLE:
                return pickle.load(f)
    
    def _parse_xml(self, file) -> dict:
        """Parse XML to dict"""
        tree = ET.parse(file)
        root = tree.getroot()
        return self._xml_to_dict(root)
    
    def _xml_to_dict(self, element) -> dict:
        """Convert XML element to dictionary"""
        result = {}
        for child in element:
            if len(child):
                result[child.tag] = self._xml_to_dict(child)
            else:
                # Try to convert to appropriate type
                text = child.text
                if text is None:
                    result[child.tag] = None
                elif text.isdigit():
                    result[child.tag] = int(text)
                elif text.replace('.', '').isdigit():
                    result[child.tag] = float(text)
                elif text.lower() in ['true', 'false']:
                    result[child.tag] = text.lower() == 'true'
                else:
                    result[child.tag] = text
        return result
    
    def _validate_mod_data(self, data: dict):
        """Validate mod data has required fields"""
        required_fields = ['name', 'diet_type', 'base_stats']
        
        for field in required_fields:
            if field not in data:
                raise ModError(f"Missing required field: {field}")
        
        # Validate diet type
        if data['diet_type'] not in [dt.value for dt in DietType]:
            raise ModError(f"Invalid diet type: {data['diet_type']}")
        
        # Validate base stats
        base_stats = data['base_stats']
        if 'energy_range' not in base_stats:
            raise ModError("Missing energy_range in base_stats")
        
        # Validate script if present
        if 'special_ability' in data and 'script' in data['special_ability']:
            SafeScriptExecutor.validate_script(data['special_ability']['script'])
    
    def unload_mod(self, mod_id: str):
        """Unload a mod"""
        if mod_id in self.loaded_mods:
            # Remove animal class
            if mod_id in self.animal_classes:
                del self.animal_classes[mod_id]
            # Remove mod info
            del self.loaded_mods[mod_id]
            return True
        return False
    
    def get_all_mods(self) -> List[ModInfo]:
        """Get all loaded mods"""
        return list(self.loaded_mods.values())
    
    def reload_mod(self, mod_id: str) -> Optional[ModInfo]:
        """Reload a mod from its file"""
        if mod_id in self.loaded_mods:
            file_path = self.loaded_mods[mod_id].file_path
            self.unload_mod(mod_id)
            return self.load_mod(file_path)
        return None

class ModAnimalFactory:
    """Creates animal classes from mod definitions"""
    
    @staticmethod
    def create_animal_class(mod_info: ModInfo) -> Type:
        """Dynamically create a new animal class from mod data"""
        
        data = mod_info.data
        class_name = data['name'].replace(' ', '').replace('-', '_')
        diet_type = DietType(data['diet_type'])
        
        # Define the new class
        class ModAnimal(Animal):
            mod_info = mod_info  # Attach mod info to class
            
            def __init__(self, name, energy, config):
                super().__init__(name, energy, data['name'], config)
                
                # Set stats from mod
                self.icon = data.get('icon', '🐾')
                self.diet_type = diet_type
                self.special_ability_cooldown = 0
                self.mod_data = data
                
                # Load base stats
                base_stats = data.get('base_stats', {})
                self.metabolism_rate = base_stats.get('metabolism_rate', 1.0)
                self.base_energy = base_stats.get('base_energy', 30)
                
                # Load behavior stats
                behavior = data.get('behavior', {})
                self.hunt_success_rate = behavior.get('hunt_success_rate', 0.5)
                self.pack_bonus = behavior.get('pack_bonus', 0.0)
                self.hunger_threshold = behavior.get('hunger_threshold', 15)
                self.territorial = behavior.get('territorial', True)
                self.herd_animal = behavior.get('herd_animal', False)
                self.flee_chance = behavior.get('flee_chance', 0.5)
                self.can_fly = behavior.get('can_fly', False)
                self.hibernation = behavior.get('hibernation', False)
                
                # Load reproduction data
                self.reproduction_data = data.get('reproduction', {})
                
                # Load special ability
                self.special_ability_data = data.get('special_ability', {})
                if self.special_ability_data and 'script' in self.special_ability_data:
                    self.ability_script = self.special_ability_data['script']
                    self.ability_name = self.special_ability_data.get('name', 'Special Ability')
                    self.ability_cooldown = self.special_ability_data.get('cooldown', 5)
                else:
                    self.ability_script = None
                    self.ability_name = None
                    self.ability_cooldown = 0
            
            def move(self):
                """Override move with metabolism rate"""
                loss = int(random.randint(1, 5) * self.metabolism_rate)
                self.energy = max(0, self.energy - loss)
                return loss
            
            def daily_action(self, forest):
                """Execute daily behavior based on diet type"""
                super().daily_action(forest)
                action_report = []
                
                # Handle special ability cooldown
                if self.special_ability_cooldown > 0:
                    self.special_ability_cooldown -= 1
                
                # Check for special ability use
                if self.ability_script and self.special_ability_cooldown == 0:
                    ability_result = self.use_special_ability(forest)
                    if ability_result:
                        action_report.append(ability_result)
                
                # Diet-specific behavior
                if self.diet_type == DietType.CARNIVORE:
                    result = self._carnivore_action(forest)
                    if result:
                        action_report.append(result)
                elif self.diet_type == DietType.HERBIVORE:
                    result = self._herbivore_action(forest)
                    if result:
                        action_report.append(result)
                else:  # omnivore
                    result = self._omnivore_action(forest)
                    if result:
                        action_report.append(result)
                
                return None, action_report
            
            def _carnivore_action(self, forest):
                """Carnivore behavior - hunt prey"""
                # Find potential prey (animals that are not this species)
                prey = [a for a in forest 
                       if a.species != self.species and 
                       a.energy < self.energy * 1.2]  # Hunt weaker or similar animals
                
                if prey and self.energy < self.hunger_threshold:
                    target = random.choice(prey)
                    success = random.random() < self.hunt_success_rate
                    
                    if success:
                        forest.remove(target)
                        self.eat(target.energy)
                        return f"{self.icon} {self.name} hunted {target.name}!"
                    else:
                        loss = self.move()
                        return f"{self.icon} {self.name} failed to hunt. Lost {loss} energy."
                
                # If not hunting, just move
                loss = self.move()
                return f"{self.icon} {self.name} roamed. Lost {loss} energy."
            
            def _herbivore_action(self, forest):
                """Herbivore behavior - eat plants and hide"""
                # Check for predators
                predators = [a for a in forest if a.diet_type in [DietType.CARNIVORE, DietType.OMNIVORE]]
                
                if predators and random.random() < self.flee_chance:
                    # Try to hide or flee
                    if self.can_fly:
                        return f"{self.icon} {self.name} flew away from danger!"
                    else:
                        loss = self.move() * 2  # Fleeing costs more energy
                        return f"{self.icon} {self.name} fled from predators! Lost {loss} energy."
                
                # Look for plants in territory
                if self.territory and self.territory.resources > 0:
                    food = min(10, self.territory.resources)
                    self.territory.resources -= food
                    self.eat(food)
                    return f"{self.icon} {self.name} grazed on {food} plants."
                
                # No plants, just move
                loss = self.move()
                return f"{self.icon} {self.name} searched for food. Lost {loss} energy."
            
            def _omnivore_action(self, forest):
                """Omnivore behavior - can do both"""
                # 50% chance to hunt or graze, depending on energy
                if self.energy < self.hunger_threshold:
                    # Hungry - more likely to hunt
                    if random.random() < 0.7:
                        return self._carnivore_action(forest)
                    else:
                        return self._herbivore_action(forest)
                else:
                    # Not hungry - more likely to graze
                    if random.random() < 0.3:
                        return self._carnivore_action(forest)
                    else:
                        return self._herbivore_action(forest)
            
            def use_special_ability(self, forest):
                """Use special ability from script"""
                if not self.ability_script:
                    return None
                
                result = SafeScriptExecutor.execute_function(
                    self.ability_script,
                    'special_action',
                    self,
                    forest
                )
                
                if result:
                    self.special_ability_cooldown = self.ability_cooldown
                
                return result
            
            def reproduce(self, partner=None):
                """Reproduction based on mod settings"""
                if not self.reproduction_data:
                    return None
                
                rate = self.reproduction_data.get('rate', 0.1)
                if random.random() >= rate:
                    return None
                
                # Check energy requirement
                min_energy = self.reproduction_data.get('min_energy', 20)
                if self.energy < min_energy:
                    return None
                
                # Determine offspring count
                offspring_range = self.reproduction_data.get('offspring_count', [1, 1])
                if isinstance(offspring_range, list):
                    count = random.randint(offspring_range[0], offspring_range[1])
                else:
                    count = 1
                
                offspring = []
                for i in range(count):
                    # Create baby
                    energy_range = self.mod_data['base_stats']['energy_range']
                    baby_energy = random.randint(energy_range[0] // 2, energy_range[1] // 2)
                    
                    baby = ModAnimal(
                        f"{self.mod_data['name']}_{random.randint(100,999)}",
                        baby_energy,
                        self.config
                    )
                    
                    # Inherit genes
                    if partner and isinstance(partner, ModAnimal):
                        baby.genes = GeneticTraits(self.config, self.genes, partner.genes)
                    else:
                        baby.genes = GeneticTraits(self.config, self.genes, self.genes)
                    
                    offspring.append(baby)
                
                return offspring
            
            def __str__(self):
                status = f"{self.icon} {self.name} ({self.species})"
                status += f" - Energy: {self.energy}, Age: {self.age}"
                if self.special_ability_cooldown > 0:
                    status += f" [Ability cooldown: {self.special_ability_cooldown}]"
                return status
        
        # Set class name for proper identification
        ModAnimal.__name__ = class_name
        return ModAnimal

# ==================== GENETIC TRAITS ====================

class GeneticTraits:
    """Genetic traits that can be inherited and evolve"""
    
    def __init__(self, config: Configuration, parent1=None, parent2=None):
        self.config = config
        
        if parent1 and parent2 and config.get('genetics.enabled', True):
            # Inherit from parents with mutation
            self.speed = self._inherit_trait(parent1.speed, parent2.speed)
            self.strength = self._inherit_trait(parent1.strength, parent2.strength)
            self.fertility = self._inherit_trait(parent1.fertility, parent2.fertility)
            self.longevity = self._inherit_trait(parent1.longevity, parent2.longevity)
            self.metabolism = self._inherit_trait(parent1.metabolism, parent2.metabolism)
        else:
            # Random initial traits
            self.speed = random.uniform(0.5, 1.5)
            self.strength = random.uniform(0.5, 1.5)
            self.fertility = random.uniform(0.5, 1.5)
            self.longevity = random.uniform(0.5, 1.5)
            self.metabolism = random.uniform(0.5, 1.5)
    
    def _inherit_trait(self, trait1, trait2):
        """Inherit trait with mutation"""
        inheritance = self.config.get('genetics.inheritance_method', 'average')
        
        if inheritance == 'average':
            trait = (trait1 + trait2) / 2
        else:  # dominant
            trait = max(trait1, trait2)
        
        # Mutation
        if random.random() < self.config.get('genetics.mutation_rate', 0.1):
            trait *= random.uniform(0.8, 1.2)
        
        # Keep within bounds
        trait_min = self.config.get('genetics.trait_min', 0.3)
        trait_max = self.config.get('genetics.trait_max', 2.0)
        return max(trait_min, min(trait_max, trait))
    
    def to_dict(self):
        return {
            'speed': round(self.speed, 2),
            'strength': round(self.strength, 2),
            'fertility': round(self.fertility, 2),
            'longevity': round(self.longevity, 2),
            'metabolism': round(self.metabolism, 2)
    }

# ==================== CONFIGURATION SYSTEM ====================

class Configuration:
    """Flexible configuration system supporting multiple formats"""
    
    DEFAULT_CONFIG = {
        'simulation': {
            'max_days': 1000,
            'default_speed': 5,
            'log_level': 'info',
            'auto_save': True,
            'auto_save_interval': 10
        },
        'mods': {
            'enabled': True,
            'mods_directory': 'mods',
            'auto_load': True,
            'safe_mode': True
        },
        'initial_population': {
            'min_lions': 1,
            'max_lions': 2,
            'min_rabbits': 5,
            'max_rabbits': 12,
            'min_wolves': 0,
            'max_wolves': 2,
            'min_deer': 0,
            'max_deer': 3,
            'wolf_spawn_chance': 0.3,
            'deer_spawn_chance': 0.4
        },
        'animals': {
            'rabbit': {
                'reproduction_rate': 0.3,
                'base_energy': 12,
                'energy_range': [8, 15],
                'max_age': 1000,
                'hunger_threshold': 10,
                'hiding_chance': 0.4
            },
            'lion': {
                'hunt_success_rate': 0.5,
                'base_energy': 30,
                'energy_range': [25, 35],
                'max_age': 2000,
                'hunger_threshold': 15,
                'pack_bonus': 0.1
            },
            'wolf': {
                'hunt_success_rate': 0.4,
                'base_energy': 25,
                'energy_range': [20, 30],
                'max_age': 1500,
                'pack_bonus': 0.15,
                'hunger_threshold': 20
            },
            'deer': {
                'reproduction_rate': 0.2,
                'base_energy': 20,
                'energy_range': [15, 25],
                'max_age': 1800,
                'speed_bonus': 1.5
            }
        },
        'environment': {
            'initial_plants': 100,
            'min_plants': 20,
            'max_plants': 200,
            'territories': [
                {'name': 'Meadow', 'size': 10, 'food_density': 8},
                {'name': 'Forest', 'size': 15, 'food_density': 6},
                {'name': 'River Valley', 'size': 12, 'food_density': 7},
                {'name': 'Hilltop', 'size': 8, 'food_density': 5},
                {'name': 'Deep Woods', 'size': 20, 'food_density': 4}
            ]
        },
        'genetics': {
            'enabled': True,
            'mutation_rate': 0.1,
            'trait_min': 0.3,
            'trait_max': 2.0,
            'inheritance_method': 'average'  # 'average' or 'dominant'
        },
        'events': {
            'enabled': True,
            'forest_fire': {'probability': 0.01, 'enabled': True},
            'disease_outbreak': {'probability': 0.02, 'enabled': True},
            'mating_season': {'probability': 0.1, 'enabled': True},
            'migrating_herd': {'probability': 0.05, 'enabled': True}
        },
        'display': {
            'dark_theme': True,
            'show_genetics': True,
            'refresh_rate': 100,
            'log_lines': 1000
        }
    }
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self.DEFAULT_CONFIG.copy()
        self.config_path = config_path
        self.format = OutputFormat.JSON
        
        if config_path and Path(config_path).exists():
            self.load(config_path)
    
    def load(self, path: str) -> bool:
        """Load configuration from file (auto-detect format)"""
        try:
            self.config_path = path
            suffix = Path(path).suffix.lower()
            
            # Map file extensions to formats
            format_map = {
                '.json': OutputFormat.JSON,
                '.hjson': OutputFormat.HJSON,
                '.msgpack': OutputFormat.MESSAGEPACK,
                '.bson': OutputFormat.BSON,
                '.xml': OutputFormat.XML,
                '.toml': OutputFormat.TOML,
                '.yaml': OutputFormat.YAML,
                '.yml': OutputFormat.YAML,
                '.pkl': OutputFormat.PICKLE
            }
            
            self.format = format_map.get(suffix, OutputFormat.JSON)
            
            with open(path, 'rb') as f:
                if self.format == OutputFormat.JSON:
                    self.config = json.load(f)
                elif self.format == OutputFormat.HJSON:
                    self.config = hjson.load(f)
                elif self.format == OutputFormat.MESSAGEPACK:
                    self.config = msgpack.unpackb(f.read())
                elif self.format == OutputFormat.BSON:
                    self.config = bson.decode(f.read())
                elif self.format == OutputFormat.YAML:
                    self.config = yaml.safe_load(f)
                elif self.format == OutputFormat.XML:
                    self.config = self._load_xml(f)
                elif self.format == OutputFormat.TOML:
                    self.config = tomllib.load(f)
                elif self.format == OutputFormat.PICKLE:
                    self.config = pickle.load(f)
            
            # Merge with defaults
            self.config = self._merge_configs(self.DEFAULT_CONFIG, self.config)
            return True
            
        except Exception as e:
            print(f"Error loading config: {e}")
            return False
    
    def save(self, path: str, format: OutputFormat = OutputFormat.JSON) -> bool:
        """Save configuration to file"""
        try:
            suffix = format.value
            if not path.endswith(f'.{suffix}'):
                path = f"{path}.{suffix}"
            
            with open(path, 'wb') as f:
                if format == OutputFormat.JSON:
                    json.dump(self.config, f, indent=2)
                elif format == OutputFormat.HJSON:
                    hjson.dump(self.config, f, indent=2)
                elif format == OutputFormat.MESSAGEPACK:
                    f.write(msgpack.packb(self.config))
                elif format == OutputFormat.BSON:
                    f.write(bson.encode(self.config))
                elif format == OutputFormat.YAML:
                    yaml.dump(self.config, f)
                elif format == OutputFormat.XML:
                    f.write(self._save_xml())
                elif format == OutputFormat.TOML:
                    self._save_toml(f)
                elif format == OutputFormat.PICKLE:
                    pickle.dump(self.config, f)
            
            self.format = format
            self.config_path = path
            return True
            
        except Exception as e:
            print(f"Error saving config: {e}")
            return False
    
    def _load_xml(self, file) -> Dict:
        """Load XML configuration"""
        tree = ET.parse(file)
        root = tree.getroot()
        return self._xml_to_dict(root)
    
    def _xml_to_dict(self, element) -> Dict:
        """Convert XML element to dictionary"""
        result = {}
        for child in element:
            if len(child):
                result[child.tag] = self._xml_to_dict(child)
            else:
                text = child.text
                if text is None:
                    result[child.tag] = None
                elif text.isdigit():
                    result[child.tag] = int(text)
                elif text.replace('.', '').isdigit():
                    result[child.tag] = float(text)
                elif text.lower() in ['true', 'false']:
                    result[child.tag] = text.lower() == 'true'
                else:
                    result[child.tag] = text
        return result
    
    def _save_xml(self) -> bytes:
        """Save configuration as XML"""
        root = ET.Element("configuration")
        self._dict_to_xml(root, self.config)
        tree = ET.ElementTree(root)
        import io
        buffer = io.BytesIO()
        tree.write(buffer, encoding='utf-8', xml_declaration=True)
        return buffer.getvalue()
    
    def _dict_to_xml(self, parent, data: Dict):
        """Convert dictionary to XML elements"""
        for key, value in data.items():
            if isinstance(value, dict):
                elem = ET.SubElement(parent, key)
                self._dict_to_xml(elem, value)
            else:
                elem = ET.SubElement(parent, key)
                elem.text = str(value)
    
    def _save_toml(self, file):
        """Save TOML configuration"""
        try:
            import toml
            toml.dump(self.config, file)
        except ImportError:
            import tomli_w
            tomli_w.dump(self.config, file)
    
    def _merge_configs(self, default: Dict, custom: Dict) -> Dict:
        """Recursively merge configurations"""
        result = default.copy()
        
        for key, value in custom.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        
        return result
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value using dot notation"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value using dot notation"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value

# ==================== ABSTRACT BASE CLASSES ====================

class Animal(ABC):
    """Abstract base class for all animals"""
    
    def __init__(self, name, energy, species, config: Configuration):
        self.name = name
        self.energy = energy
        self.species = species
        self.age = 0
        self.max_energy = 100
        self.days_since_last_meal = 0
        self.config = config
        self.genes = GeneticTraits(config)
        self.territory = None
        self.home_range = []
        self.diet_type = DietType.CARNIVORE  # Default, overridden by subclasses
    
    def move(self):
        loss = int(random.randint(1, 5) * self.genes.metabolism)
        self.energy = max(0, self.energy - loss)
        return loss
    
    def eat(self, food_energy=0):
        if food_energy > 0:
            gain = food_energy
            self.energy = min(self.max_energy, self.energy + food_energy)
            self.days_since_last_meal = 0
        else:
            gain = random.randint(5, 10)
            self.energy = min(self.max_energy, self.energy + gain)
            self.days_since_last_meal = 0
        return gain
    
    def is_alive(self):
        # Die from starvation if no food for 5 days
        if self.days_since_last_meal > 5:
            return False
        # Max age from config, influenced by genetics
        species_config = self.config.get(f'animals.{self.species.lower()}', {})
        base_max_age = species_config.get('max_age', 1000)
        max_age = int(base_max_age * self.genes.longevity)
        return self.energy > 0 and self.age < max_age
    
    @abstractmethod
    def daily_action(self, forest):
        """Polymorphic method - different for each animal type"""
        pass
    
    @abstractmethod
    def reproduce(self, partner=None):
        """Reproduction behavior"""
        pass
    
    def __str__(self):
        return f"{self.name} ({self.species}) - Energy: {self.energy}, Age: {self.age}"

# ==================== TERRITORY SYSTEM ====================

class Territory:
    """Territory that animals can claim and defend"""
    
    def __init__(self, name, size, food_density, config: Configuration):
        self.name = name
        self.size = size
        self.food_density = food_density
        self.occupants = []
        self.resources = size * food_density
        self.owner = None  # Alpha animal that owns the territory
        self.config = config
    
    def add_occupant(self, animal):
        if animal not in self.occupants:
            self.occupants.append(animal)
            animal.territory = self
    
    def remove_occupant(self, animal):
        if animal in self.occupants:
            self.occupants.remove(animal)
            animal.territory = None
            if self.owner == animal:
                self.owner = None
    
    def claim(self, animal):
        """Claim territory (if strong enough)"""
        if self.owner is None:
            self.owner = animal
            return True
        elif animal.genes.strength > self.owner.genes.strength:
            # Challenge existing owner
            self.owner = animal
            return True
        return False
    
    def regenerate_resources(self, season):
        """Regenerate resources based on season"""
        season_multiplier = {
            Season.SPRING: 1.5,
            Season.SUMMER: 1.2,
            Season.AUTUMN: 1.0,
            Season.WINTER: 0.5
        }
        self.resources = min(self.size * self.food_density * 2,
                           self.resources + self.size * season_multiplier[season])

# ==================== NATIVE ANIMAL CLASSES ====================

class Lion(Animal):
    """Lion class with pack behavior"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Lion", config)
        species_config = config.get('animals.lion', {})
        self.hunt_success_rate = species_config.get('hunt_success_rate', 0.5) * self.genes.strength
        self.hunger_threshold = species_config.get('hunger_threshold', 15)
        self.pride = []
        self.hunts_successful = 0
        self.hunts_failed = 0
        self.pack_size = 1
        self.diet_type = DietType.CARNIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        prey = [a for a in forest if a.diet_type in [DietType.HERBIVORE, DietType.OMNIVORE]]
        action_report = []
        
        # Update pack size (lions in same territory)
        if self.territory:
            self.pack_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Lion))
        
        # Hunting bonus from pack
        pack_bonus = min(0.3, self.pack_size * self.config.get('animals.lion.pack_bonus', 0.1))
        
        if prey and self.energy < self.hunger_threshold:
            # Hungry lions hunt more aggressively
            target = random.choice(prey)
            success = random.random() < (self.hunt_success_rate + pack_bonus)
            
            if success:
                forest.remove(target)
                self.eat(target.energy)
                self.hunts_successful += 1
                action_report.append(f"🦁 {self.name} hunted {target.name}! Energy now: {self.energy}")
                return "hunt_success", action_report
            else:
                loss = self.move()
                self.hunts_failed += 1
                action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                return "hunt_fail", action_report
        elif prey:
            # Well-fed lions may still hunt occasionally
            if random.random() < 0.3:
                target = random.choice(prey)
                if random.random() < (self.hunt_success_rate + pack_bonus):
                    forest.remove(target)
                    self.eat(target.energy)
                    self.hunts_successful += 1
                    action_report.append(f"🦁 {self.name} hunted {target.name}! Energy: {self.energy}")
                    return "hunt_success", action_report
                else:
                    loss = self.move()
                    self.hunts_failed += 1
                    action_report.append(f"🦁 {self.name} failed to hunt. Lost {loss} energy. Energy: {self.energy}")
                    return "hunt_fail", action_report
            else:
                loss = self.move()
                action_report.append(f"🦁 {self.name} rested. Lost {loss} energy. Energy: {self.energy}")
                return "rest", action_report
        else:
            loss = self.move()
            action_report.append(f"🦁 {self.name} found no prey. Lost {loss} energy. Energy: {self.energy}")
            return "no_prey", action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Lion):
            cub = Lion(f"Cub_{random.randint(100,999)}", 
                      random.randint(15, 25), self.config)
            cub.genes = GeneticTraits(self.config, self, partner)
            cub.age = 0
            return [cub]
        return None

class Rabbit(Animal):
    """Rabbit class with hiding behavior"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Rabbit", config)
        species_config = config.get('animals.rabbit', {})
        self.reproduction_rate = species_config.get('reproduction_rate', 0.3) * self.genes.fertility
        self.hidden = False
        self.hiding_spot = None
        self.children_born = 0
        self.herd_size = 1
        self.hiding_chance = species_config.get('hiding_chance', 0.4)
        self.diet_type = DietType.HERBIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        action_report = []
        predators = [a for a in forest if a.diet_type in [DietType.CARNIVORE, DietType.OMNIVORE]]
        
        # Update herd size (rabbits in same territory)
        if self.territory:
            self.herd_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Rabbit))
        
        # Safety in numbers - less likely to hide in large herds
        hiding_chance = self.hiding_chance / max(1, self.herd_size * 0.5)
        
        if predators and random.random() < hiding_chance:
            # Rabbits can hide from predators
            self.hidden = True
            self.hiding_spot = f"spot_{random.randint(1,10)}"
            action_report.append(f"🐰 {self.name} is hiding in {self.hiding_spot}!")
        else:
            self.hidden = False
            self.hiding_spot = None
            loss = self.move()
            action_report.append(f"🐰 {self.name} moved. Lost {loss} energy. Energy: {self.energy}")
        
        # Eat plants
        if self.territory and self.territory.resources > 0 and not self.hidden:
            food = min(5, self.territory.resources)
            self.territory.resources -= food
            self.eat(food)
            action_report.append(f"🐰 {self.name} ate {food} plants.")
        
        # Reproduce only if enough energy and safe
        baby = None
        if self.energy > 15 and random.random() < self.reproduction_rate and not self.hidden:
            baby_energy = random.randint(5, 10)
            baby = Rabbit(f"Rabbit_{random.randint(100,999)}", baby_energy, self.config)
            baby.genes = GeneticTraits(self.config, self, self)
            baby.age = 0
            self.children_born += 1
            action_report.append(f"🐰 {self.name} gave birth to {baby.name}!")
        
        return baby, action_report
    
    def reproduce(self, partner=None):
        if random.random() < self.reproduction_rate:
            baby = Rabbit(f"Rabbit_{random.randint(100,999)}", 
                         random.randint(5, 10), self.config)
            if partner and isinstance(partner, Rabbit):
                baby.genes = GeneticTraits(self.config, self, partner)
            else:
                baby.genes = GeneticTraits(self.config, self, self)
            return [baby]
        return None

class Wolf(Animal):
    """Wolf class - hunts in packs"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Wolf", config)
        species_config = config.get('animals.wolf', {})
        self.pack_size = 1
        self.pack_bonus = species_config.get('pack_bonus', 0.15)
        self.hunt_success_rate = species_config.get('hunt_success_rate', 0.4) * self.genes.strength
        self.hunger_threshold = species_config.get('hunger_threshold', 20)
        self.hunts_successful = 0
        self.hunts_failed = 0
        self.diet_type = DietType.CARNIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        prey = [a for a in forest if a.diet_type in [DietType.HERBIVORE, DietType.OMNIVORE]]
        action_report = []
        
        # Update pack size
        if self.territory:
            self.pack_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Wolf))
        
        pack_bonus = min(0.5, self.pack_size * self.pack_bonus)
        
        if prey and self.energy < self.hunger_threshold:
            target = random.choice(prey)
            success = random.random() < (self.hunt_success_rate + pack_bonus)
            
            if success:
                forest.remove(target)
                self.eat(target.energy)
                self.hunts_successful += 1
                action_report.append(f"🐺 {self.name} hunted {target.name}! Energy: {self.energy}")
            else:
                loss = self.move()
                self.hunts_failed += 1
                action_report.append(f"🐺 {self.name} failed to hunt. Lost {loss} energy")
        else:
            loss = self.move()
            action_report.append(f"🐺 {self.name} roamed. Lost {loss} energy")
        
        return None, action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Wolf):
            pup = Wolf(f"Wolf_{random.randint(100,999)}", random.randint(10, 20), self.config)
            pup.genes = GeneticTraits(self.config, self, partner)
            return [pup]
        return None

class Deer(Animal):
    """Deer class - fast herbivore"""
    
    def __init__(self, name, energy, config: Configuration):
        super().__init__(name, energy, "Deer", config)
        species_config = config.get('animals.deer', {})
        self.herd_size = 1
        self.speed_bonus = species_config.get('speed_bonus', 1.5) * self.genes.speed
        self.reproduction_rate = species_config.get('reproduction_rate', 0.2) * self.genes.fertility
        self.diet_type = DietType.HERBIVORE
    
    def daily_action(self, forest):
        super().daily_action(forest)
        action_report = []
        
        # Update herd size
        if self.territory:
            self.herd_size = sum(1 for a in self.territory.occupants 
                               if isinstance(a, Deer))
        
        # Deer are fast - they move more but can escape better
        loss = self.move()
        action_report.append(f"🦌 {self.name} grazed. Lost {loss} energy")
        
        # Eat plants
        if self.territory and self.territory.resources > 0:
            food = min(8, self.territory.resources)
            self.territory.resources -= food
            self.eat(food)
            action_report.append(f"🦌 {self.name} ate {food} plants.")
        
        # Reproduction
        baby = None
        if self.energy > 25 and random.random() < self.reproduction_rate:
            baby = Deer(f"Deer_{random.randint(100,999)}", random.randint(10, 15), self.config)
            baby.genes = GeneticTraits(self.config, self, self)
            action_report.append(f"🦌 {self.name} gave birth to a fawn!")
        
        return baby, action_report
    
    def reproduce(self, partner=None):
        if partner and isinstance(partner, Deer):
            fawn = Deer(f"Deer_{random.randint(100,999)}", random.randint(10, 15), self.config)
            fawn.genes = GeneticTraits(self.config, self, partner)
            return [fawn]
        return None

# ==================== ANIMAL FACTORY ====================

class AnimalFactory:
    """Factory for creating animals (native and modded)"""
    
    _native_classes = {
        "Lion": Lion,
        "Rabbit": Rabbit,
        "Wolf": Wolf,
        "Deer": Deer
    }
    
    _mod_classes = {}
    _mod_configs = {}
    
    @classmethod
    def register_mod_animal(cls, species_id: str, animal_class: Type, mod_data: dict):
        """Register a mod animal class"""
        cls._mod_classes[species_id] = animal_class
        cls._mod_configs[species_id] = mod_data
    
    @classmethod
    def get_available_species(cls) -> List[str]:
        """Get list of all available species"""
        return list(cls._native_classes.keys()) + list(cls._mod_classes.keys())
    
    @classmethod
    def create_animal(cls, species, config: Configuration, name=None, energy=None):
        """Create an animal of the specified species"""
        # Check native classes first
        if species in cls._native_classes:
            animal_class = cls._native_classes[species]
            species_config = config.get(f'animals.{species.lower()}', {})
            
            if name is None:
                if species == "Lion":
                    name = cls._random_lion_name()
                else:
                    name = f"{species}_{random.randint(100,999)}"
            
            if energy is None:
                energy_range = species_config.get('energy_range', [25, 35])
                energy = random.randint(energy_range[0], energy_range[1])
            
            return animal_class(name, energy, config)
        
        # Check mod classes
        elif species in cls._mod_classes:
            animal_class = cls._mod_classes[species]
            mod_data = cls._mod_configs[species]
            
            if name is None:
                name = f"{mod_data['name']}_{random.randint(100,999)}"
            
            if energy is None:
                energy_range = mod_data['base_stats']['energy_range']
                energy = random.randint(energy_range[0], energy_range[1])
            
            return animal_class(name, energy, config)
        
        else:
            raise ValueError(f"Unknown species: {species}")
    
    @classmethod
    def _random_lion_name(cls):
        male_names = ["Leo", "Leon", "Aslan", "Simba", "Mufasa", "Scar", "Kimba"]
        female_names = ["Nala", "Sarabi", "Kiara", "Cleopatra", "Nefertiti", "Zara"]
        all_names = male_names + female_names
        return f"{random.choice(all_names)}_{random.randint(10,99)}"

# ==================== EVENT SYSTEM ====================

class Event(ABC):
    """Base class for random events"""
    
    def __init__(self, name, config_key, config: Configuration):
        self.name = name
        self.config_key = config_key
        self.config = config
        event_config = config.get(f'events.{config_key}', {})
        self.probability = event_config.get('probability', 0.01)
        self.enabled = event_config.get('enabled', True)
    
    @abstractmethod
    def apply(self, simulator):
        """Apply the event to the simulator"""
        pass
    
    def __str__(self):
        return self.name

class ForestFire(Event):
    """Forest fire event - reduces plants and harms animals"""
    
    def __init__(self, config: Configuration):
        super().__init__("🔥 Forest Fire", 'forest_fire', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Reduce plant food by half
        simulator.environment.food_available = int(simulator.environment.food_available * 0.5)
        
        # Harm all animals
        casualties = []
        for animal in simulator.forest[:]:
            if random.random() < 0.3:  # 30% chance of death/injury
                animal.energy = int(animal.energy * 0.7)
                casualties.append(animal.name)
        
        return f"🔥 FOREST FIRE! Plants halved. {len(casualties)} animals injured."

class DiseaseOutbreak(Event):
    """Disease outbreak - affects specific species"""
    
    def __init__(self, config: Configuration):
        super().__init__("🦠 Disease Outbreak", 'disease_outbreak', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Choose random species from all available (including mods)
        all_species = AnimalFactory.get_available_species()
        if not all_species:
            return None
            
        species = random.choice(all_species)
        casualties = []
        
        for animal in simulator.forest[:]:
            if animal.species == species and random.random() < 0.4:
                simulator.forest.remove(animal)
                casualties.append(animal.name)
        
        return f"🦠 DISEASE OUTBREAK! {len(casualties)} {species}s died."

class MatingSeason(Event):
    """Mating season - boosts reproduction"""
    
    def __init__(self, config: Configuration):
        super().__init__("💕 Mating Season", 'mating_season', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Boost reproduction for one day
        newborns = 0
        for animal in simulator.forest[:]:
            if hasattr(animal, 'reproduction_rate'):
                # Boost reproduction rate temporarily
                original_rate = animal.reproduction_rate
                animal.reproduction_rate *= 2
                
                # Try to reproduce
                offspring = animal.reproduce()
                if offspring:
                    for baby in offspring:
                        simulator.forest.append(baby)
                        newborns += 1
                
                # Restore original rate
                animal.reproduction_rate = original_rate
        
        return f"💕 MATING SEASON! {newborns} babies born today!"

class MigratingHerd(Event):
    """Migrating herd - adds new animals"""
    
    def __init__(self, config: Configuration):
        super().__init__("🦌 Migrating Herd", 'migrating_herd', config)
    
    def apply(self, simulator):
        if not self.enabled:
            return None
            
        # Add new animals (could be modded species)
        new_animals = []
        all_species = AnimalFactory.get_available_species()
        herbivores = [s for s in all_species if s in ["Rabbit", "Deer"] or 
                     (s in AnimalFactory._mod_configs and 
                      AnimalFactory._mod_configs[s].get('diet_type') in ['herbivore', 'omnivore'])]
        
        if herbivores:
            for _ in range(random.randint(1, 3)):
                species = random.choice(herbivores)
                try:
                    animal = AnimalFactory.create_animal(species, simulator.config)
                    new_animals.append(animal)
                except:
                    pass
        
        simulator.forest.extend(new_animals)
        names = ", ".join([a.name for a in new_animals])
        return f"🦌 MIGRATING HERD! New arrivals: {names}"

class EventManager:
    """Manages random events in the simulation"""
    
    def __init__(self, config: Configuration):
        self.config = config
        self.events = [
            ForestFire(config),
            DiseaseOutbreak(config),
            MatingSeason(config),
            MigratingHerd(config)
        ]
        self.event_history = []
    
    def check_events(self, simulator):
        """Check and apply random events"""
        if not self.config.get('events.enabled', True):
            return []
            
        reports = []
        for event in self.events:
            if event.enabled and random.random() < event.probability:
                result = event.apply(simulator)
                if result:
                    reports.append(result)
                    self.event_history.append((simulator.day, event.name))
        return reports

# ==================== ENVIRONMENT ====================

class Environment:
    """Environment with seasons and weather"""
    
    def __init__(self, name, config: Configuration):
        self.name = name
        self.config = config
        self.food_available = config.get('environment.initial_plants', 100)
        self.weather = Weather.CLEAR
        self.season = Season.SPRING
        self.day = 0
        self.territories = self._create_territories()
    
    def _create_territories(self):
        """Create territories from config"""
        territories = []
        territory_configs = self.config.get('environment.territories', [])
        
        for t_config in territory_configs:
            territory = Territory(
                t_config['name'],
                t_config['size'],
                t_config['food_density'],
                self.config
            )
            territories.append(territory)
        
        return territories
    
    def update_weather(self):
        self.day += 1
        
        # Update season every 10 days
        if self.day % 10 == 0:
            season_index = (self.day // 10) % 4
            self.season = list(Season)[season_index]
        
        # Weather probabilities based on season
        weights = {
            Season.SPRING: [0.3, 0.4, 0.1, 0.1, 0.1],
            Season.SUMMER: [0.5, 0.1, 0.3, 0.05, 0.05],
            Season.AUTUMN: [0.3, 0.3, 0.1, 0.2, 0.1],
            Season.WINTER: [0.2, 0.2, 0.1, 0.3, 0.2]
        }
        
        self.weather = random.choices(list(Weather), weights[self.season])[0]
        
        # Update food availability
        season_food_modifier = {
            Season.SPRING: 8,
            Season.SUMMER: 3,
            Season.AUTUMN: 2,
            Season.WINTER: -10
        }
        
        weather_food_modifier = {
            Weather.CLEAR: 0,
            Weather.RAIN: 5,
            Weather.DROUGHT: -5,
            Weather.STORM: -3,
            Weather.MILD: 2
        }
        
        self.food_available += season_food_modifier[self.season] + weather_food_modifier[self.weather]
        
        min_plants = self.config.get('environment.min_plants', 20)
        max_plants = self.config.get('environment.max_plants', 200)
        self.food_available = max(min_plants, min(max_plants, self.food_available))
        
        # Regenerate territories
        for territory in self.territories:
            territory.regenerate_resources(self.season)
        
        return self.weather
    
    def apply_weather_effects(self, animal):
        if animal is None:
            return 0
            
        effect = 0
        if self.weather == Weather.RAIN:
            effect = random.randint(1, 3)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        elif self.weather == Weather.DROUGHT:
            effect = -random.randint(0, 2)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == Weather.STORM:
            effect = -random.randint(1, 4)
            animal.energy = max(0, animal.energy + effect)
        elif self.weather == Weather.MILD:
            effect = random.randint(0, 1)
            animal.energy = min(animal.max_energy, animal.energy + effect)
        
        return effect
    
    def get_plant_food(self):
        if self.food_available > 0:
            max_food = 3 if self.season == Season.WINTER else 5
            food = min(random.randint(1, max_food), self.food_available)
            self.food_available -= food
            return food
        return 0
    
    def assign_territory(self, animal):
        """Assign animal to a territory"""
        if not animal.territory and hasattr(animal, 'territorial') and animal.territorial:
            # Find territory with space
            available = [t for t in self.territories if len(t.occupants) < t.size]
            if available:
                territory = random.choice(available)
                territory.add_occupant(animal)
                
                # Try to claim territory
                if random.random() < 0.3:  # 30% chance to claim
                    territory.claim(animal)
                
                return territory
        return animal.territory
    
    def __str__(self):
        return f"Weather: {self.weather.value}, Season: {self.season.value}, Plants: {self.food_available}"

# ==================== MOD MANAGER DIALOG ====================

class ModManagerDialog(QDialog):
    """Dialog for managing mods at runtime"""
    
    mods_changed = Signal()
    
    def __init__(self, mod_loader: ModLoader, config: Configuration, parent=None):
        super().__init__(parent)
        self.mod_loader = mod_loader
        self.config = config
        self.setWindowTitle("📦 Mod Manager")
        self.setGeometry(200, 200, 800, 600)
        self.init_ui()
        self.refresh_mod_list()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Mods directory info
        dir_layout = QHBoxLayout()
        dir_layout.addWidget(QLabel(f"Mods Directory:"))
        dir_layout.addWidget(QLabel(str(self.mod_loader.mods_directory)))
        dir_layout.addStretch()
        layout.addLayout(dir_layout)
        
        # Mod list
        list_group = QGroupBox("Installed Mods")
        list_layout = QVBoxLayout()
        
        self.mod_table = QTableWidget()
        self.mod_table.setColumnCount(5)
        self.mod_table.setHorizontalHeaderLabels(["Mod", "Species", "Diet", "Format", "Status"])
        self.mod_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.mod_table.setSelectionBehavior(QTableWidget.SelectRows)
        list_layout.addWidget(self.mod_table)
        
        list_group.setLayout(list_layout)
        layout.addWidget(list_group)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        self.load_btn = QPushButton("📂 Load Mod")
        self.load_btn.clicked.connect(self.load_mod)
        btn_layout.addWidget(self.load_btn)
        
        self.unload_btn = QPushButton("❌ Unload Mod")
        self.unload_btn.clicked.connect(self.unload_mod)
        self.unload_btn.setEnabled(False)
        btn_layout.addWidget(self.unload_btn)
        
        self.reload_btn = QPushButton("🔄 Reload Mod")
        self.reload_btn.clicked.connect(self.reload_mod)
        self.reload_btn.setEnabled(False)
        btn_layout.addWidget(self.reload_btn)
        
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh_mod_list)
        btn_layout.addWidget(self.refresh_btn)
        
        layout.addLayout(btn_layout)
        
        # Mod details
        details_group = QGroupBox("Mod Details")
        details_layout = QFormLayout()
        
        self.details_text = QTextEdit()
        self.details_text.setReadOnly(True)
        self.details_text.setMaximumHeight(150)
        details_layout.addRow(self.details_text)
        
        details_group.setLayout(details_layout)
        layout.addWidget(details_group)
        
        # Dialog buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        # Connect selection change
        self.mod_table.itemSelectionChanged.connect(self.on_mod_selected)
    
    def refresh_mod_list(self):
        """Refresh the mod list"""
        mods = self.mod_loader.get_all_mods()
        
        self.mod_table.setRowCount(len(mods))
        for i, mod in enumerate(mods):
            self.mod_table.setItem(i, 0, QTableWidgetItem(mod.name))
            self.mod_table.setItem(i, 1, QTableWidgetItem(mod.id))
            self.mod_table.setItem(i, 2, QTableWidgetItem(mod.data.get('diet_type', 'unknown')))
            self.mod_table.setItem(i, 3, QTableWidgetItem(mod.format.value))
            
            status_widget = QWidget()
            status_layout = QHBoxLayout(status_widget)
            status_layout.setContentsMargins(0,0,0,0)
            
            enabled_cb = QCheckBox()
            enabled_cb.setChecked(mod.enabled)
            enabled_cb.stateChanged.connect(lambda state, m=mod: self.toggle_mod(m, state))
            status_layout.addWidget(enabled_cb)
            
            if mod.error:
                error_label = QLabel("⚠️")
                error_label.setToolTip(mod.error)
                status_layout.addWidget(error_label)
            
            status_layout.addStretch()
            self.mod_table.setCellWidget(i, 4, status_widget)
    
    def toggle_mod(self, mod: ModInfo, state):
        """Toggle mod enabled state"""
        mod.enabled = (state == Qt.Checked)
        if mod.enabled:
            # Try to create animal class if not exists
            if mod.id not in self.mod_loader.animal_classes:
                try:
                    animal_class = ModAnimalFactory.create_animal_class(mod)
                    self.mod_loader.animal_classes[mod.id] = animal_class
                    AnimalFactory.register_mod_animal(mod.id, animal_class, mod.data)
                    mod.error = None
                except Exception as e:
                    mod.error = str(e)
                    mod.enabled = False
        else:
            # Remove animal class
            if mod.id in self.mod_loader.animal_classes:
                del self.mod_loader.animal_classes[mod.id]
    
    def load_mod(self):
        """Load a new mod from file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Mod", str(self.mod_loader.mods_directory),
            "Mod Files (*.json *.hjson *.msgpack *.bson *.xml *.toml *.yaml *.yml);;All Files (*)"
        )
        
        if file_path:
            mod_info = self.mod_loader.load_mod(file_path)
            if mod_info:
                # Create animal class
                try:
                    animal_class = ModAnimalFactory.create_animal_class(mod_info)
                    self.mod_loader.animal_classes[mod_info.id] = animal_class
                    AnimalFactory.register_mod_animal(mod_info.id, animal_class, mod_info.data)
                    QMessageBox.information(self, "Success", f"Mod '{mod_info.name}' loaded successfully!")
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to create animal class: {e}")
                
                self.refresh_mod_list()
                self.mods_changed.emit()
            else:
                QMessageBox.warning(self, "Error", "Failed to load mod!")
    
    def unload_mod(self):
        """Unload selected mod"""
        current_row = self.mod_table.currentRow()
        if current_row >= 0:
            mod_id = self.mod_table.item(current_row, 1).text()
            reply = QMessageBox.question(self, "Confirm Unload", 
                                       f"Unload mod '{mod_id}'? This will remove all animals of this species.")
            if reply == QMessageBox.Yes:
                self.mod_loader.unload_mod(mod_id)
                self.refresh_mod_list()
                self.mods_changed.emit()
    
    def reload_mod(self):
        """Reload selected mod"""
        current_row = self.mod_table.currentRow()
        if current_row >= 0:
            mod_id = self.mod_table.item(current_row, 1).text()
            mod_info = self.mod_loader.reload_mod(mod_id)
            if mod_info:
                # Recreate animal class
                try:
                    animal_class = ModAnimalFactory.create_animal_class(mod_info)
                    self.mod_loader.animal_classes[mod_id] = animal_class
                    AnimalFactory.register_mod_animal(mod_id, animal_class, mod_info.data)
                    QMessageBox.information(self, "Success", f"Mod '{mod_info.name}' reloaded!")
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Failed to recreate animal class: {e}")
                
                self.refresh_mod_list()
                self.mods_changed.emit()
    
    def on_mod_selected(self):
        """Handle mod selection change"""
        current_row = self.mod_table.currentRow()
        has_selection = current_row >= 0
        
        self.unload_btn.setEnabled(has_selection)
        self.reload_btn.setEnabled(has_selection)
        
        if has_selection:
            mod_id = self.mod_table.item(current_row, 1).text()
            mod_info = self.mod_loader.loaded_mods.get(mod_id)
            if mod_info:
                # Display mod details
                details = f"ID: {mod_info.id}\n"
                details += f"Name: {mod_info.name}\n"
                details += f"File: {mod_info.file_path}\n"
                details += f"Format: {mod_info.format.value}\n"
                details += f"Diet: {mod_info.data.get('diet_type', 'unknown')}\n"
                details += f"Energy Range: {mod_info.data['base_stats']['energy_range']}\n"
                
                if 'behavior' in mod_info.data:
                    details += f"\nBehavior:\n"
                    for key, value in mod_info.data['behavior'].items():
                        details += f"  {key}: {value}\n"
                
                if 'special_ability' in mod_info.data:
                    details += f"\nSpecial Ability: {mod_info.data['special_ability'].get('name', 'Unknown')}\n"
                
                if mod_info.error:
                    details += f"\n⚠️ Error: {mod_info.error}\n"
                
                self.details_text.setText(details)

# ==================== PAUSE MENU DIALOG ====================

class PauseMenuDialog(QDialog):
    """Dialog shown when simulation is paused"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("⏸ Simulation Paused")
        self.setModal(True)
        self.setFixedSize(300, 250)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("Simulation Paused")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: bold; margin: 10px;")
        layout.addWidget(title)
        
        # Buttons
        btn_style = "font-size: 14px; padding: 8px; margin: 2px;"
        
        self.resume_btn = QPushButton("▶ Resume Simulation")
        self.resume_btn.setStyleSheet(btn_style)
        self.resume_btn.clicked.connect(lambda: self.done(1))
        layout.addWidget(self.resume_btn)
        
        self.mods_btn = QPushButton("📦 Manage Mods")
        self.mods_btn.setStyleSheet(btn_style)
        self.mods_btn.clicked.connect(lambda: self.done(2))
        layout.addWidget(self.mods_btn)
        
        self.exit_btn = QPushButton("🚪 Exit to Main Menu")
        self.exit_btn.setStyleSheet(btn_style)
        self.exit_btn.clicked.connect(lambda: self.done(3))
        layout.addWidget(self.exit_btn)
        
        self.quit_btn = QPushButton("❌ Quit Game")
        self.quit_btn.setStyleSheet(btn_style)
        self.quit_btn.clicked.connect(lambda: self.done(4))
        layout.addWidget(self.quit_btn)
        
        # Status label
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("color: #888; margin-top: 10px;")
        layout.addWidget(self.status_label)

# ==================== SIMULATION WORKER ====================

class SimulationWorker(QObject):
    """Worker object for running simulation in separate thread"""
    
    update_signal = Signal(str)
    status_signal = Signal(dict)
    finished = Signal()
    paused_signal = Signal()
    
    def __init__(self, simulator):
        super().__init__()
        self.simulator = simulator
        self.running = False
        self.paused = False
        self.speed = 5
        self.pause_menu_shown = False
    
    def run(self):
        """Run the simulation"""
        self.running = True
        while self.running and self.simulator.forest:
            if self.paused:
                if not self.pause_menu_shown:
                    self.paused_signal.emit()
                    self.pause_menu_shown = True
                QThread.msleep(100)  # Sleep while paused
                continue
            
            # Run one day
            reports = self.simulator.simulate_day()
            
            # Send updates
            for report in reports:
                self.update_signal.emit(report)
            
            # Send status
            self.status_signal.emit(self.simulator.get_status_dict())
            
            # Auto-save if enabled
            if (self.simulator.config.get('simulation.auto_save', True) and 
                self.simulator.day % self.simulator.config.get('simulation.auto_save_interval', 10) == 0):
                self.simulator.save_simulation("autosave.pkl")
                self.update_signal.emit("💾 Auto-saved simulation")
            
            # Wait based on speed
            QThread.msleep(int(1000 / self.speed))
        
        self.finished.emit()
    
    def stop(self):
        self.running = False
    
    def pause(self):
        self.paused = not self.paused
        self.pause_menu_shown = False

# ==================== MAIN SIMULATOR CLASS ====================

class ForestSimulator:
    """Main simulator class"""
    
    def __init__(self, config: Configuration = None):
        self.config = config or Configuration()
        self.mod_loader = ModLoader(self.config.get('mods.mods_directory', 'mods'))
        self.forest = []
        self.environment = Environment("Enchanted Forest", self.config)
        self.day = 0
        self.event_manager = EventManager(self.config)
        self.stats = {
            "rabbits_born": 0,
            "lions_born": 0,
            "deer_born": 0,
            "hunts_successful": 0,
            "hunts_failed": 0,
            "deaths": 0,
            "rabbit_deaths": 0,
            "lion_deaths": 0,
            "deer_deaths": 0,
            "starvation_deaths": 0,
            "old_age_deaths": 0,
            "weather_events": {"clear": 0, "rain": 0, "drought": 0, "storm": 0, "mild": 0},
            "plant_consumption": 0
        }
        
        # Load mods if enabled
        if self.config.get('mods.auto_load', True):
            self.load_mods()
    
    def load_mods(self):
        """Load all mods from mods directory"""
        mod_files = self.mod_loader.discover_mods()
        for mod_file in mod_files:
            mod_info = self.mod_loader.load_mod(mod_file)
            if mod_info and self.config.get('mods.safe_mode', True):
                try:
                    # Create animal class
                    animal_class = ModAnimalFactory.create_animal_class(mod_info)
                    self.mod_loader.animal_classes[mod_info.id] = animal_class
                    AnimalFactory.register_mod_animal(mod_info.id, animal_class, mod_info.data)
                    print(f"✅ Loaded mod: {mod_info.name}")
                except Exception as e:
                    print(f"❌ Failed to create animal class for {mod_info.name}: {e}")
    
    def initialize_forest(self):
        """Initialize the forest with animals"""
        # Add native animals
        # Lions
        min_lions = self.config.get('initial_population.min_lions', 1)
        max_lions = self.config.get('initial_population.max_lions', 2)
        num_lions = random.randint(min_lions, max_lions)
        for i in range(num_lions):
            lion = AnimalFactory.create_animal("Lion", self.config)
            lion.age = random.randint(1, 5)
            self.forest.append(lion)
        
        # Rabbits
        min_rabbits = self.config.get('initial_population.min_rabbits', 5)
        max_rabbits = self.config.get('initial_population.max_rabbits', 12)
        num_rabbits = random.randint(min_rabbits, max_rabbits)
        for i in range(num_rabbits):
            rabbit = AnimalFactory.create_animal("Rabbit", self.config)
            rabbit.age = random.randint(1, 3)
            self.forest.append(rabbit)
        
        # Wolves (optional)
        wolf_chance = self.config.get('initial_population.wolf_spawn_chance', 0.3)
        if random.random() < wolf_chance:
            min_wolves = self.config.get('initial_population.min_wolves', 0)
            max_wolves = self.config.get('initial_population.max_wolves', 2)
            num_wolves = random.randint(min_wolves, max_wolves)
            for i in range(num_wolves):
                wolf = AnimalFactory.create_animal("Wolf", self.config)
                wolf.age = random.randint(1, 4)
                self.forest.append(wolf)
        
        # Deer (optional)
        deer_chance = self.config.get('initial_population.deer_spawn_chance', 0.4)
        if random.random() < deer_chance:
            min_deer = self.config.get('initial_population.min_deer', 0)
            max_deer = self.config.get('initial_population.max_deer', 3)
            num_deer = random.randint(min_deer, max_deer)
            for i in range(num_deer):
                deer = AnimalFactory.create_animal("Deer", self.config)
                deer.age = random.randint(1, 3)
                self.forest.append(deer)
        
        # Add mod animals if enabled
        if self.config.get('mods.enabled', True):
            for mod_id, animal_class in self.mod_loader.animal_classes.items():
                mod_info = self.mod_loader.loaded_mods.get(mod_id)
                if mod_info and mod_info.enabled:
                    # Random chance to spawn mod animals
                    spawn_chance = 0.3  # Could be configurable per mod
                    if random.random() < spawn_chance:
                        count = random.randint(0, 2)
                        for _ in range(count):
                            try:
                                animal = AnimalFactory.create_animal(mod_id, self.config)
                                animal.age = random.randint(1, 3)
                                self.forest.append(animal)
                            except Exception as e:
                                print(f"Error spawning mod animal {mod_id}: {e}")
        
        # Assign territories
        for animal in self.forest:
            self.environment.assign_territory(animal)
    
    def simulate_day(self):
        """Simulate one day"""
        self.day += 1
        weather = self.environment.update_weather()
        self.stats["weather_events"][weather.value] += 1
        
        daily_report = [f"\n{'='*50}", f"DAY {self.day} - {self.environment}", f"{'='*50}"]
        
        # Check for random events
        event_reports = self.event_manager.check_events(self)
        daily_report.extend(event_reports)
        
        # Apply weather to all animals
        weather_effects = []
        for animal in self.forest[:]:
            effect = self.environment.apply_weather_effects(animal)
            if effect > 0:
                weather_effects.append(f"{animal.icon if hasattr(animal, 'icon') else '🐾'} {animal.name} gained {effect} energy")
            elif effect < 0:
                weather_effects.append(f"{animal.icon if hasattr(animal, 'icon') else '🐾'} {animal.name} lost {-effect} energy")
        
        if weather_effects:
            daily_report.append("\n🌤️ WEATHER EFFECTS:")
            daily_report.extend(weather_effects)
        
        # Herbivores can eat plants
        herbivores = [a for a in self.forest if a.diet_type in [DietType.HERBIVORE, DietType.OMNIVORE]]
        for herbivore in herbivores:
            plant_food = self.environment.get_plant_food()
            if plant_food > 0:
                herbivore.eat(plant_food)
                self.stats["plant_consumption"] += plant_food
                icon = getattr(herbivore, 'icon', '🌿')
                daily_report.append(f"{icon} {herbivore.name} ate {plant_food} plants")
        
        # Process daily actions
        new_animals = []
        
        # Shuffle to prevent order bias
        random.shuffle(self.forest)
        
        for animal in self.forest[:]:
            if hasattr(animal, 'daily_action'):
                babies, reports = animal.daily_action(self.forest)
                daily_report.extend(reports)
                
                if babies:
                    if isinstance(babies, list):
                        new_animals.extend(babies)
                    else:
                        new_animals.append(babies)
                    
                    # Update birth stats
                    if isinstance(animal, Rabbit):
                        self.stats["rabbits_born"] += 1
                    elif isinstance(animal, Deer):
                        self.stats["deer_born"] = self.stats.get("deer_born", 0) + 1
        
        # Add newborns to forest
        self.forest.extend(new_animals)
        
        # Check for deaths
        alive_animals = []
        for animal in self.forest:
            if animal.is_alive():
                alive_animals.append(animal)
            else:
                self.stats["deaths"] += 1
                death_reason = "old age" if animal.age >= 50 else "starvation"
                
                if death_reason == "starvation":
                    self.stats["starvation_deaths"] += 1
                else:
                    self.stats["old_age_deaths"] += 1
                
                icon = getattr(animal, 'icon', '💀')
                
                if isinstance(animal, Lion):
                    self.stats["lion_deaths"] = self.stats.get("lion_deaths", 0) + 1
                    daily_report.append(f"{icon} {animal.name} the Lion died ({death_reason})")
                elif isinstance(animal, Rabbit):
                    self.stats["rabbit_deaths"] += 1
                    daily_report.append(f"{icon} {animal.name} the Rabbit died ({death_reason})")
                elif isinstance(animal, Wolf):
                    self.stats["wolf_deaths"] = self.stats.get("wolf_deaths", 0) + 1
                    daily_report.append(f"{icon} {animal.name} the Wolf died ({death_reason})")
                elif isinstance(animal, Deer):
                    self.stats["deer_deaths"] = self.stats.get("deer_deaths", 0) + 1
                    daily_report.append(f"{icon} {animal.name} the Deer died ({death_reason})")
                else:
                    # Mod animal
                    daily_report.append(f"{icon} {animal.name} the {animal.species} died ({death_reason})")
        
        self.forest = alive_animals
        
        return daily_report
    
    def get_status_dict(self):
        """Get current status as dictionary"""
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        wolves = sum(1 for a in self.forest if isinstance(a, Wolf))
        deer = sum(1 for a in self.forest if isinstance(a, Deer))
        mod_animals = sum(1 for a in self.forest if not isinstance(a, (Lion, Rabbit, Wolf, Deer)))
        
        return {
            'day': self.day,
            'rabbits': rabbits,
            'lions': lions,
            'wolves': wolves,
            'deer': deer,
            'mod_animals': mod_animals,
            'total': len(self.forest),
            'plants': self.environment.food_available,
            'weather': self.environment.weather.value,
            'season': self.environment.season.value
        }
    
    def get_final_stats(self):
        """Get final statistics as string"""
        rabbits = sum(1 for a in self.forest if isinstance(a, Rabbit))
        lions = sum(1 for a in self.forest if isinstance(a, Lion))
        wolves = sum(1 for a in self.forest if isinstance(a, Wolf))
        deer = sum(1 for a in self.forest if isinstance(a, Deer))
        mod_animals = sum(1 for a in self.forest if not isinstance(a, (Lion, Rabbit, Wolf, Deer)))
        
        stats = f"""
{'='*50}
🏆 FINAL STATISTICS
{'='*50}
Days simulated: {self.day}

Final population:
  🐰 Rabbits: {rabbits}
  🦁 Lions:   {lions}
  🐺 Wolves:  {wolves}
  🦌 Deer:    {deer}
  📦 Mods:    {mod_animals}
  Total:      {len(self.forest)}

Births:
  🐰 Rabbits born: {self.stats.get('rabbits_born', 0)}
  🦌 Deer born:    {self.stats.get('deer_born', 0)}

Deaths:
  💀 Total: {self.stats.get('deaths', 0)}
  💀 Starvation: {self.stats.get('starvation_deaths', 0)}
  💀 Old age: {self.stats.get('old_age_deaths', 0)}

Hunting:
  🎯 Successful: {self.stats.get('hunts_successful', 0)}
  ❌ Failed: {self.stats.get('hunts_failed', 0)}
"""
        return stats
    
    def save_simulation(self, filename="simulation_save.pkl"):
        """Save simulation state"""
        with open(filename, 'wb') as f:
            pickle.dump({
                'forest': self.forest,
                'environment': self.environment,
                'day': self.day,
                'stats': self.stats,
                'config': self.config
            }, f)
    
    @classmethod
    def load_simulation(cls, filename="simulation_save.pkl"):
        """Load simulation state"""
        with open(filename, 'rb') as f:
            data = pickle.load(f)
            simulator = cls(data.get('config', Configuration()))
            simulator.forest = data['forest']
            simulator.environment = data['environment']
            simulator.day = data['day']
            simulator.stats = data['stats']
            return simulator

# ==================== GUI MAIN WINDOW ====================

class ForestSimulatorGUI(QMainWindow):
    """Main GUI window for the forest simulator"""
    
    def __init__(self):
        super().__init__()
        self.config = Configuration()
        self.simulator = None
        self.worker = None
        self.thread = None
        self.pause_menu = None
        self.init_ui()
        
        # Create mods directory
        mods_dir = Path(self.config.get('mods.mods_directory', 'mods'))
        mods_dir.mkdir(exist_ok=True)
        
        self.initialize_simulator()
    
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("🌳 Animals: Wildlife Simulator (V1.5.0)")
        self.setGeometry(100, 100, 1400, 900)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Left panel - Controls
        left_panel = self.create_control_panel()
        main_layout.addWidget(left_panel, 1)
        
        # Right panel - Display
        right_panel = self.create_display_panel()
        main_layout.addWidget(right_panel, 2)
        
        # Apply theme
        if self.config.get('display.dark_theme', True):
            self.apply_dark_theme()
    
    def create_control_panel(self):
        """Create the control panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Simulation controls group
        control_group = QGroupBox("Simulation Controls")
        control_layout = QVBoxLayout()
        
        # Day selection
        day_layout = QHBoxLayout()
        day_layout.addWidget(QLabel("Days to run:"))
        self.day_spinbox = QSpinBox()
        self.day_spinbox.setRange(1, self.config.get('simulation.max_days', 1000))
        self.day_spinbox.setValue(30)
        day_layout.addWidget(self.day_spinbox)
        control_layout.addLayout(day_layout)
        
        # Speed control
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("Speed:"))
        self.speed_slider = QProgressBar()
        self.speed_slider.setRange(1, 10)
        self.speed_slider.setValue(self.config.get('simulation.default_speed', 5))
        speed_layout.addWidget(QLabel("Slow"))
        speed_layout.addWidget(self.speed_slider)
        speed_layout.addWidget(QLabel("Fast"))
        control_layout.addLayout(speed_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.start_btn = QPushButton("▶ Start")
        self.start_btn.clicked.connect(self.start_simulation)
        button_layout.addWidget(self.start_btn)
        
        self.pause_btn = QPushButton("⏸ Pause")
        self.pause_btn.clicked.connect(self.pause_simulation)
        self.pause_btn.setEnabled(False)
        button_layout.addWidget(self.pause_btn)
        
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)
        
        control_layout.addLayout(button_layout)
        
        # Step button
        self.step_btn = QPushButton("⏩ Step Day")
        self.step_btn.clicked.connect(self.step_day)
        control_layout.addWidget(self.step_btn)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        # Mods group
        mods_group = QGroupBox("Mods")
        mods_layout = QVBoxLayout()
        
        self.manage_mods_btn = QPushButton("📦 Manage Mods")
        self.manage_mods_btn.clicked.connect(self.manage_mods)
        mods_layout.addWidget(self.manage_mods_btn)
        
        self.mod_status_label = QLabel("Mods loaded: 0")
        mods_layout.addWidget(self.mod_status_label)
        
        mods_group.setLayout(mods_layout)
        layout.addWidget(mods_group)
        
        # Configuration group
        config_group = QGroupBox("Configuration")
        config_layout = QVBoxLayout()
        
        self.edit_config_btn = QPushButton("⚙ Edit Configuration")
        self.edit_config_btn.clicked.connect(self.edit_configuration)
        config_layout.addWidget(self.edit_config_btn)
        
        self.load_config_btn = QPushButton("📂 Load Config")
        self.load_config_btn.clicked.connect(self.load_configuration)
        config_layout.addWidget(self.load_config_btn)
        
        self.save_config_btn = QPushButton("💾 Save Config")
        self.save_config_btn.clicked.connect(self.save_configuration)
        config_layout.addWidget(self.save_config_btn)
        
        # Format selector
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel("Format:"))
        self.config_format = QComboBox()
        for fmt in OutputFormat:
            self.config_format.addItem(fmt.value)
        format_layout.addWidget(self.config_format)
        config_layout.addLayout(format_layout)
        
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # Initialization group
        init_group = QGroupBox("Initialize")
        init_layout = QVBoxLayout()
        
        self.init_btn = QPushButton("🌱 New Forest")
        self.init_btn.clicked.connect(self.initialize_simulator)
        init_layout.addWidget(self.init_btn)
        
        init_group.setLayout(init_layout)
        layout.addWidget(init_group)
        
        # Save/Load group
        save_group = QGroupBox("Save/Load Simulation")
        save_layout = QVBoxLayout()
        
        self.save_btn = QPushButton("💾 Save Simulation")
        self.save_btn.clicked.connect(self.save_simulation)
        save_layout.addWidget(self.save_btn)
        
        self.load_btn = QPushButton("📂 Load Simulation")
        self.load_btn.clicked.connect(self.load_simulation)
        save_layout.addWidget(self.load_btn)
        
        save_group.setLayout(save_layout)
        layout.addWidget(save_group)
        
        # Statistics display
        stats_group = QGroupBox("Current Statistics")
        self.stats_layout = QVBoxLayout()
        
        self.stats_labels = {
            'day': QLabel("Day: 0"),
            'rabbits': QLabel("🐰 Rabbits: 0"),
            'lions': QLabel("🦁 Lions: 0"),
            'wolves': QLabel("🐺 Wolves: 0"),
            'deer': QLabel("🦌 Deer: 0"),
            'mods': QLabel("📦 Mod Animals: 0"),
            'total': QLabel("📊 Total: 0"),
            'plants': QLabel("🌱 Plants: 100"),
            'weather': QLabel("☀️ Weather: Clear"),
            'season': QLabel("🌸 Season: Spring")
        }
        
        for label in self.stats_labels.values():
            self.stats_layout.addWidget(label)
        
        stats_group.setLayout(self.stats_layout)
        layout.addWidget(stats_group)
        
        layout.addStretch()
        return panel
    
    def create_display_panel(self):
        """Create the display panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Tab widget
        tabs = QTabWidget()
        
        # Log tab
        log_widget = QWidget()
        log_layout = QVBoxLayout(log_widget)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier", 10))
        self.log_text.setMaximumBlockCount(self.config.get('display.log_lines', 1000))
        log_layout.addWidget(self.log_text)
        
        tabs.addTab(log_widget, "📋 Event Log")
        
        # Animals tab
        animals_widget = QWidget()
        animals_layout = QVBoxLayout(animals_widget)
        
        self.animals_table = QTableWidget()
        self.animals_table.setColumnCount(7)
        self.animals_table.setHorizontalHeaderLabels(["Icon", "Species", "Name", "Energy", "Age", "Diet", "Territory"])
        self.animals_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        animals_layout.addWidget(self.animals_table)
        
        tabs.addTab(animals_widget, "🐾 Animals")
        
        # Statistics tab
        stats_widget = QWidget()
        stats_layout = QVBoxLayout(stats_widget)
        
        self.stats_table = QTableWidget()
        self.stats_table.setColumnCount(2)
        self.stats_table.setHorizontalHeaderLabels(["Statistic", "Value"])
        self.stats_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        stats_layout.addWidget(self.stats_table)
        
        tabs.addTab(stats_widget, "📊 Statistics")
        
        # Territories tab
        territories_widget = QWidget()
        territories_layout = QVBoxLayout(territories_widget)
        
        self.territories_table = QTableWidget()
        self.territories_table.setColumnCount(5)
        self.territories_table.setHorizontalHeaderLabels(["Territory", "Size", "Occupants", "Resources", "Owner"])
        self.territories_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        territories_layout.addWidget(self.territories_table)
        
        tabs.addTab(territories_widget, "🗺 Territories")
        
        # Mods tab
        mods_widget = QWidget()
        mods_layout = QVBoxLayout(mods_widget)
        
        self.mods_table = QTableWidget()
        self.mods_table.setColumnCount(4)
        self.mods_table.setHorizontalHeaderLabels(["Mod", "Species", "Diet", "Status"])
        self.mods_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        mods_layout.addWidget(self.mods_table)
        
        tabs.addTab(mods_widget, "📦 Loaded Mods")
        
        layout.addWidget(tabs)
        
        return panel
    
    def apply_dark_theme(self):
        """Apply dark theme to the application"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2b2b2b;
            }
            QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
                font-size: 12px;
            }
            QGroupBox {
                border: 2px solid #555;
                border-radius: 5px;
                margin-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QPushButton {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 5px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #4a4a4a;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
            QTextEdit {
                background-color: #1e1e1e;
                border: 1px solid #555;
                border-radius: 3px;
            }
            QTableWidget {
                background-color: #1e1e1e;
                border: 1px solid #555;
                gridline-color: #555;
            }
            QHeaderView::section {
                background-color: #3c3c3c;
                padding: 5px;
                border: 1px solid #555;
            }
            QSpinBox, QDoubleSpinBox, QComboBox, QLineEdit {
                background-color: #1e1e1e;
                border: 1px solid #555;
                border-radius: 3px;
                padding: 2px;
                color: #ffffff;
            }
            QProgressBar {
                border: 1px solid #555;
                border-radius: 3px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #4a90e2;
                border-radius: 2px;
            }
            QTabWidget::pane {
                border: 1px solid #555;
                background-color: #2b2b2b;
            }
            QTabBar::tab {
                background-color: #3c3c3c;
                padding: 5px 10px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: #4a4a4a;
            }
            QDialog {
                background-color: #2b2b2b;
            }
        """)
    
    def initialize_simulator(self):
        """Initialize a new simulator with current config"""
        self.simulator = ForestSimulator(self.config)
        self.simulator.initialize_forest()
        self.update_display()
        self.update_mod_status()
        self.log_text.append("🌳 New forest initialized!")
        self.log_text.append(f"Configuration loaded from: {self.config.config_path or 'defaults'}")
        self.log_text.append(f"Mods loaded: {len(self.simulator.mod_loader.loaded_mods)}")
    
    def update_mod_status(self):
        """Update mod status display"""
        if self.simulator:
            mod_count = len(self.simulator.mod_loader.loaded_mods)
            self.mod_status_label.setText(f"Mods loaded: {mod_count}")
            self.update_mods_table()
    
    def update_mods_table(self):
        """Update the mods table"""
        if not self.simulator:
            return
            
        mods = self.simulator.mod_loader.get_all_mods()
        self.mods_table.setRowCount(len(mods))
        
        for i, mod in enumerate(mods):
            self.mods_table.setItem(i, 0, QTableWidgetItem(mod.name))
            self.mods_table.setItem(i, 1, QTableWidgetItem(mod.id))
            self.mods_table.setItem(i, 2, QTableWidgetItem(mod.data.get('diet_type', 'unknown')))
            
            status = "✅ Enabled" if mod.enabled else "❌ Disabled"
            if mod.error:
                status += f" (⚠️ {mod.error})"
            self.mods_table.setItem(i, 3, QTableWidgetItem(status))
    
    def manage_mods(self):
        """Open mod manager dialog"""
        if self.simulator:
            dialog = ModManagerDialog(self.simulator.mod_loader, self.config, self)
            dialog.mods_changed.connect(self.on_mods_changed)
            dialog.exec()
    
    def on_mods_changed(self):
        """Handle mods changed signal"""
        self.update_mod_status()
        self.log_text.append("📦 Mods updated!")
    
    def start_simulation(self):
        """Start the simulation"""
        if not self.simulator or not self.simulator.forest:
            self.initialize_simulator()
        
        self.start_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.stop_btn.setEnabled(True)
        self.init_btn.setEnabled(False)
        self.step_btn.setEnabled(False)
        self.manage_mods_btn.setEnabled(False)
        self.edit_config_btn.setEnabled(False)
        
        # Create and start worker thread
        self.worker = SimulationWorker(self.simulator)
        self.worker.update_signal.connect(self.add_log)
        self.worker.status_signal.connect(self.update_stats)
        self.worker.finished.connect(self.simulation_finished)
        self.worker.paused_signal.connect(self.show_pause_menu)
        
        # Set speed
        self.worker.speed = self.speed_slider.value()
        
        # Start in separate thread
        self.thread = QThread()
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        
        self.thread.start()
    
    def pause_simulation(self):
        """Pause/resume the simulation"""
        if self.worker:
            self.worker.pause()
            self.pause_btn.setText("▶ Resume" if self.worker.paused else "⏸ Pause")
    
    def show_pause_menu(self):
        """Show the pause menu dialog"""
        if not self.pause_menu:
            self.pause_menu = PauseMenuDialog(self)
            result = self.pause_menu.exec()
            self.handle_pause_menu_result(result)
            self.pause_menu = None
    
    def handle_pause_menu_result(self, result):
        """Handle pause menu result"""
        if result == 1:  # Resume
            self.worker.pause()  # Toggle pause off
            self.pause_btn.setText("⏸ Pause")
        elif result == 2:  # Manage Mods
            self.manage_mods()
            # Show pause menu again
            self.show_pause_menu()
        elif result == 3:  # Exit to Main Menu
            self.stop_simulation()
            self.initialize_simulator()
        elif result == 4:  # Quit Game
            self.close()
    
    def stop_simulation(self):
        """Stop the simulation"""
        if self.worker:
            self.worker.stop()
            if self.thread:
                self.thread.quit()
                self.thread.wait()
            
            self.start_btn.setEnabled(True)
            self.pause_btn.setEnabled(False)
            self.stop_btn.setEnabled(False)
            self.init_btn.setEnabled(True)
            self.step_btn.setEnabled(True)
            self.manage_mods_btn.setEnabled(True)
            self.edit_config_btn.setEnabled(True)
            self.pause_btn.setText("⏸ Pause")
    
    def step_day(self):
        """Run one day of simulation"""
        if self.simulator and self.simulator.forest:
            reports = self.simulator.simulate_day()
            for report in reports:
                self.add_log(report)
            self.update_display()
    
    def simulation_finished(self):
        """Called when simulation finishes"""
        self.start_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.stop_btn.setEnabled(False)
        self.init_btn.setEnabled(True)
        self.step_btn.setEnabled(True)
        self.manage_mods_btn.setEnabled(True)
        self.edit_config_btn.setEnabled(True)
        self.pause_btn.setText("⏸ Pause")
        
        self.add_log("\n🏁 Simulation finished!")
        if self.simulator:
            self.add_log(self.simulator.get_final_stats())
    
    def add_log(self, message):
        """Add message to log"""
        self.log_text.append(message)
        # Scroll to bottom
        cursor = self.log_text.textCursor()
        cursor.movePosition(cursor.End)
        self.log_text.setTextCursor(cursor)
    
    def update_display(self):
        """Update all display elements"""
        if self.simulator:
            self.update_stats(self.simulator.get_status_dict())
            self.update_animals_table()
            self.update_stats_table()
            self.update_territories_table()
            self.update_mods_table()
    
    def update_stats(self, stats):
        """Update statistics display"""
        self.stats_labels['day'].setText(f"Day: {stats['day']}")
        self.stats_labels['rabbits'].setText(f"🐰 Rabbits: {stats['rabbits']}")
        self.stats_labels['lions'].setText(f"🦁 Lions: {stats['lions']}")
        self.stats_labels['wolves'].setText(f"🐺 Wolves: {stats['wolves']}")
        self.stats_labels['deer'].setText(f"🦌 Deer: {stats['deer']}")
        self.stats_labels['mods'].setText(f"📦 Mod Animals: {stats['mod_animals']}")
        self.stats_labels['total'].setText(f"📊 Total: {stats['total']}")
        self.stats_labels['plants'].setText(f"🌱 Plants: {stats['plants']}")
        self.stats_labels['weather'].setText(f"☀️ Weather: {stats['weather'].capitalize()}")
        self.stats_labels['season'].setText(f"🌸 Season: {stats['season'].capitalize()}")
    
    def update_animals_table(self):
        """Update the animals table"""
        if not self.simulator:
            return
            
        self.animals_table.setRowCount(len(self.simulator.forest))
        
        for i, animal in enumerate(self.simulator.forest):
            icon = getattr(animal, 'icon', '🐾')
            icon_item = QTableWidgetItem(icon)
            icon_item.setTextAlignment(Qt.AlignCenter)
            
            species_item = QTableWidgetItem(animal.species)
            name_item = QTableWidgetItem(animal.name)
            energy_item = QTableWidgetItem(str(animal.energy))
            age_item = QTableWidgetItem(str(animal.age))
            diet_item = QTableWidgetItem(animal.diet_type.value if hasattr(animal, 'diet_type') else 'unknown')
            
            # Color code energy
            if animal.energy < 20:
                energy_item.setForeground(QColor(255, 100, 100))
            elif animal.energy > 50:
                energy_item.setForeground(QColor(100, 255, 100))
            
            # Territory
            territory_item = QTableWidgetItem(animal.territory.name if animal.territory else "None")
            
            self.animals_table.setItem(i, 0, icon_item)
            self.animals_table.setItem(i, 1, species_item)
            self.animals_table.setItem(i, 2, name_item)
            self.animals_table.setItem(i, 3, energy_item)
            self.animals_table.setItem(i, 4, age_item)
            self.animals_table.setItem(i, 5, diet_item)
            self.animals_table.setItem(i, 6, territory_item)
    
    def update_stats_table(self):
        """Update the statistics table"""
        if not self.simulator:
            return
            
        stats = self.simulator.stats
        self.stats_table.setRowCount(20)
        
        stat_items = [
            ("Total Days", str(self.simulator.day)),
            ("Total Animals", str(len(self.simulator.forest))),
            ("Total Births", str(stats.get('rabbits_born', 0) + stats.get('deer_born', 0))),
            ("Total Deaths", str(stats.get('deaths', 0))),
            ("Starvation Deaths", str(stats.get('starvation_deaths', 0))),
            ("Old Age Deaths", str(stats.get('old_age_deaths', 0))),
            ("Successful Hunts", str(stats.get('hunts_successful', 0))),
            ("Failed Hunts", str(stats.get('hunts_failed', 0))),
            ("Plant Consumption", str(stats.get('plant_consumption', 0))),
            ("Clear Days", str(stats.get('weather_events', {}).get('clear', 0))),
            ("Rainy Days", str(stats.get('weather_events', {}).get('rain', 0))),
            ("Drought Days", str(stats.get('weather_events', {}).get('drought', 0))),
            ("Storm Days", str(stats.get('weather_events', {}).get('storm', 0))),
            ("Mild Days", str(stats.get('weather_events', {}).get('mild', 0)))
        ]
        
        for i, (label, value) in enumerate(stat_items):
            self.stats_table.setItem(i, 0, QTableWidgetItem(label))
            self.stats_table.setItem(i, 1, QTableWidgetItem(value))
    
    def update_territories_table(self):
        """Update the territories table"""
        if not self.simulator or not self.simulator.environment:
            return
            
        territories = self.simulator.environment.territories
        self.territories_table.setRowCount(len(territories))
        
        for i, territory in enumerate(territories):
            self.territories_table.setItem(i, 0, QTableWidgetItem(territory.name))
            self.territories_table.setItem(i, 1, QTableWidgetItem(str(territory.size)))
            self.territories_table.setItem(i, 2, QTableWidgetItem(str(len(territory.occupants))))
            self.territories_table.setItem(i, 3, QTableWidgetItem(str(int(territory.resources))))
            self.territories_table.setItem(i, 4, QTableWidgetItem(
                territory.owner.name if territory.owner else "Unowned"
            ))
    
    def edit_configuration(self):
        """Open configuration editor"""
        from importlib import import_module
        # For simplicity, we'll just show a message that this would open the editor
        # In a full implementation, you'd create a ConfigurationDialog similar to ModManagerDialog
        QMessageBox.information(self, "Info", "Configuration editor would open here")
    
    def load_configuration(self):
        """Load configuration from file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Configuration", "", 
            "Config Files (*.json *.hjson *.msgpack *.bson *.xml *.toml *.yaml *.yml);;All Files (*)"
        )
        
        if file_path:
            if self.config.load(file_path):
                self.log_text.append(f"✅ Configuration loaded from {file_path}")
                # Update UI with new config
                if self.config.get('display.dark_theme', True):
                    self.apply_dark_theme()
                self.day_spinbox.setRange(1, self.config.get('simulation.max_days', 1000))
                self.speed_slider.setValue(self.config.get('simulation.default_speed', 5))
            else:
                QMessageBox.warning(self, "Error", f"Failed to load configuration from {file_path}")
    
    def save_configuration(self):
        """Save configuration to file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Configuration", "config",
            f"JSON (*.json);;HJSON (*.hjson);;MessagePack (*.msgpack);;BSON (*.bson);;XML (*.xml);;TOML (*.toml);;YAML (*.yaml);;Pickle (*.pkl)"
        )
        
        if file_path:
            # Get selected format from file extension
            suffix = Path(file_path).suffix[1:]  # Remove the dot
            try:
                format_enum = OutputFormat(suffix)
            except ValueError:
                format_enum = OutputFormat.JSON
                file_path += '.json'
            
            if self.config.save(file_path, format_enum):
                self.log_text.append(f"✅ Configuration saved to {file_path}")
            else:
                QMessageBox.warning(self, "Error", f"Failed to save configuration to {file_path}")
    
    def save_simulation(self):
        """Save the simulation state"""
        if not self.simulator:
            return
            
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Simulation", "simulation", "Pickle Files (*.pkl)"
        )
        
        if file_path:
            self.simulator.save_simulation(file_path)
            self.add_log(f"💾 Simulation saved to {file_path}")
    
    def load_simulation(self):
        """Load a saved simulation"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Simulation", "", "Pickle Files (*.pkl)"
        )
        
        if file_path:
            try:
                self.simulator = ForestSimulator.load_simulation(file_path)
                self.config = self.simulator.config
                self.update_display()
                self.update_mod_status()
                self.add_log(f"📂 Simulation loaded from {file_path}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load simulation: {e}")

# ==================== MAIN ====================

def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    
    # Create and show GUI
    gui = ForestSimulatorGUI()
    gui.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()