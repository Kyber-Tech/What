
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { ai, getCharacterFeats, summarizeBattle, generateCharacterIdeas } from './services/geminiService';
import type { Character, ChartData, Battle, Message, CharacterNumericalStats, CharacterStats } from './types';
import type { Chat } from '@google/genai';
import { Type } from '@google/genai';
import { Header } from './components/Header';
import { CharacterInput } from './components/CharacterInput';
import { AnalysisResult } from './components/AnalysisResult';
import { Rules } from './components/Rules';
import { BattleHistory } from './components/BattleHistory';
import { getHistory, saveBattleToHistory, clearHistory } from './historyService';
import { UPSGC_RULES, BALANCED_MODEL, HEAVY_MODEL, FAST_MODEL } from './constants';
import { generateShareLink, parseDataFromHash } from './services/sharingService';
import { ModelSelector } from './components/ModelSelector';
import { AboutApp } from './components/AboutApp';
import { SparklesIcon } from './components/SparklesIcon';

const BASE_SYSTEM_INSTRUCTION = `You are an expert, unbiased VS Battle Analyst. Your sole task is to determine the winner of a matchup between two fictional characters based STRICTLY on the provided "Unified Power-Scaling System for General Use (UPSGC)".

**DO NOT** use any external knowledge or other power-scaling systems. Your entire analysis must be derived from the provided character feats and the UPSGC framework. After providing the initial analysis, you will engage in a debate with the user if they disagree, always grounding your arguments in the UPSGC rules and provided feats.`;

const getSystemInstruction = (memoryContext: string) => `${memoryContext}${BASE_SYSTEM_INSTRUCTION}`;

const chartLabels: (keyof CharacterNumericalStats)[] = [
  'Destructive Power',
  'Striking Strength',
  'Lifting Strength',
  'Travel Speed',
  'Combat Speed',
  'Reaction Speed',
  'Durability',
  'Scope of Influence',
  'Hax/Abilities',
  'Strategic Intelligence',
  'Psychological Resistance',
  'Psychological Attack Potency',
];

const getDisplayName = (character: Character) => {
    return character.version ? `${character.name} (${character.version})` : character.name;
};

const App: React.FC = () => {
    const [characterA, setCharacterA] = useState<Character>({ name: '', origin: '', feats: '', dimensionality: '', version: '' });
    const [characterB, setCharacterB] = useState<Character>({ name: '', origin: '', feats: '', dimensionality: '', version: '' });
    const [result, setResult] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [chartData, setChartData] = useState<ChartData | null>(null);
    const [theme, setTheme] = useState<'light' | 'dark'>('dark');
    const [battleHistory, setBattleHistory] = useState<Battle[]>([]);
    const [conversation, setConversation] = useState<Message[]>([]);
    const [isReplying, setIsReplying] = useState(false);
    const [currentBattle, setCurrentBattle] = useState<Battle | null>(null);
    const [selectedModel, setSelectedModel] = useState(BALANCED_MODEL);
    const [shareableLink, setShareableLink] = useState<string | null>(null);

    const chatRef = useRef<Chat | null>(null);
    const selectionInterval = useRef<number | null>(null);

    const [isLuckySelecting, setIsLuckySelecting] = useState(false);
    
    const toggleTheme = useCallback(() => {
        setTheme(prevTheme => {
            const newTheme = prevTheme === 'light' ? 'dark' : 'light';
            localStorage.setItem('theme', newTheme);
            if (newTheme === 'dark') {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
            return newTheme;
        });
    }, []);

    useEffect(() => {
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const initialTheme = savedTheme === 'dark' || (!savedTheme && prefersDark) ? 'dark' : 'light';
        setTheme(initialTheme);
        if (initialTheme === 'dark') {
            document.documentElement.classList.add('dark');
        }

        setBattleHistory(getHistory());

        const battleFromHash = parseDataFromHash();
        if (battleFromHash) {
            loadBattle(battleFromHash);
            window.location.hash = '';
        }
    }, []);

    // Effect to generate the shareable link when a battle is completed or loaded.
    useEffect(() => {
        if (currentBattle) {
            try {
                const link = generateShareLink(currentBattle);
                setShareableLink(link);
            } catch (err) {
                console.error("Share link generation failed:", err);
                const errorMessage = err instanceof Error ? err.message : "An unknown error occurred while creating the share link.";
                // Append this error to the main error state so it's visible.
                setError(prevError => prevError ? `${prevError}\n${errorMessage}` : errorMessage);
                setShareableLink(null);
            }
        } else {
            setShareableLink(null);
        }
    }, [currentBattle]);
    
    const loadBattle = (battle: Battle) => {
        setCharacterA(battle.characterA);
        setCharacterB(battle.characterB);
        setResult(battle.result);
        setChartData(battle.chartData);
        setConversation(battle.conversation || []);
        setCurrentBattle(battle);
        setSelectedModel(battle.model || BALANCED_MODEL);
        setTimeout(() => {
            document.getElementById('verdict-section')?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
    };

    const handleClearHistory = () => {
        setBattleHistory(clearHistory());
    };

    const handleAnalyze = async () => {
        if (!characterA.name || !characterA.origin || !characterB.name || !characterB.origin) {
            setError('Both characters must have a name and origin.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setResult(null);
        setChartData(null);
        setConversation([]);
        chatRef.current = null;
        setCurrentBattle(null);

        try {
            // STEP 1: Get Stats with Tier-First Mandate
            setLoadingMessage('Performing statistical analysis...');
            const analysisPrompt = `
You are a meticulous VS Battle Analyst and researcher. Your task is to analyze two characters based on the "Unified Power-Scaling System for General Use (UPSGC)" rules.

**CRITICAL INSTRUCTIONS - FOLLOW THIS PROCESS EXACTLY:**

1.  **RESEARCH (MOST IMPORTANT FIRST STEP):**
    *   For each character, use your internal knowledge to research their canonical feats and abilities.
    *   The user may provide a list of feats for context. Use these as a starting point, but you MUST prioritize your own verified, canonical research. If user-provided feats seem inaccurate or out of context, disregard them in favor of established canon.

2.  **TIER ASSIGNMENT:**
    *   **Power Tier:** Identify the character's single most powerful and consistent feat. Based SOLELY on that feat, assign them a Power Tier (e.g., "Tier 5: Planetary Level"). Be precise with low tiers (e.g., Tier 0.6 vs 0.7).
    *   **MPS Tier (Mental & Psychological State):** Evaluate their mental fortitude based on the 7 UPSGC tiers: Absolute, Strong, High, Moderate, Low, Weak, Non-existent.
    *   **Dimensionality:** Determine if the character is Mono-Dimensional, Poly-Dimensional, or Meta-Dimensional according to the rules.
    *   **Immunity Level:** Assign an Immunity Hax Level (1-5) if applicable.

3.  **NUMERICAL STAT DERIVATION:**
    *   Derive numerical scores (1-100) for all stats, including the granular speed metrics (Travel, Combat, Reaction).
    *   **The scores MUST reflect the Power Tier.** A character in a higher tier should have drastically higher scores.

**RULES:**
${UPSGC_RULES}

---

**CHARACTER A: ${characterA.name} (${characterA.version || 'Standard'}) from ${characterA.origin}**
*Dimensionality Hint:* ${characterA.dimensionality || 'Not specified'}
*User-Provided Feats:*
${characterA.feats || 'None provided. Rely on your own research.'}

---

**CHARACTER B: ${characterB.name} (${characterB.version || 'Standard'}) from ${characterB.origin}**
*Dimensionality Hint:* ${characterB.dimensionality || 'Not specified'}
*User-Provided Feats:*
${characterB.feats || 'None provided. Rely on your own research.'}

---

Provide your analysis in the required JSON format. Do not include any other text or explanation.
`;

            const statsSchema = {
                type: Type.OBJECT,
                properties: {
                    tier: { type: Type.STRING, description: "The Power Tier assigned based on the single most powerful feat." },
                    tierJustification: { type: Type.STRING, description: "A one-sentence justification for the assigned Power Tier." },
                    mpsTier: { type: Type.STRING, description: "The Mental & Psychological State (MPS) Tier. One of: Absolute, Strong, High, Moderate, Low, Weak, Non-existent." },
                    mpsTierJustification: { type: Type.STRING, description: "A brief justification for the assigned MPS Tier." },
                    immunityLevel: { type: Type.NUMBER, description: "Integer 0-5 based on UPSGC Immunity Hax tiers." },
                    immunityJustification: { type: Type.STRING, description: "Brief reason for immunity level." },
                    dimensionality: { type: Type.STRING, description: "One of: Mono-Dimensional, Poly-Dimensional, Meta-Dimensional." },
                    'Destructive Power': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Striking Strength': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Lifting Strength': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Travel Speed': { type: Type.NUMBER, description: "Score 1-100 based on UPSGC tiers." },
                    'Combat Speed': { type: Type.NUMBER, description: "Score 1-100." },
                    'Reaction Speed': { type: Type.NUMBER, description: "Score 1-100." },
                    'Durability': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Scope of Influence': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Hax/Abilities': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Strategic Intelligence': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Psychological Resistance': { type: Type.NUMBER, description: "Score from 1-100." },
                    'Psychological Attack Potency': { type: Type.NUMBER, description: "Score from 1-100." },
                },
                required: [
                    'tier',
                    'tierJustification',
                    'mpsTier',
                    'mpsTierJustification',
                    'immunityLevel',
                    'immunityJustification',
                    'dimensionality',
                    'Destructive Power',
                    'Striking Strength',
                    'Lifting Strength',
                    'Travel Speed',
                    'Combat Speed',
                    'Reaction Speed',
                    'Durability',
                    'Scope of Influence',
                    'Hax/Abilities',
                    'Strategic Intelligence',
                    'Psychological Resistance',
                    'Psychological Attack Potency',
                ]
            };
            const analysisSchema = {
                type: Type.OBJECT,
                properties: {
                    charA: statsSchema,
                    charB: statsSchema,
                },
                required: ['charA', 'charB']
            };
            
            const statsConfig: any = {
                responseMimeType: 'application/json',
                responseSchema: analysisSchema,
            };

            if (selectedModel === HEAVY_MODEL) {
                statsConfig.thinkingConfig = { thinkingBudget: 32768 };
            }

            const statsResponse = await ai.models.generateContent({
                model: selectedModel,
                contents: analysisPrompt,
                config: statsConfig,
            });
            
            const text = statsResponse.text;
            if (!text) {
                throw new Error("The AI returned an empty response for the statistical analysis.");
            }

            let analysis: { charA: CharacterStats; charB: CharacterStats; };
            try {
                analysis = JSON.parse(text);
            } catch (e) {
                console.error("Failed to parse stats JSON:", text, e);
                throw new Error("The AI returned a malformed response for the statistical analysis. Please try again.");
            }


            setChartData({
                charA: analysis.charA,
                charB: analysis.charB,
                labels: chartLabels
            });

            // STEP 2: Generate the textual report
            setLoadingMessage('Writing battle report...');
            const reportPrompt = `
You are a VS Battle Analyst and writer.
You have already performed a statistical analysis of two characters based on the UPSGC rules. Your task now is to write a detailed battle report.

**ANALYSIS DATA (Ground Truth):**

**Character A: ${characterA.name}**
*   **Power Tier:** ${analysis.charA.tier}
*   **MPS Tier:** ${analysis.charA.mpsTier}
*   **Immunity Level:** ${analysis.charA.immunityLevel} (${analysis.charA.immunityJustification})
*   **Dimensionality:** ${analysis.charA.dimensionality}
*   **Stats:** ${JSON.stringify(analysis.charA, null, 2)}
*   **Context:** ${characterA.feats || 'N/A'}

**Character B: ${characterB.name}**
*   **Power Tier:** ${analysis.charB.tier}
*   **MPS Tier:** ${analysis.charB.mpsTier}
*   **Immunity Level:** ${analysis.charB.immunityLevel} (${analysis.charB.immunityJustification})
*   **Dimensionality:** ${analysis.charB.dimensionality}
*   **Stats:** ${JSON.stringify(analysis.charB, null, 2)}
*   **Context:** ${characterB.feats || 'N/A'}

**WRITING & MARKDOWN FORMATTING INSTRUCTIONS:**

1.  **Verdict First:** Start with a clear "### Conclusion & Verdict" section. State the winner unequivocally.

2.  **Detailed Breakdown:** Create a "### Detailed Breakdown" section. Use bullet points ("* ") to compare key stats.
    *   **Speed Interaction:** Explicitly analyze Travel vs Reaction speed. Mention if a "Blitzsieg" occurs based on Reaction Time differences.
    *   **Immunity Interaction:** Compare their Immunity Hax Levels. Does one character bypass the other's defenses?
    *   **Dimensionality:** Discuss any dimensional advantages.

3.  **Battle Scenario:** Write a "### Battle Scenario" section. Describe a plausible, moment-by-moment narrative.

4.  **Adhere to the Data:** Your report must be consistent with the provided stats, tiers, and immunity levels.
`;
            
            const reportConfig: any = {};
            if (selectedModel === HEAVY_MODEL) {
                reportConfig.thinkingConfig = { thinkingBudget: 32768 };
            }

            const reportResponse = await ai.models.generateContent({
                model: selectedModel,
                contents: reportPrompt,
                config: Object.keys(reportConfig).length > 0 ? reportConfig : undefined,
            });

            const reportText = reportResponse.text;
            if (!reportText) {
                throw new Error("The AI returned an empty response for the battle report.");
            }
            
            setResult(reportText);

            setConversation([{ role: 'model', content: reportText }]);
            
            const battleSummary = await summarizeBattle(reportText);

            const newBattle: Battle = {
                id: crypto.randomUUID(),
                characterA: characterA,
                characterB: characterB,
                result: reportText,
                chartData: {
                    charA: analysis.charA,
                    charB: analysis.charB,
                    labels: chartLabels
                },
                timestamp: Date.now(),
                conversation: [{ role: 'model', content: reportText }],
                initialPrompt: reportPrompt,
                model: selectedModel,
                summary: battleSummary
            };
            setCurrentBattle(newBattle);
            setBattleHistory(saveBattleToHistory(newBattle));

        } catch (err) {
            console.error("Analysis failed:", err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred during analysis.');
        } finally {
            setIsLoading(false);
            setLoadingMessage('');
        }
    };
    
    const handleFeelingLucky = async () => {
        setIsLoading(true);
        setError(null);
        setResult(null);
        setChartData(null);
        setConversation([]);
        
        try {
            setLoadingMessage("Summoning combatant ideas...");
            const ideas = await generateCharacterIdeas();

            setLoadingMessage("Choosing the warriors...");
            setIsLuckySelecting(true);

            const shuffled = ideas.sort(() => 0.5 - Math.random());
            const charAIdea = shuffled[0];
            const charBIdea = shuffled[1];

            let cycles = 0;
            const maxCycles = 20 + Math.floor(Math.random() * 10);
            if (selectionInterval.current) clearInterval(selectionInterval.current);

            selectionInterval.current = window.setInterval(() => {
                cycles++;
                if (cycles > maxCycles) {
                    if (selectionInterval.current) clearInterval(selectionInterval.current);
                    setIsLuckySelecting(false);
                    setCharacterA(c => ({ ...c, name: charAIdea.name, origin: charAIdea.origin, feats: '', version: '', dimensionality: '' }));
                    setCharacterB(c => ({ ...c, name: charBIdea.name, origin: charBIdea.origin, feats: '', version: '', dimensionality: '' }));
                    
                    const fillFeats = async () => {
                        try {
                            setLoadingMessage(`Gathering intel on ${charAIdea.name}...`);
                            const featsA = await getCharacterFeats(charAIdea.name, charAIdea.origin);
                            setCharacterA(c => ({...c, feats: featsA}));

                            setLoadingMessage(`Gathering intel on ${charBIdea.name}...`);
                            const featsB = await getCharacterFeats(charBIdea.name, charBIdea.origin);
                            setCharacterB(c => ({...c, feats: featsB}));
                            
                            setIsLoading(false);
                            setLoadingMessage('');

                        } catch (err) {
                           setError(err instanceof Error ? err.message : 'Failed to auto-fill feats for lucky matchup.');
                           setIsLoading(false);
                           setLoadingMessage('');
                        }
                    };
                    fillFeats();
                    return;
                }

                const randomA = ideas[Math.floor(Math.random() * ideas.length)];
                const randomB = ideas[Math.floor(Math.random() * ideas.length)];
                setCharacterA(c => ({ ...c, name: randomA.name, origin: randomA.origin }));
                setCharacterB(c => ({ ...c, name: randomB.name, origin: randomB.origin }));
            }, 150);

        } catch (err) {
            setError(err instanceof Error ? err.message : "The 'I'm Feeling Lucky' feature failed.");
            setIsLoading(false);
            setIsLuckySelecting(false);
        }
    };
    
    const handleSendMessage = async (message: string) => {
        if (!currentBattle || !currentBattle.initialPrompt) {
            setError("Cannot start debate without an initial battle context.");
            return;
        }

        const newUserMessage: Message = { role: 'user', content: message };
        const baseConversation = conversation; // Capture current state to avoid stale closures.

        const updatedConversation = [...baseConversation, newUserMessage, { role: 'model', content: '' }];
        setConversation(updatedConversation);
        setIsReplying(true);

        try {
            if (!chatRef.current) {
                // The history for the chat should be the conversation state *before* the new user message.
                // The original .slice(0,-1) was incorrect as it would remove crucial context.
                // FIX: Add explicit type to `msg` to prevent TypeScript from widening the type of `baseConversation`.
                const historyForMemory = baseConversation
                    .map((msg: Message) => ({
                        role: msg.role,
                        parts: [{ text: msg.content }]
                    }));

                const memoryContext = `
### PREVIOUS BATTLE CONTEXT & DEBATE HISTORY
This is the analysis and conversation so far. Continue the debate from this point.
---
`;
                
                const chatModel = currentBattle.model || BALANCED_MODEL;
                const chatConfig: any = {
                    systemInstruction: getSystemInstruction(memoryContext),
                };

                if (chatModel === HEAVY_MODEL) {
                    chatConfig.thinkingConfig = { thinkingBudget: 32768 };
                }

                chatRef.current = ai.chats.create({
                    model: chatModel,
                    config: chatConfig,
                    history: historyForMemory
                });
            }

            const result = await chatRef.current.sendMessageStream({ message });
            
            let accumulatedText = '';
            for await (const chunk of result) {
                accumulatedText += chunk.text;
                // Build new conversation state from the captured base state to ensure consistency.
                setConversation([
                    ...baseConversation,
                    newUserMessage,
                    { role: 'model', content: accumulatedText }
                ]);
            }
            
            const finalConversation: Message[] = [...baseConversation, newUserMessage, { role: 'model', content: accumulatedText }];
            
            // Use captured currentBattle to build the updated battle object to avoid stale state.
            const updatedBattle = { ...currentBattle, conversation: finalConversation };
            setCurrentBattle(updatedBattle);
            setBattleHistory(saveBattleToHistory(updatedBattle));


        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "An unknown error occurred in the debate.";
            setError(errorMessage);
            // Revert conversation to the state before the user's failed message.
            setConversation(baseConversation);
        } finally {
            setIsReplying(false);
        }
    };
    
    return (
      <div className="bg-gray-100 dark:bg-gray-900 min-h-screen text-gray-900 dark:text-gray-100 font-sans transition-colors duration-300">
        <main className="container mx-auto px-4 py-8">
          <Header theme={theme} toggleTheme={toggleTheme} />
          <div className="mt-12 max-w-4xl mx-auto">
            <ModelSelector selectedModel={selectedModel} onModelChange={setSelectedModel} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <CharacterInput title="Combatant A" character={characterA} setCharacter={setCharacterA} isLuckySelecting={isLuckySelecting} />
              <CharacterInput title="Combatant B" character={characterB} setCharacter={setCharacterB} isLuckySelecting={isLuckySelecting} />
            </div>
            <div className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4">
              <button
                onClick={handleAnalyze}
                disabled={isLoading || !characterA.name || !characterA.origin || !characterB.name || !characterB.origin}
                className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 focus:ring-indigo-500 transition-all duration-200 transform active:scale-95"
              >
                {isLoading && loadingMessage ? loadingMessage : 'Analyze Matchup'}
              </button>
               <button
                onClick={handleFeelingLucky}
                disabled={isLoading}
                className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 focus:ring-purple-500 transition-all duration-200 transform active:scale-95"
              >
                <SparklesIcon className="-ml-1 mr-2 h-5 w-5" />
                I'm Feeling Lucky
              </button>
            </div>
          </div>
          <AnalysisResult
            result={result}
            isLoading={isLoading && !isLuckySelecting}
            error={error}
            chartData={chartData}
            characterNames={{ a: getDisplayName(characterA), b: getDisplayName(characterB) }}
            conversation={conversation}
            isReplying={isReplying}
            onSendMessage={handleSendMessage}
            shareableLink={shareableLink}
          />
          <AboutApp />
          <Rules />
          <BattleHistory history={battleHistory} onSelect={loadBattle} onClear={handleClearHistory} />
        </main>
      </div>
    );
};

export default App;
