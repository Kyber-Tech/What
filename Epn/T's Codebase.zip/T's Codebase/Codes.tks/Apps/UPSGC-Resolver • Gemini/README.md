
# UPSGC-Resolver • Gemini

An unbiased VS debating system for fictional characters, powered by Google's Gemini AI. Enter two characters, get a detailed analysis based on a consistent power-scaling framework, debate the AI's verdict, and share the battle with a friend!

## Features

-   **AI-Powered Analysis**: Leverages the Gemini API for in-depth, unbiased analysis of fictional character matchups.
-   **Consistent Rule-Based Verdicts**: All analyses are strictly bound by the "Unified Power-Scaling System for General Use" (UPSGC) to ensure consistency.
-   **Data-Driven Visualizations**: Compares characters using a radar chart and a side-by-side stat table for a clear visual breakdown.
-   **Automated Research**: The AI performs its own research on characters to determine their canonical feats and abilities, ensuring accuracy even with minimal user input.
-   **Interactive Debate Zone**: Don't agree with the outcome? Challenge the AI's reasoning in a one-on-one debate.
-   **"I'm Feeling Lucky"**: Can't decide on a matchup? Let the app generate a random, interesting battle for you.
-   **Battle History & Sharing**: Save your favorite matchups and share a unique link with others to view the results and continue the debate.
-   **Selectable AI Models**: Choose between Fast, Balanced, and Heavy Reasoning models to control the speed and depth of the analysis.

## How to Use

1.  **(Optional) Select an Analysis Model**: At the top of the page, you can choose between 'Fast', 'Balanced', or 'Heavy Reasoning' models. 'Balanced' is the default and recommended for most uses.
2.  **Enter Combatants**: Fill in the 'Character Name' and 'Origin / Series' for both Combatant A and Combatant B. This is the minimum information required.
3.  **(Optional) Specify Versions**: If a character has multiple versions with different power levels (e.g., "Post-Crisis Superman"), you can specify it in the 'Version / Era' field. Use the ✨ button to get AI-powered suggestions.
4.  **(Optional) Provide Feats**: You can list known feats and abilities in the text box to provide context. The AI will primarily use its own research, but this can help guide it. Use the "Research Feats" button to have the AI auto-fill this section based on its knowledge.
5.  **Analyze**: Click the **Analyze Matchup** button. The AI will now perform its research and generate a verdict. This may take a few moments.
6.  **Review the Verdict**: The results will appear below, including:
    -   A Power Tier comparison.
    -   A detailed written breakdown and battle scenario.
    -   A radar chart and stat table.
7.  **Debate the AI**: If you disagree with the analysis, scroll down to the **Debate Zone**. Type your argument and press send to challenge the AI's conclusion.
8.  **Share Your Battle**: Click the **Share Battle** button to copy a unique link to your clipboard. Anyone with the link can view the full analysis and continue the debate.

## The UPSGC System

The Unified Power-Scaling System for General Use (UPSGC) is a fan-made, comprehensive framework created to standardize how character abilities are measured. It establishes a clear tiering system (from **Tier 0.1: Minor Level** to **Tier 14: Ultra-Fiction**) and defines core criteria like Destructive Capacity, Speed, and Hax. By using a single, detailed rulebook, this application can compare characters from different universes on a more level playing field.

## Technology Stack

-   **AI**: Google Gemini API (`gemini-flash-latest`, `gemini-2.5-pro`)
-   **Frontend**: React & TypeScript
-   **Styling**: Tailwind CSS
