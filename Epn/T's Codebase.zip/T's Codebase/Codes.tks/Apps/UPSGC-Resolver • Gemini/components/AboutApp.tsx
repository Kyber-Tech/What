
import React, { useState } from 'react';

const ChevronDownIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
    </svg>
);

export const AboutApp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="mt-8 max-w-4xl mx-auto bg-gray-100 dark:bg-gray-800/50 rounded-lg border border-gray-200 dark:border-gray-700">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left font-semibold text-lg hover:bg-gray-200 dark:hover:bg-gray-700/50 transition-colors"
        aria-expanded={isOpen}
        aria-controls="about-app-content"
      >
        <span>What is UPSGC-Resolver?</span>
        <ChevronDownIcon className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div id="about-app-content" className="p-6 border-t border-gray-200 dark:border-gray-700 prose dark:prose-invert prose-lg max-w-none text-gray-600 dark:text-gray-300 animate-fadeIn">
          <h3 className="text-purple-500 dark:text-purple-400">The Goal</h3>
          <p>
            UPSGC-Resolver is an experimental tool designed to bring a structured, data-driven, and unbiased approach to the classic "VS" debates about fictional characters. Its purpose is to provide a verdict based on a consistent set of rules (UPSGC) and verified canonical evidence.
          </p>

          <h3 className="text-purple-500 dark:text-purple-400">How The AI Works</h3>
          <p>
            The analysis is powered by Google's Gemini AI. The AI operates under a strict set of directives:
          </p>
          <ul>
            <li>It <strong>prioritizes internal research</strong> to identify canonical feats and abilities from valid sources, ensuring accuracy even if you don't list every feat manually.</li>
            <li>It uses your input as context or to specify particular versions of a character, but will correct inaccuracies if they contradict established canon.</li>
            <li>It <strong>must</strong> adhere exclusively to the mechanics of the Unified Power-Scaling System for General Use (UPSGC)—specifically regarding Speed (Travel vs. Reaction), Hax Immunity levels, and Dimensionality—ignoring tiering conventions from other popular battle wikis.</li>
          </ul>
          <p>
            This creates a balance: the AI acts as an impartial researcher and referee, applying specific mechanical rules to the lore of the characters.
          </p>

          <h3 className="text-purple-500 dark:text-purple-400">The UPSGC System</h3>
          <p>
            The Unified Power-Scaling System for General Use (UPSGC) is a fan-made, comprehensive framework created to standardize how character abilities are measured. It establishes a clear tiering system (from <strong>Tier 0.1: Minor Level</strong> to <strong>Tier 14: Ultra-Fiction</strong>) and defines core criteria like Destructive Capacity, Speed (splitting Reaction and Travel speed for "Blitzsieg" mechanics), and Hax. By using a single, detailed rulebook, we can compare characters from different universes on a more level playing field. You can read the full ruleset in the section below.
          </p>

          <h3 className="text-purple-500 dark:text-purple-400">Debate and Share</h3>
          <p>
             The initial verdict is just the beginning. The "Debate Zone" allows you to challenge the AI's reasoning. If you believe it misinterpreted a feat or misapplied a rule, you can argue your case. The AI will defend its position, always referencing the UPSGC rules. Finally, you can share a unique link to any battle, allowing others to view the analysis and even continue the debate from where you left off.
          </p>
        </div>
      )}
    </div>
  );
};
