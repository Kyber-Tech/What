import React, { useState, useRef } from 'react';
import type { ChartData, CharacterNumericalStats } from '../types';
import { STAT_EXPLANATIONS } from '../constants';

interface StatComparisonTableProps {
  data: ChartData;
  characterNames: { a: string; b: string };
}

export const StatComparisonTable: React.FC<StatComparisonTableProps> = ({ data, characterNames }) => {
  const { labels, charA, charB } = data;
  const [activeStat, setActiveStat] = useState<keyof CharacterNumericalStats | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const tooltipId = 'stat-table-tooltip'; // Unique ID for ARIA

  // Show tooltip on hover or focus, calculating position relative to the stat label element.
  const showTooltip = (event: React.MouseEvent | React.FocusEvent, stat: keyof CharacterNumericalStats) => {
    if (!containerRef.current) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    const targetRect = (event.currentTarget as Element).getBoundingClientRect();
    
    // Position tooltip to the right of the stat label
    const x = targetRect.right - containerRect.left;
    const y = targetRect.top + targetRect.height / 2 - containerRect.top;

    setActiveStat(stat);
    setTooltipPosition({ x, y });
  };

  // Hide tooltip when the mouse leaves or the element loses focus.
  const hideTooltip = () => {
    setActiveStat(null);
    setTooltipPosition(null);
  };

  return (
    <div ref={containerRef} className="relative mt-8 xl:mt-0">
      <div className="overflow-x-auto bg-gray-50 dark:bg-gray-900/50 rounded-lg p-4 border border-gray-200 dark:border-gray-700/50">
        <table className="min-w-full">
          <caption className="text-lg font-semibold mb-4 text-gray-800 dark:text-gray-200">
            Side-by-Side Stats
          </caption>
          <thead>
            <tr>
              <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300 sm:pl-2">
                Stat
              </th>
              <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-indigo-600 dark:text-indigo-400">
                {characterNames.a || 'Character One'}
              </th>
              <th scope="col" className="px-3 py-3.5 text-center text-sm font-semibold text-purple-600 dark:text-purple-400">
                {characterNames.b || 'Character Two'}
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
            {labels.map((stat) => {
              const scoreA = charA[stat];
              const scoreB = charB[stat];
              const isAHigher = scoreA > scoreB;
              const isBHigher = scoreB > scoreA;

              const classA = isAHigher ? 'font-bold text-green-700 bg-green-100 dark:text-green-300 dark:bg-green-900/40' : (isBHigher ? 'text-gray-400 dark:text-gray-500' : 'text-gray-700 dark:text-gray-300');
              const classB = isBHigher ? 'font-bold text-green-700 bg-green-100 dark:text-green-300 dark:bg-green-900/40' : (isAHigher ? 'text-gray-400 dark:text-gray-500' : 'text-gray-700 dark:text-gray-300');

              return (
                <tr key={stat} className="hover:bg-gray-100 dark:hover:bg-gray-800/50">
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-800 dark:text-gray-300 sm:pl-2">
                    <span
                      role="button"
                      aria-describedby={activeStat === stat ? tooltipId : undefined}
                      className="cursor-pointer border-b border-dotted border-gray-400 dark:border-gray-500 hover:border-gray-900 dark:hover:border-white focus:border-gray-900 dark:focus:border-white focus:outline-none transition-colors"
                      tabIndex={0}
                      onMouseEnter={(e) => showTooltip(e, stat)}
                      onMouseLeave={hideTooltip}
                      onFocus={(e) => showTooltip(e, stat)}
                      onBlur={hideTooltip}
                    >
                      {stat}
                    </span>
                  </td>
                  <td className={`whitespace-nowrap px-3 py-4 text-sm text-center transition-colors duration-300 rounded-md ${classA}`}>
                    {scoreA}
                  </td>
                  <td className={`whitespace-nowrap px-3 py-4 text-sm text-center transition-colors duration-300 rounded-md ${classB}`}>
                    {scoreB}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
       {activeStat && tooltipPosition && (
        <div
          id={tooltipId}
          role="tooltip"
          className="absolute p-2 text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-lg pointer-events-none w-56 z-10"
          style={{
            left: `${tooltipPosition.x}px`,
            top: `${tooltipPosition.y}px`,
            transform: 'translate(10px, -50%)', // Position to the right and vertically centered on the element
          }}
        >
          {STAT_EXPLANATIONS[activeStat]}
        </div>
      )}
    </div>
  );
};