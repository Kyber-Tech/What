import React, { useState, useRef } from 'react';
import type { ChartData, CharacterNumericalStats } from '../types';
import { STAT_EXPLANATIONS } from '../constants';

interface MatchupChartProps {
  data: ChartData;
  characterNames: { a: string; b: string };
}

export const MatchupChart: React.FC<MatchupChartProps> = ({ data, characterNames }) => {
  // State for managing active label and tooltip position for accessibility.
  const [activeLabel, setActiveLabel] = useState<keyof CharacterNumericalStats | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const tooltipId = 'matchup-chart-tooltip'; // Unique ID for ARIA

  const size = 320;
  const center = size / 2;
  const radius = size * 0.4;
  const { labels, charA, charB } = data;
  const numAxes = labels.length;
  const angleSlice = (Math.PI * 2) / numAxes;

  // Show tooltip on hover or focus, calculating position relative to the stat label element.
  const showTooltip = (event: React.MouseEvent | React.FocusEvent, label: keyof CharacterNumericalStats) => {
    if (!containerRef.current) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    const targetRect = (event.currentTarget as Element).getBoundingClientRect();
    
    // Position the tooltip to be centered above the stat label
    const x = targetRect.left + targetRect.width / 2 - containerRect.left;
    const y = targetRect.top - containerRect.top;

    setActiveLabel(label);
    setTooltipPosition({ x, y });
  };

  // Hide tooltip when the mouse leaves or the element loses focus.
  const hideTooltip = () => {
    setActiveLabel(null);
    setTooltipPosition(null);
  };

  const getPoint = (value: number, index: number) => {
    const angle = angleSlice * index - Math.PI / 2; // Subtract PI/2 to start at the top
    const scaledRadius = radius * (value / 100);
    return {
      x: center + scaledRadius * Math.cos(angle),
      y: center + scaledRadius * Math.sin(angle),
    };
  };

  const charAPoints = labels.map((label, i) => getPoint(charA[label], i));
  const charBPoints = labels.map((label, i) => getPoint(charB[label], i));

  const pointsToString = (points: { x: number; y: number }[]) => {
    return points.map(p => `${p.x},${p.y}`).join(' ');
  };

  const axisLabels = labels.map((label, i) => {
    const angle = angleSlice * i - Math.PI / 2;
    const point = getPoint(115, i); // Place labels just outside the chart

    let textAnchor: 'middle' | 'start' | 'end' = 'middle';
     // Use a small epsilon for floating point comparison
    if (Math.cos(angle) > 0.01) {
      textAnchor = 'start'; // Right hemisphere
    } else if (Math.cos(angle) < -0.01) {
      textAnchor = 'end'; // Left hemisphere
    }
    
    return (
      <text
        key={label}
        x={point.x}
        y={point.y}
        dy=".3em"
        textAnchor={textAnchor}
        className="text-xs fill-current text-gray-500 dark:text-gray-400 cursor-pointer hover:fill-gray-900 dark:hover:fill-white focus:fill-gray-900 dark:focus:fill-white focus:outline-none transition-colors"
        tabIndex={0}
        onMouseEnter={(e) => showTooltip(e, label)}
        onMouseLeave={hideTooltip}
        onFocus={(e) => showTooltip(e, label)}
        onBlur={hideTooltip}
        aria-describedby={activeLabel === label ? tooltipId : undefined}
      >
        {label}
      </text>
    );
  });

  const gridLevels = [25, 50, 75, 100];
  const chartTitleId = "matchup-chart-title";
  const charADescription = `Stats for ${characterNames.a}: ${labels.map(l => `${l} ${charA[l]}`).join(', ')}.`;
  const charBDescription = `Stats for ${characterNames.b}: ${labels.map(l => `${l} ${charB[l]}`).join(', ')}.`;

  return (
    <div ref={containerRef} className="relative mb-8 p-4 bg-gray-50/50 dark:bg-gray-900/50 rounded-lg">
      <h4 id={chartTitleId} className="text-lg font-semibold text-center mb-4 text-gray-800 dark:text-gray-200">Stat Comparison</h4>
      <div className="flex justify-center items-center">
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          role="img"
          aria-labelledby={chartTitleId}
        >
            <title>Radar chart comparing stats for {characterNames.a} and {characterNames.b}.</title>
            {/* Grid */}
            <g className="grid">
              {gridLevels.map(level => (
                <polygon
                  key={level}
                  points={pointsToString(labels.map((_, i) => getPoint(level, i)))}
                  className="fill-none stroke-gray-300 dark:stroke-gray-700"
                  strokeWidth="1"
                />
              ))}
            </g>
            {/* Axes */}
            <g className="axes">
              {labels.map((_, i) => (
                <line
                  key={i}
                  x1={center}
                  y1={center}
                  x2={getPoint(100, i).x}
                  y2={getPoint(100, i).y}
                  className="stroke-gray-300 dark:stroke-gray-700"
                  strokeWidth="1"
                />
              ))}
            </g>
            
            {/* Data Polygons - Animated */}
            <g className="data" style={{ transformOrigin: `${center}px ${center}px`, animation: 'scaleUp 0.5s ease-out forwards' }} role="list">
              <g role="listitem">
                <polygon
                  aria-label={charADescription}
                  points={pointsToString(charAPoints)}
                  className="fill-indigo-500/50 stroke-indigo-400"
                  strokeWidth="2"
                />
              </g>
              <g role="listitem">
                <polygon
                  aria-label={charBDescription}
                  points={pointsToString(charBPoints)}
                  className="fill-purple-500/50 stroke-purple-400"
                  strokeWidth="2"
                />
              </g>
            </g>
             {/* Labels */}
            <g className="labels">{axisLabels}</g>
        </svg>
      </div>
      {/* Tooltip element that appears on hover */}
      {activeLabel && tooltipPosition && (
        <div
          id={tooltipId}
          role="tooltip"
          className="absolute p-2 text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-lg pointer-events-none w-56 z-10"
          style={{
            left: `${tooltipPosition.x}px`,
            top: `${tooltipPosition.y}px`,
            transform: 'translate(-50%, -110%)', // Center and position above the element
          }}
        >
          {STAT_EXPLANATIONS[activeLabel]}
        </div>
      )}
      <div className="flex justify-center space-x-6 mt-4 text-sm">
        <div className="flex items-center">
            <span className="w-4 h-4 rounded-full bg-indigo-500 mr-2 border border-indigo-400"></span>
            <span>{characterNames.a || 'Character One'}</span>
        </div>
        <div className="flex items-center">
            <span className="w-4 h-4 rounded-full bg-purple-500 mr-2 border border-purple-400"></span>
            <span>{characterNames.b || 'Character Two'}</span>
        </div>
      </div>
       <style>{`
        @keyframes scaleUp {
          from { transform: scale(0); }
          to { transform: scale(1); }
        }
      `}</style>
    </div>
  );
};