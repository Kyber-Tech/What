
import React, { useState } from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import { MatchupChart } from './MatchupChart';
import { DebateZone } from './DebateZone';
import type { ChartData, Message } from '../types';
import { StatComparisonTable } from './StatComparisonTable';
import { TierDisplay } from './TierDisplay';
import { SpeedAnalysis } from './SpeedAnalysis';
import { ShareIcon } from './ShareIcon';
import { MarkdownRenderer } from './MarkdownRenderer';

const CheckIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

interface AnalysisResultProps {
  result: string | null;
  isLoading: boolean;
  error: string | null;
  chartData: ChartData | null;
  characterNames: {a: string, b: string};
  conversation: Message[];
  isReplying: boolean;
  onSendMessage: (message: string) => void;
  shareableLink: string | null;
}

const ResultSkeleton: React.FC = () => (
  <div className="animate-pulse space-y-4">
    <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-1/4"></div>
    <div className="space-y-2">
      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full"></div>
      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-5/6"></div>
      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full"></div>
    </div>
    <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-1/3 mt-6"></div>
    <div className="space-y-2">
      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full"></div>
      <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-3/4"></div>
    </div>
  </div>
);

export const AnalysisResult: React.FC<AnalysisResultProps> = ({
  result,
  isLoading,
  error,
  chartData,
  characterNames,
  conversation,
  isReplying,
  onSendMessage,
  shareableLink
}) => {
  const [copySuccess, setCopySuccess] = useState(false);

  const handleShare = () => {
    if (shareableLink) {
      navigator.clipboard.writeText(shareableLink).then(() => {
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
      }, (err) => {
        console.error('Failed to copy share link: ', err);
      });
    }
  };

  if (!result && !isLoading && !error) {
    return null;
  }

  return (
    <div id="verdict-section" className="mt-12 max-w-4xl mx-auto">
      <div className="bg-gray-50 dark:bg-gray-800/50 p-6 sm:p-8 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700">
        <h2 className="text-3xl font-extrabold text-center mb-8 text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-600 dark:from-indigo-400 dark:to-purple-500">
          The Verdict
        </h2>
        {isLoading && (
          <div className="flex flex-col items-center justify-center min-h-[300px]">
            <LoadingSpinner />
            <p className="mt-4 text-lg font-medium text-gray-600 dark:text-gray-400">The AI is analyzing the matchup...</p>
            <p className="text-sm text-gray-500 dark:text-gray-500">This can take a moment, especially with the Heavy Reasoning model.</p>
          </div>
        )}
        {error && (
          <div className="text-center text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-900/50 p-4 rounded-md border border-red-300 dark:border-red-600">
            <h3 className="font-bold text-lg">An Error Occurred</h3>
            <p className="mt-2">{error}</p>
          </div>
        )}
        {result && !isLoading && (
          <div className="animate-fadeIn">
            {chartData && (
              <>
                <TierDisplay characterNames={characterNames} data={chartData}/>
                <SpeedAnalysis data={chartData} characterNames={characterNames} />
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 items-start">
                  <MatchupChart data={chartData} characterNames={characterNames} />
                  <StatComparisonTable data={chartData} characterNames={characterNames} />
                </div>
              </>
            )}
            <div className="mt-8 pt-6 border-t border-gray-300 dark:border-gray-700">
              <MarkdownRenderer text={result} className="prose dark:prose-invert max-w-none text-gray-700 dark:text-gray-300" />
            </div>
             {shareableLink && (
              <div className="mt-8 text-center">
                <button
                  onClick={handleShare}
                  className="inline-flex items-center px-6 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 focus:ring-green-500 transition-all duration-200 transform active:scale-95"
                >
                  {copySuccess ? (
                    <>
                      <CheckIcon className="-ml-1 mr-2 h-5 w-5" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <ShareIcon className="-ml-1 mr-2 h-5 w-5" />
                      Share Battle
                    </>
                  )}
                </button>
              </div>
            )}
            <DebateZone conversation={conversation} isReplying={isReplying} onSendMessage={onSendMessage} />
          </div>
        )}
      </div>
    </div>
  );
};
