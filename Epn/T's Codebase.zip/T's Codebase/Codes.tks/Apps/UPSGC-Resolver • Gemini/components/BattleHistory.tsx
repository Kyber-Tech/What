import React, { useState } from 'react';
import type { Battle } from '../types';

const ChevronDownIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
    </svg>
);

interface BattleHistoryProps {
  history: Battle[];
  onSelect: (battle: Battle) => void;
  onClear: () => void;
}

export const BattleHistory: React.FC<BattleHistoryProps> = ({ history, onSelect, onClear }) => {
  const [isOpen, setIsOpen] = useState(false);

  const getCharacterDisplayName = (character: Battle['characterA']) => {
    return character.version ? `${character.name} (${character.version})` : character.name;
  };

  return (
    <div className="mt-8 max-w-4xl mx-auto bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-200 dark:border-gray-700">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left font-semibold text-lg text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors"
        aria-expanded={isOpen}
        aria-controls="battle-history-content"
      >
        <span>Battle History</span>
        <ChevronDownIcon className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div id="battle-history-content" className="p-4 border-t border-gray-200 dark:border-gray-700 animate-fadeIn">
          {history.length === 0 ? (
            <p className="text-gray-500 dark:text-gray-400 text-center py-4">No battles have been recorded yet.</p>
          ) : (
            <>
              <ul className="space-y-2 max-h-96 overflow-y-auto pr-2">
                {history.map((battle) => (
                  <li key={battle.id}>
                    <button
                      onClick={() => onSelect(battle)}
                      className="w-full text-left p-3 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700/50 focus:bg-gray-200 dark:focus:bg-gray-700 focus:outline-none transition-colors"
                    >
                      <p className="font-semibold text-indigo-600 dark:text-indigo-400 truncate">
                        {getCharacterDisplayName(battle.characterA)} vs {getCharacterDisplayName(battle.characterB)}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 truncate">
                        {battle.summary || `Analyzed on ${new Date(battle.timestamp).toLocaleString()}`}
                      </p>
                    </button>
                  </li>
                ))}
              </ul>
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 text-right">
                <button
                  onClick={onClear}
                  className="px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 focus:ring-red-500"
                >
                  Clear History
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};