
import React from 'react';
import type { ChartData } from '../types';

interface TierDisplayProps {
  characterNames: { a: string; b: string };
  data: ChartData;
}

const CrownIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className || "w-5 h-5"}>
        <path fillRule="evenodd" d="M11.23 3.633c.34-.386.92-.386 1.26 0l1.171 1.336c.703.8 1.844.8 2.548 0l1.17-1.336a.881.881 0 0 1 1.26 0l.294.333a.881.881 0 0 1 0 1.252l-1.17 1.336c-.704.8-1.845.8-2.548 0l-1.17-1.336a.881.881 0 0 1 0-1.252l.293-.333ZM6.505 5.234c.34-.386.92-.386 1.26 0l1.171 1.336c.703.8 1.844.8 2.548 0L12.654 5.234a.881.881 0 0 1 1.26 0l.294.333a.881.881 0 0 1 0 1.252l-1.17 1.336c-.704.8-1.845.8-2.548 0L9.32 6.82a.881.881 0 0 1 0-1.252l.293-.333a.881.881 0 0 1 1.26 0l-.001-.001ZM2.77 5.234a.881.881 0 0 1 1.26 0l1.171 1.336c.703.8 1.844.8 2.548 0L8.92 5.234a.881.881 0 0 1 1.26 0l.294.333a.881.881 0 0 1 0 1.252l-1.17 1.336c-.704.8-1.845.8-2.548 0L5.618 6.82a.881.881 0 0 1 0-1.252l.293-.333a.881.881 0 0 1 .53-.223Z" clipRule="evenodd" />
        <path d="M2 9.5a.75.75 0 0 1 .75-.75h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 9.5Z" />
        <path d="M4 11.25a.75.75 0 0 1 .75-.75h10.5a.75.75 0 0 1 0 1.5H4.75a.75.75 0 0 1-.75-.75Z" />
        <path fillRule="evenodd" d="M3.75 13a.75.75 0 0 1 .75-.75h11a.75.75 0 0 1 .75.75v3.19l-5.22-1.63a.75.75 0 0 0-.56 0L4.5 16.19V13a.75.75 0 0 1-.75-.75Z" clipRule="evenodd" />
    </svg>
);

const BrainIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-5 h-5"}>
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/>
    </svg>
);

const ShieldIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-5 h-5"}>
        <path fillRule="evenodd" d="M12.516 2.17a.75.75 0 0 0-1.032 0 11.209 11.209 0 0 1-7.877 3.08.75.75 0 0 0-.722.515A12.74 12.74 0 0 0 2.25 9.75c0 5.942 4.064 10.933 9.563 12.348a.749.749 0 0 0 .374 0c5.499-1.415 9.563-6.406 9.563-12.348 0-1.352-.272-2.636-.759-3.804a.75.75 0 0 0-.773-.422 11.217 11.217 0 0 1-7.703-3.354Z" clipRule="evenodd" />
    </svg>
);

const CubeIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-5 h-5"}>
        <path d="M12.378 1.602a.75.75 0 0 0-.756 0L3 6.632l9 5.25 9-5.25-8.622-5.03ZM21.75 7.93l-9 5.25v9l8.628-5.032a.75.75 0 0 0 .372-.648V7.93ZM11.25 22.18v-9l-9-5.25v8.57a.75.75 0 0 0 .372.648l8.628 5.033Z" />
    </svg>
);


// Helper function to extract the numerical value from a tier string
const getTierNumber = (tierString?: string): number | null => {
    if (!tierString) return null;
    const match = tierString.match(/Tier (\d+(\.\d+)?)/);
    return match ? parseFloat(match[1]) : null;
};

// Rank mapping for MPS Tiers (7 is highest)
const MPS_RANKS: Record<string, number> = {
    'absolute': 7,
    'strong': 6,
    'high': 5,
    'moderate': 4,
    'low': 3,
    'weak': 2,
    'non-existent': 1,
    'nonexistent': 1
};

const getMpsRank = (mpsTier?: string): number => {
    if (!mpsTier) return 0;
    const key = mpsTier.toLowerCase();
    for (const rank in MPS_RANKS) {
        if (key.includes(rank)) return MPS_RANKS[rank];
    }
    return 0;
};

export const TierDisplay: React.FC<TierDisplayProps> = ({ characterNames, data }) => {
    const { charA, charB } = data;
    
    // Power Tier Logic
    const tierNumA = getTierNumber(charA.tier);
    const tierNumB = getTierNumber(charB.tier);
    const hasPowerAdvantageA = tierNumA !== null && tierNumB !== null && tierNumA > tierNumB;
    const hasPowerAdvantageB = tierNumA !== null && tierNumB !== null && tierNumB > tierNumA;

    // MPS Tier Logic
    const mpsRankA = getMpsRank(charA.mpsTier);
    const mpsRankB = getMpsRank(charB.mpsTier);
    const hasMpsAdvantageA = mpsRankA > mpsRankB;
    const hasMpsAdvantageB = mpsRankB > mpsRankA;

    // Immunity Level Logic
    const immunityA = charA.immunityLevel || 0;
    const immunityB = charB.immunityLevel || 0;
    const hasImmunityAdvantageA = immunityA > immunityB;
    const hasImmunityAdvantageB = immunityB > immunityA;


    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {/* Power Tier Card */}
            <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg text-center border border-gray-200 dark:border-gray-700">
                <h3 className="text-sm font-bold text-gray-800 dark:text-gray-200 mb-4 flex items-center justify-center uppercase tracking-wider">
                    <CrownIcon className="w-5 h-5 mr-1 text-yellow-500"/>
                    Power Tier
                </h3>
                <div className="space-y-4">
                     <div className={`p-2 bg-white dark:bg-gray-800 rounded-lg ${hasPowerAdvantageA ? 'ring-2 ring-yellow-400 dark:ring-yellow-500' : ''}`}>
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.a}</p>
                         <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 leading-tight">{charA.tier}</p>
                     </div>
                     <div className={`p-2 bg-white dark:bg-gray-800 rounded-lg ${hasPowerAdvantageB ? 'ring-2 ring-yellow-400 dark:ring-yellow-500' : ''}`}>
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.b}</p>
                         <p className="text-sm font-semibold text-purple-600 dark:text-purple-400 leading-tight">{charB.tier}</p>
                     </div>
                </div>
            </div>

             {/* Immunity Tier Card */}
             <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg text-center border border-gray-200 dark:border-gray-700">
                <h3 className="text-sm font-bold text-gray-800 dark:text-gray-200 mb-4 flex items-center justify-center uppercase tracking-wider">
                    <ShieldIcon className="w-5 h-5 mr-1 text-green-500"/>
                    Immunity Hax
                </h3>
                <div className="space-y-4">
                     <div className={`p-2 bg-white dark:bg-gray-800 rounded-lg ${hasImmunityAdvantageA ? 'ring-2 ring-green-400 dark:ring-green-500' : ''}`}>
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.a}</p>
                         <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 leading-tight">Level {charA.immunityLevel}</p>
                     </div>
                     <div className={`p-2 bg-white dark:bg-gray-800 rounded-lg ${hasImmunityAdvantageB ? 'ring-2 ring-green-400 dark:ring-green-500' : ''}`}>
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.b}</p>
                         <p className="text-sm font-semibold text-purple-600 dark:text-purple-400 leading-tight">Level {charB.immunityLevel}</p>
                     </div>
                </div>
            </div>

            {/* Dimensionality Card */}
             <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg text-center border border-gray-200 dark:border-gray-700">
                <h3 className="text-sm font-bold text-gray-800 dark:text-gray-200 mb-4 flex items-center justify-center uppercase tracking-wider">
                    <CubeIcon className="w-5 h-5 mr-1 text-red-500"/>
                    Dimensionality
                </h3>
                <div className="space-y-4">
                     <div className="p-2 bg-white dark:bg-gray-800 rounded-lg">
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.a}</p>
                         <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 leading-tight capitalize">{charA.dimensionality || 'Unknown'}</p>
                     </div>
                     <div className="p-2 bg-white dark:bg-gray-800 rounded-lg">
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.b}</p>
                         <p className="text-sm font-semibold text-purple-600 dark:text-purple-400 leading-tight capitalize">{charB.dimensionality || 'Unknown'}</p>
                     </div>
                </div>
            </div>

            {/* MPS Tier Card */}
            <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg text-center border border-gray-200 dark:border-gray-700">
                <h3 className="text-sm font-bold text-gray-800 dark:text-gray-200 mb-4 flex items-center justify-center uppercase tracking-wider">
                    <BrainIcon className="w-5 h-5 mr-1 text-blue-500"/>
                    Mental State
                </h3>
                <div className="space-y-4">
                     <div className={`p-2 bg-white dark:bg-gray-800 rounded-lg ${hasMpsAdvantageA ? 'ring-2 ring-blue-400 dark:ring-blue-500' : ''}`}>
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.a}</p>
                         <p className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 leading-tight">{charA.mpsTier || 'N/A'}</p>
                     </div>
                     <div className={`p-2 bg-white dark:bg-gray-800 rounded-lg ${hasMpsAdvantageB ? 'ring-2 ring-blue-400 dark:ring-blue-500' : ''}`}>
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide mb-1 truncate">{characterNames.b}</p>
                         <p className="text-sm font-semibold text-purple-600 dark:text-purple-400 leading-tight">{charB.mpsTier || 'N/A'}</p>
                     </div>
                </div>
            </div>
        </div>
    );
};
