
import React from 'react';

// This function will handle inline markdown like **bold**, *italic*
const processInlineMarkdown = (text: string): React.ReactNode => {
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g).filter(Boolean); // filter out empty strings
    return <>{parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={index}>{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={index}>{part.slice(1, -1)}</em>;
      }
      return part;
    })}</>;
};

export const MarkdownRenderer: React.FC<{ text: string, className?: string }> = ({ text, className }) => {
  const elements: React.ReactNode[] = [];
  const blocks = text.split(/\n\s*\n/).filter(block => block.trim() !== '');

  blocks.forEach((block, index) => {
    const trimmedBlock = block.trim();
    const lines = trimmedBlock.split('\n').map(l => l.trim());

    if (trimmedBlock.startsWith('### ')) {
      elements.push(<h3 key={index} className="font-bold text-xl mt-6 mb-2 text-purple-600 dark:text-purple-400">{processInlineMarkdown(trimmedBlock.substring(4))}</h3>);
    } else if (trimmedBlock.startsWith('## ')) {
      elements.push(<h2 key={index} className="font-bold text-2xl mt-8 mb-4 text-purple-600 dark:text-purple-400">{processInlineMarkdown(trimmedBlock.substring(3))}</h2>);
    } else if (trimmedBlock.startsWith('# ')) {
        elements.push(<h1 key={index} className="font-bold text-3xl mt-8 mb-4 text-purple-600 dark:text-purple-400">{processInlineMarkdown(trimmedBlock.substring(2))}</h1>);
    } else if (trimmedBlock.startsWith('#### ')) {
        elements.push(<h4 key={index} className="font-bold text-lg mt-5 mb-2">{processInlineMarkdown(trimmedBlock.substring(5))}</h4>);
    } else if (lines.length >= 2 && lines[1].match(/^[:\-\s|]+$/) && lines[0].includes('|')) {
        // Table parsing logic
        const headersRaw = lines[0].split('|').map(s => s.trim());
        const headers = headersRaw.slice(1, headersRaw.length - 1);
        
        const rows = lines.slice(2).map(line => {
            const cellsRaw = line.split('|').map(s => s.trim());
            return cellsRaw.slice(1, cellsRaw.length - 1);
        });

        elements.push(
            <div key={index} className="overflow-x-auto my-4 rounded-lg border border-gray-300 dark:border-gray-700 not-prose">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
                    <thead className="bg-gray-100 dark:bg-gray-800">
                        <tr>
                            {headers.map((header, i) => (
                                <th key={i} scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    {processInlineMarkdown(header)}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-900/50 divide-y divide-gray-200 dark:divide-gray-600">
                        {rows.map((row, rowIndex) => (
                            <tr key={rowIndex} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                                {row.map((cell, cellIndex) => (
                                    <td key={cellIndex} className="px-4 py-3 text-sm text-gray-700 dark:text-gray-300">
                                        {processInlineMarkdown(cell)}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    } else if (trimmedBlock.split('\n').every(line => line.trim().startsWith('* ') || line.trim().startsWith('- '))) {
      const listItems = trimmedBlock.split('\n').map(item => item.trim().replace(/^[\*\-]\s/, ''));
      elements.push(
        <ul key={index} className="list-disc pl-5 space-y-2 my-4">
          {listItems.map((item, i) => <li key={i}>{processInlineMarkdown(item)}</li>)}
        </ul>
      );
    } else if (trimmedBlock.split('\n').every(line => line.trim().match(/^\d+\.\s/))) {
      const listItems = trimmedBlock.split('\n').map(item => item.trim().replace(/^\d+\.\s/, ''));
      elements.push(
        <ol key={index} className="list-decimal pl-5 space-y-2 my-4">
          {listItems.map((item, i) => <li key={i}>{processInlineMarkdown(item)}</li>)}
        </ol>
      );
    } else {
      // Normal paragraph. Replace internal newlines with spaces.
      elements.push(<p key={index}>{processInlineMarkdown(trimmedBlock.replace(/\n/g, ' '))}</p>);
    }
  });

  return (
    <div className={className}>
      {elements.map((el, i) => <React.Fragment key={i}>{el}</React.Fragment>)}
    </div>
  );
};