
import React from 'react';
import type { ChartData } from '../types';

interface SpeedAnalysisProps {
  data: ChartData;
  characterNames: { a: string; b: string };
}

const LightningIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-6 h-6"}>
        <path fillRule="evenodd" d="M14.615 1.595a.75.75 0 0 1 .359.852L12.982 9.75h7.268a.75.75 0 0 1 .548 1.262l-10.5 11.25a.75.75 0 0 1-1.272-.71l1.992-7.302H3.75a.75.75 0 0 1-.548-1.262l10.5-11.25a.75.75 0 0 1 .913-.143Z" clipRule="evenodd" />
    </svg>
);

const SpeedBar: React.FC<{ label: string; valA: number; valB: number; nameA: string; nameB: string }> = ({ label, valA, valB, nameA, nameB }) => {
    const max = 100;
    const widthA = Math.min((valA / max) * 100, 100);
    const widthB = Math.min((valB / max) * 100, 100);

    return (
        <div className="mb-4">
            <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
            </div>
            <div className="relative h-6 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden flex">
                <div 
                    className="h-full bg-indigo-500 flex items-center justify-center text-xs text-white font-bold transition-all duration-500" 
                    style={{ width: `${widthA}%` }}
                    title={`${nameA}: ${valA}`}
                >
                    {widthA > 10 && valA}
                </div>
                <div className="w-1 bg-white dark:bg-gray-900 z-10"></div>
                 <div 
                    className="h-full bg-purple-500 flex items-center justify-center text-xs text-white font-bold transition-all duration-500" 
                    style={{ width: `${widthB}%` }}
                    title={`${nameB}: ${valB}`}
                >
                    {widthB > 10 && valB}
                </div>
            </div>
             <div className="flex justify-between text-xs mt-1 text-gray-500">
                <span className="text-indigo-600 dark:text-indigo-400">{nameA} ({valA})</span>
                <span className="text-purple-600 dark:text-purple-400">{nameB} ({valB})</span>
            </div>
        </div>
    );
};

export const SpeedAnalysis: React.FC<SpeedAnalysisProps> = ({ data, characterNames }) => {
    const { charA, charB } = data;
    
    // Blitzsieg Threshold: A significant gap in Reaction Speed (e.g., >15 points on a 100 scale implies a tier jump)
    const reactionDiff = charA['Reaction Speed'] - charB['Reaction Speed'];
    const BLITZ_THRESHOLD = 15;
    
    let blitzMessage = null;
    let blitzWinner = null;

    if (reactionDiff > BLITZ_THRESHOLD) {
        blitzWinner = characterNames.a;
        blitzMessage = `${characterNames.a} has a decisive Reaction Speed advantage. According to UPSGC rules, this likely results in a "Blitzsieg," preventing ${characterNames.b} from activating proactive abilities.`;
    } else if (reactionDiff < -BLITZ_THRESHOLD) {
        blitzWinner = characterNames.b;
        blitzMessage = `${characterNames.b} has a decisive Reaction Speed advantage. According to UPSGC rules, this likely results in a "Blitzsieg," preventing ${characterNames.a} from activating proactive abilities.`;
    }

    return (
        <div className="mb-8 p-6 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700">
            <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-6 flex items-center">
                <LightningIcon className="w-6 h-6 mr-2 text-yellow-500" />
                Speed Dynamics (RT/SPD)
            </h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                    <SpeedBar 
                        label="Travel Speed (SPD)" 
                        valA={charA['Travel Speed']} 
                        valB={charB['Travel Speed']} 
                        nameA={characterNames.a} 
                        nameB={characterNames.b} 
                    />
                     <SpeedBar 
                        label="Reaction Speed (RT)" 
                        valA={charA['Reaction Speed']} 
                        valB={charB['Reaction Speed']} 
                        nameA={characterNames.a} 
                        nameB={characterNames.b} 
                    />
                     <SpeedBar 
                        label="Combat Speed (CSPD)" 
                        valA={charA['Combat Speed']} 
                        valB={charB['Combat Speed']} 
                        nameA={characterNames.a} 
                        nameB={characterNames.b} 
                    />
                </div>

                <div className="flex flex-col justify-center">
                    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                        <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Analysis</h4>
                        {blitzMessage ? (
                            <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 border-l-4 border-yellow-500 text-yellow-800 dark:text-yellow-200 text-sm">
                                <strong>⚡ Blitzsieg Alert:</strong> {blitzMessage}
                            </div>
                        ) : (
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                                Reaction speeds are comparable. Neither combatant holds a distinct "Blitzsieg" advantage, meaning both can likely utilize their Hax and abilities proactively.
                            </p>
                        )}
                         <div className="mt-4 text-xs text-gray-500 dark:text-gray-500">
                            * Travel Speed determines map control.<br/>
                            * Reaction Speed determines initiative and Hax activation.<br/>
                            * Combat Speed determines melee exchange dominance.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
