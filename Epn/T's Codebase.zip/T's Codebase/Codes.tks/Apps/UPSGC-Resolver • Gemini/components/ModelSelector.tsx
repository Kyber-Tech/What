import React from 'react';
import { FAST_MODEL, BALANCED_MODEL, HEAVY_MODEL } from '../constants';

interface ModelSelectorProps {
  selectedModel: string;
  onModelChange: (model: string) => void;
}

const models = [
  { id: BALANCED_MODEL, name: 'Balanced', description: 'Good speed and reasoning. (Default)' },
  { id: FAST_MODEL, name: 'Fast Output', description: 'Quickest results, lighter analysis.' },
  { id: HEAVY_MODEL, name: 'Heavy Reasoning', description: 'Deeper analysis, may take longer.' }
];

export const ModelSelector: React.FC<ModelSelectorProps> = ({ selectedModel, onModelChange }) => {
  return (
    <div className="mb-8 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-200 dark:border-gray-700">
      <h3 className="text-lg font-semibold text-center text-gray-800 dark:text-gray-200 mb-4">Analysis Model</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {models.map((model) => {
          const isSelected = selectedModel === model.id;
          return (
            <button
              key={model.id}
              onClick={() => onModelChange(model.id)}
              className={`p-4 rounded-lg text-left transition-all duration-200 transform hover:-translate-y-1 ${
                isSelected
                  ? 'bg-indigo-600 border-2 border-indigo-400 shadow-lg text-white'
                  : 'bg-gray-200 dark:bg-gray-700/50 hover:bg-gray-300 dark:hover:bg-gray-700 border-2 border-transparent'
              }`}
              aria-pressed={isSelected}
            >
              <p className={`font-bold ${isSelected ? 'text-white' : 'text-gray-900 dark:text-white'}`}>{model.name}</p>
              <p className={`text-sm  mt-1 ${isSelected ? 'text-indigo-100' : 'text-gray-600 dark:text-gray-300'}`}>{model.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
};