import React from 'react';
import { ThemeToggle } from './ThemeToggle';

interface HeaderProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({ theme, toggleTheme }) => {
  return (
    <header className="text-center relative">
       <div className="absolute top-0 right-0 z-10">
        <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
      </div>
      <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-purple-600 dark:from-indigo-400 dark:to-purple-500">
        UPSGC-Resolver • Gemini
      </h1>
      <p className="mt-4 max-w-2xl mx-auto text-lg text-gray-600 dark:text-gray-400">
        Powered by the Unified Power-Scaling System. Enter two combatants and their feats to receive an unbiased, rule-based verdict.
      </p>
    </header>
  );
};
