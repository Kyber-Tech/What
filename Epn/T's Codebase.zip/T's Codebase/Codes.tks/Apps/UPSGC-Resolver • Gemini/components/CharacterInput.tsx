
import React, { useState } from 'react';
import type { Character } from '../types';
import { getCharacterFeats, getCharacterVersions } from '../services/geminiService';

interface CharacterInputProps {
  title: string;
  character: Character;
  setCharacter: React.Dispatch<React.SetStateAction<Character>>;
  isLuckySelecting?: boolean;
}

const SuggestVersionsIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-4 h-4"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456Z" />
  </svg>
);


export const CharacterInput: React.FC<CharacterInputProps> = ({ title, character, setCharacter, isLuckySelecting }) => {
  const [isFetchingFeats, setIsFetchingFeats] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [isFetchingVersions, setIsFetchingVersions] = useState(false);
  const [versions, setVersions] = useState<string[]>([]);

  const handleInputChange = (field: keyof Character) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setCharacter(c => ({ ...c, [field]: e.target.value }));
  };
  
  const handleSuggestVersions = async () => {
    if (!character.name || !character.origin) return;
    setIsFetchingVersions(true);
    setFetchError(null);
    try {
      const fetchedVersions = await getCharacterVersions(character.name, character.origin);
      setVersions(fetchedVersions);
    } catch (err) {
      setFetchError(err instanceof Error ? err.message : 'Failed to fetch versions.');
    } finally {
      setIsFetchingVersions(false);
    }
  };

  const handleAutoFill = async () => {
    if (!character.name || !character.origin) return;

    setIsFetchingFeats(true);
    setFetchError(null);

    try {
      const feats = await getCharacterFeats(character.name, character.origin, character.version);
      setCharacter(c => ({ ...c, feats: feats }));
    } catch (err) {
      setFetchError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsFetchingFeats(false);
    }
  };

  const canSuggestVersions = character.name && character.origin && !isFetchingVersions;
  const canAutoFill = character.name && character.origin && !isFetchingFeats;

  return (
    <div className={`bg-gray-50 dark:bg-gray-800/50 p-6 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transition-all duration-300 ${isLuckySelecting ? 'ring-2 ring-purple-500 ring-offset-2 ring-offset-gray-100 dark:ring-offset-gray-900 animate-pulse' : ''}`}>
      <h2 className="text-2xl font-bold text-center mb-4 text-indigo-600 dark:text-indigo-400">{title}</h2>
      
      {isLuckySelecting ? (
        <div className="h-[148px] flex flex-col items-center justify-center text-center overflow-hidden">
            <div key={character.name} className="animate-roulette-cycle text-2xl font-bold text-indigo-600 dark:text-indigo-400">
                {character.name || '...'}
            </div>
            <div key={character.origin} className="animate-roulette-cycle-delayed text-lg text-gray-600 dark:text-gray-500">
                {character.origin || '...'}
            </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <label htmlFor={`name-${title}`} className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Character Name
            </label>
            <input
              type="text"
              id={`name-${title}`}
              value={character.name}
              onChange={handleInputChange('name')}
              placeholder="e.g., Superman"
              className="mt-1 block w-full bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
            <div>
              <label htmlFor={`origin-${title}`} className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Origin / Series
              </label>
              <input
                type="text"
                id={`origin-${title}`}
                value={character.origin}
                onChange={handleInputChange('origin')}
                placeholder="e.g., DC Comics"
                className="mt-1 block w-full bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>

            <div>
              <label htmlFor={`dimensionality-${title}`} className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Dimensionality
              </label>
              <select
                id={`dimensionality-${title}`}
                value={character.dimensionality || ''}
                onChange={handleInputChange('dimensionality')}
                className="mt-1 block w-full bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              >
                <option value="">Let AI Decide</option>
                <option value="mono">Mono-Dimensionality</option>
                <option value="poly">Poly-Dimensionality</option>
                <option value="meta">Meta-Dimensionality</option>
              </select>
            </div>

            <div>
              <label htmlFor={`version-${title}`} className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Version / Era (Optional)
              </label>
              <div className="flex items-center space-x-2 mt-1">
                <input
                  type="text"
                  id={`version-${title}`}
                  list={`versions-list-${title}`}
                  value={character.version || ''}
                  onChange={handleInputChange('version')}
                  placeholder="e.g., Post-Crisis"
                  className="block w-full bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
                {versions.length > 0 && (
                  <datalist id={`versions-list-${title}`}>
                    {versions.map(v => <option key={v} value={v} />)}
                  </datalist>
                )}
                <button
                  onClick={handleSuggestVersions}
                  disabled={!canSuggestVersions}
                  className="inline-flex items-center p-2 border border-transparent text-xs font-medium rounded-md shadow-sm text-gray-800 dark:text-white bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 disabled:bg-gray-400 dark:disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 focus:ring-gray-500"
                  aria-label={`Suggest versions for ${character.name}`}
                  title="Suggest versions with AI"
                >
                  {isFetchingVersions ? (
                    <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  ) : (
                    <SuggestVersionsIcon />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div>
        <div className="flex justify-between items-center mb-1">
          <label htmlFor={`feats-${title}`} className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Feats & Abilities (Optional)
          </label>
          <button
            onClick={handleAutoFill}
            disabled={!canAutoFill}
            className="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 focus:ring-purple-500 transition-all duration-200 transform active:scale-95"
            aria-label={`Research feats for ${character.name}`}
          >
            {isFetchingFeats ? (
              <>
                <svg className="animate-spin -ml-0.5 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Researching...
              </>
            ) : (
              'Research Feats'
            )}
          </button>
        </div>
        <textarea
          id={`feats-${title}`}
          value={character.feats}
          onChange={handleInputChange('feats')}
          rows={8}
          placeholder="Optionally, list key feats to guide the AI's research. The AI will perform its own research regardless."
          className="block w-full bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm resize-y"
          aria-describedby={fetchError ? `error-${title}` : undefined}
        />
        {fetchError && (
           <p id={`error-${title}`} className="mt-2 text-sm text-red-600 dark:text-red-400" role="alert">
             <strong>AI Error:</strong> {fetchError} Please enter data manually or check the character info and try again.
           </p>
        )}
      </div>
    </div>
  );
};