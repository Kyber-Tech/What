

import React, { useState, useEffect, useRef } from 'react';
import type { Message } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';

interface DebateZoneProps {
  conversation: Message[];
  isReplying: boolean;
  onSendMessage: (message: string) => void;
}

const SendIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-6 h-6"}>
        <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
    </svg>
);

const ThumbsDownIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10 15v4a3 3 0 0 0 3 3l5-10V2H8a2 2 0 0 0-2 2v7Z"></path>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 15v-5a2 2 0 0 1 2-2h2"></path>
  </svg>
);


export const DebateZone: React.FC<DebateZoneProps> = ({ conversation, isReplying, onSendMessage }) => {
  const [input, setInput] = useState('');
  const [dislikedMessages, setDislikedMessages] = useState<Set<number>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isReplying) {
      onSendMessage(input.trim());
      setInput('');
    }
  };
  
  const handleFeedback = (index: number, message: Message) => {
    setDislikedMessages(prev => new Set(prev).add(index));
    // In a real application, this would send feedback to a server.
    console.log(`'Dislike' feedback received for ${message.role} message at index ${index}:`, `"${message.content}"`);
  };

  if (conversation.length === 0) {
    return null;
  }
  
  return (
    <div className="mt-8 pt-6 border-t border-gray-300 dark:border-gray-700">
      <h3 className="text-2xl font-bold text-center mb-4 text-indigo-600 dark:text-indigo-400">Debate Zone</h3>
      <div className="bg-white dark:bg-gray-900/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700 max-h-[70vh] flex flex-col">
        <div className="flex-1 space-y-4 overflow-y-auto pr-2">
          {conversation.map((msg, index) => {
            const isDisliked = dislikedMessages.has(index);

            const feedbackButton = (
              // Don't show feedback button for the "thinking" bubble
              (msg.role === 'model' && msg.content === '' && isReplying) ? null : (
                <button
                  onClick={() => handleFeedback(index, msg)}
                  disabled={isDisliked}
                  className={`p-1.5 rounded-full text-gray-400 hover:text-red-600 hover:bg-gray-200 dark:hover:bg-gray-600 disabled:text-red-500 disabled:cursor-not-allowed transition-all duration-200 opacity-0 group-hover:opacity-100 focus:opacity-100 ${isDisliked ? 'opacity-100' : ''}`}
                  aria-label="Dislike this response"
                >
                  <ThumbsDownIcon className="h-4 w-4"/>
                </button>
              )
            );

            return (
              <div key={index} className={`group flex items-end gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'} ${index === conversation.length - 1 ? 'animate-slideUp' : ''}`}>
                {msg.role === 'model' && feedbackButton}
                <div className={`max-w-xl p-3 rounded-lg ${msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>
                  {(msg.role === 'model' && msg.content === '' && isReplying) ? (
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse delay-0"></span>
                      <span className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse delay-150"></span>
                      <span className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse delay-300"></span>
                    </div>
                  ) : (
                    <MarkdownRenderer text={msg.content} className="prose dark:prose-invert prose-sm max-w-none" />
                  )}
                </div>
                {msg.role === 'user' && feedbackButton}
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
        <form onSubmit={handleSubmit} className="mt-4 flex items-center space-x-2 border-t border-gray-200 dark:border-gray-700 pt-4">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
            placeholder="State your argument..."
            rows={1}
            className="flex-1 block w-full bg-gray-100 dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm resize-none"
            disabled={isReplying}
          />
          <button
            type="submit"
            disabled={!input.trim() || isReplying}
            className="inline-flex items-center justify-center p-2 border border-transparent rounded-full shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-gray-900 focus:ring-indigo-500 transition-colors"
            aria-label="Send message"
          >
            <SendIcon className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
