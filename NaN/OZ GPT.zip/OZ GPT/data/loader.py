import torch
import numpy as np
from torch.utils.data import Dataset

class MemoryMappedDataset(Dataset):
    """
    Demand-paging data loader. Ingests Terabytes of binary data with Zero RAM overhead.
    """
    def __init__(self, path, block_size):
        self.block_size = block_size
        self.data = np.memmap(path, dtype=np.uint8, mode='r')
        # Ensure data is divisible by block size for segment alignment
        self.effective_length = (len(self.data) - block_size - 1)

    def __len__(self):
        return self.effective_length

    def __getitem__(self, i):
        # Slicing is managed by OS kernel page cache
        chunk = self.data[i : i + self.block_size + 1]
        x = torch.from_numpy(chunk[:-1].astype(np.int64))
        y = torch.from_numpy(chunk[1:].astype(np.int64))
        return x, y