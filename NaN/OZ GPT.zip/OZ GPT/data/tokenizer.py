import os
import json
import torch
from typing import List, Dict, Tuple, Optional

class OZ_BPETokenizer:
    """
    Learned Byte Pair Encoding (BPE) implementation for OZ v2.8.1.
    Handles vocabulary construction, iterative pair merging, and state persistence.
    """
    def __init__(self, vocab_size: int = 50257):
        self.vocab_size = vocab_size
        # Initialize with base byte tokens (0-255)
        self.byte_encoder = {bytes([i]): i for i in range(256)}
        self.byte_decoder = {i: bytes([i]) for i in range(256)}
        
        self.vocab = self.byte_encoder.copy()
        self.merges: Dict[Tuple[int, int], int] = {}
        self.inverse_vocab: Dict[int, bytes] = self.byte_decoder.copy()
        
        # Special tokens
        self.eot_token = "<|endoftext|>"
        self._add_special_token(self.eot_token)

    def _add_special_token(self, token: str):
        token_bytes = token.encode('utf-8')
        if token_bytes not in self.vocab:
            token_id = len(self.vocab)
            self.vocab[token_bytes] = token_id
            self.inverse_vocab[token_id] = token_bytes

    def train(self, corpus_path: str, target_vocab_size: int):
        """
        Iterative training of BPE merges on a provided corpus.
        Algorithm: Frequency-based pair consolidation.
        """
        print(f"Initiating BPE training on {corpus_path}...")
        with open(corpus_path, "rb") as f:
            text = f.read()

        # Initial tokenization into bytes
        tokens = list(text)
        
        num_merges = target_vocab_size - len(self.vocab)
        for i in range(num_merges):
            stats = self._get_stats(tokens)
            if not stats:
                break
            
            # Select most frequent adjacent pair
            best_pair = max(stats, key=stats.get)
            new_token_id = len(self.vocab)
            
            # Update state
            new_token_bytes = self.inverse_vocab[best_pair[0]] + self.inverse_vocab[best_pair[1]]
            self.vocab[new_token_bytes] = new_token_id
            self.inverse_vocab[new_token_id] = new_token_bytes
            self.merges[best_pair] = new_token_id
            
            # Apply merge to training data
            tokens = self._merge_tokens(tokens, best_pair, new_token_id)
            
            if (i + 1) % 100 == 0:
                print(f"Merge {i+1}/{num_merges} completed. Current Vocab: {len(self.vocab)}")

        self.vocab_size = len(self.vocab)

    def _get_stats(self, tokens: List[int]) -> Dict[Tuple[int, int], int]:
        counts = {}
        for i in range(len(tokens) - 1):
            pair = (tokens[i], tokens[i+1])
            counts[pair] = counts.get(pair, 0) + 1
        return counts

    def _merge_tokens(self, tokens: List[int], pair: Tuple[int, int], new_id: int) -> List[int]:
        new_tokens = []
        i = 0
        while i < len(tokens):
            if i < len(tokens) - 1 and (tokens[i], tokens[i+1]) == pair:
                new_tokens.append(new_id)
                i += 2
            else:
                new_tokens.append(tokens[i])
                i += 1
        return new_tokens

    def encode(self, text: str) -> torch.Tensor:
        """
        Converts a string into a sequence of BPE token IDs.
        Utilizes pre-calculated merge rules.
        """
        tokens = list(text.encode('utf-8'))
        
        while len(tokens) >= 2:
            stats = self._get_stats(tokens)
            # Find which possible merge in the current text occurred earliest in the training process
            # (indicating it has the highest priority)
            pairs_to_merge = {pair: self.merges[pair] for pair in stats if pair in self.merges}
            
            if not pairs_to_merge:
                break
            
            # Priority defined by the order in self.merges
            best_pair = min(pairs_to_merge.keys(), key=lambda p: self.merges[p])
            tokens = self._merge_tokens(tokens, best_pair, self.merges[best_pair])
            
        return torch.tensor(tokens, dtype=torch.long)

    def decode(self, tokens: torch.Tensor) -> str:
        if isinstance(tokens, torch.Tensor):
            tokens = tokens.tolist()
            
        byte_segments = [self.inverse_vocab[t] for t in tokens]
        return b"".join(byte_segments).decode('utf-8', errors='replace')

    def save(self, path: str):
        """
        Serializes the BPE state (vocab and merges) to disk.
        Format: JSON for portability.
        """
        # Convert merges dict keys from tuples to strings for JSON compatibility
        serializable_merges = {f"{k[0]},{k[1]}": v for k, v in self.merges.items()}
        
        # Vocab keys are bytes; convert to hex strings for storage
        serializable_vocab = {k.hex(): v for k, v in self.vocab.items()}
        
        state = {
            "vocab_size": self.vocab_size,
            "vocab": serializable_vocab,
            "merges": serializable_merges
        }
        
        with open(path, "w") as f:
            json.dump(state, f, indent=4)
        print(f"BPE state synchronized to {path}.")

    def load(self, path: str):
        """
        Loads the BPE state from a serialized file.
        Restores the exact tokenization manifold used during training.
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"No BPE state found at {path}")
            
        with open(path, "r") as f:
            state = json.load(f)
            
        self.vocab_size = state["vocab_size"]
        
        # Restore vocab (hex -> bytes)
        self.vocab = {bytes.fromhex(k): v for k, v in state["vocab"].items()}
        self.inverse_vocab = {v: k for k, v in self.vocab.items()}
        
        # Restore merges (string -> tuple)
        self.merges = {}
        for k, v in state["merges"].items():
            p1, p2 = map(int, k.split(","))
            self.merges[(p1, p2)] = v
            
        print(f"BPE state restored from {path}. Vocab Size: {self.vocab_size}")