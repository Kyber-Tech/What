import torch
from core.math import bjorck_orthogonalization

class OZ_Trainer:
    def __init__(self, model, config, t_config, device):
        self.model = model
        self.cfg = config
        self.t_cfg = t_config
        self.device = device
        self.optimizer = torch.optim.AdamW(
            model.parameters(), 
            lr=t_config['learning_rate'], 
            weight_decay=t_config['weight_decay']
        )
        self.scaler = torch.cuda.amp.GradScaler(enabled=True)

    def train_step(self, x, y, accumulation_step):
        x, y = x.to(self.device), y.to(self.device)
        
        with torch.cuda.amp.autocast(dtype=torch.bfloat16):
            logits, loss = self.model(x, y)
        
        # Normalize loss for accumulation
        loss = loss / self.t_cfg['accumulation_steps']
        self.scaler.scale(loss).backward()
        
        if accumulation_step % self.t_cfg['accumulation_steps'] == 0:
            # Gradient clipping for ECS stability
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.optimizer.zero_grad(set_to_none=True)
            
        return loss.item() * self.t_cfg['accumulation_steps']