import torch
import os

class OZ_CheckpointManager:
    """
    Manages state persistence for the ECS engine.
    Ensures bfloat16 precision is preserved during I/O.
    """
    def __init__(self, checkpoint_dir: str = "checkpoints"):
        self.dir = checkpoint_dir
        os.makedirs(self.dir, exist_ok=True)

    def save(self, model, optimizer, step, loss, config):
        path = os.path.join(self.dir, f"oz_v280_step_{step}.pt")
        state = {
            "step": step,
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "loss": loss,
            "config": config
        }
        torch.save(state, path)
        print(f"Operational state archived at step {step}.")

    def load_latest(self, model, optimizer=None):
        files = [f for f in os.listdir(self.dir) if f.endswith(".pt")]
        if not files:
            return 0
        latest = max(files, key=lambda x: int(x.split("_")[-1].split(".")[0]))
        path = os.path.join(self.dir, latest)
        
        state = torch.load(path, map_location="cpu")
        model.load_state_dict(state["model_state"])
        if optimizer:
            optimizer.load_state_dict(state["optimizer_state"])
        return state["step"]