import torch
import math

@torch.jit.script
def parallel_associative_scan(A_elements: torch.Tensor, B_elements: torch.Tensor):
    """
    Parallel prefix sum for linear recurrences.
    Complexity: O(log T) steps on GPU.
    Equation: h_t = A_t * h_{t-1} + B_t
    """
    T = A_elements.size(1)
    num_steps = int(math.log2(T))
    A_star = A_elements.clone()
    B_star = B_elements.clone()
    
    for i in range(num_steps):
        step = 2**i
        # Indices for parallel updates
        A_curr = A_star[:, step:, :]
        B_curr = B_star[:, step:, :]
        A_prev = A_star[:, :-step, :]
        B_prev = B_star[:, :-step, :]
        
        # Associative composition
        # A_new = A_curr * A_prev
        # B_new = A_curr * B_prev + B_curr
        A_star[:, step:, :] = A_curr * A_prev
        B_star[:, step:, :] = torch.addcmul(B_curr, A_curr, B_prev)
        
    return B_star

def bjorck_orthogonalization(w: torch.Tensor, iters: int = 3):
    """
    Iterative manifold projection to enforce Stiefel isometry.
    Ensures singular values remain near 1.0.
    """
    # Normalize spectral radius
    w = w / (torch.linalg.matrix_norm(w, ord=2) + 1e-6)
    for _ in range(iters):
        w_wt_w = w @ w.transpose(-2, -1) @ w
        w = 1.5 * w - 0.5 * w_wt_w
    return w

def log_space_discretization(A_log: torch.Tensor, dt: torch.Tensor, B: torch.Tensor):
    """
    Numerically stable discretization of the SSM in log-space.
    Prevents exponent overflow across 500,000 steps.
    """
    A = -torch.exp(A_log)
    A_bar = torch.exp(A * dt)
    B_bar = ((A_bar - 1.0) / A) * B
    return A_bar, B_bar