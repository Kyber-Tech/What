import torch
import yaml
from core.model import OZ_v280
from data.tokenizer import OZ_Tokenizer

@torch.inference_mode()
def generate_response(prompt: str, max_new_tokens: int = 512):
    with open("configs/oz_v280_ultra.yaml", "r") as f:
        cfg = yaml.safe_load(f)['model_specification']

    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = OZ_Tokenizer()
    model = OZ_v280(cfg).to(device)
    model.eval()

    # Load weights (assuming latest checkpoint)
    # CheckpointManager.load_latest(model)

    idx = tokenizer.encode(prompt).unsqueeze(0).to(device)
    
    print(f"OZ Inference System: Sequence length {idx.size(1)} detected.")
    
    for _ in range(max_new_tokens):
        # In v2.8.0, for efficiency, we would only pass the last token 
        # plus the state-cache, but for this implementation we use block-pass
        logits, _ = model(idx[:, -cfg['block_size']:])
        
        # Sample with temperature scaling
        probs = torch.softmax(logits[:, -1, :] / 0.8, dim=-1)
        next_token = torch.multinomial(probs, num_samples=1)
        
        idx = torch.cat((idx, next_token), dim=1)
        
        # Stream output to console
        print(tokenizer.decode(next_token.squeeze()), end="", flush=True)

if __name__ == "__main__":
    prompt = "System Analysis Report: ECS v2.8.0 initialization..."
    generate_response(prompt)