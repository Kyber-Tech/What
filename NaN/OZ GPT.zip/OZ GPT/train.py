import os
import yaml
import torch
import argparse
from torch.utils.data import DataLoader

# Modular Omni-Z Components
from core.model import OZ_v280
from data.loader import MemoryMappedDataset
from data.tokenizer import OZ_BPETokenizer
from utils.trainer import OZ_Trainer
from utils.checkpoint import OZ_CheckpointManager

def parse_operational_parameters():
    """Defines the CLI interface for system deployment."""
    parser = argparse.ArgumentParser(description="Omni-Z v2.8.1 Training Orchestrator")
    parser.add_argument("--config", type=str, default="configs/oz_v280_ultra.yaml", help="Path to system blueprint.")
    parser.add_argument("--data", type=str, default="input.txt", help="Source corpus for training.")
    parser.add_argument("--tokenizer_path", type=str, default="configs/bpe_state.json", help="BPE state persistence path.")
    parser.add_argument("--resume", action="store_true", help="Resume from the latest manifold checkpoint.")
    return parser.parse_args()

def synchronize_tokenizer(args, config):
    """
    Initializes the BPE manifold. 
    If no state is detected, initiates a training cycle on the source corpus.
    """
    tokenizer = OZ_BPETokenizer(vocab_size=config['model_specification']['vocab_size'])
    
    if os.path.exists(args.tokenizer_path):
        tokenizer.load(args.tokenizer_path)
    else:
        print("BPE State not detected. Initiating Vocabulary Synthesis...")
        # Train on the provided data corpus
        tokenizer.train(args.data, target_vocab_size=config['model_specification']['vocab_size'])
        tokenizer.save(args.tokenizer_path)
        
    # Ensure the model configuration aligns with the synthesized vocabulary
    config['model_specification']['vocab_size'] = tokenizer.vocab_size
    return tokenizer

def run_operational_cycle():
    """Execution logic for the OZ v2.8.1 engine."""
    args = parse_operational_parameters()
    
    # 1. Load System Blueprint
    if not os.path.exists(args.config):
        raise FileNotFoundError(f"Configuration file {args.config} missing.")
        
    with open(args.config, "r") as f:
        full_config = yaml.safe_load(f)
    
    m_cfg = full_config['model_specification']
    t_cfg = full_config['training_specification']
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"System: OZ v2.8.1 | Device: {device} | Mode: ECS (Extreme Context Sequence)")

    # 2. Synchronize Tokenizer (v2.8.1 BPE Logic)
    tokenizer = synchronize_tokenizer(args, full_config)

    # 3. Initialize Model Architecture
    model = OZ_v280(m_cfg).to(device)
    
    # 4. Initialize Subsystems (Trainer & Checkpoint Manager)
    trainer = OZ_Trainer(model, m_cfg, t_cfg, device)
    ckpt_manager = OZ_CheckpointManager(checkpoint_dir="checkpoints")

    # 5. Restore State (Optional)
    start_step = 0
    if args.resume:
        start_step = ckpt_manager.load_latest(model, trainer.optimizer)
        print(f"Resuming from step {start_step}. Manifold alignment synchronized.")

    # 6. Data Pipeline Initialization (Memory-Mapped)
    dataset = MemoryMappedDataset(args.data, m_cfg['block_size'])
    loader = DataLoader(
        dataset, 
        batch_size=t_cfg['batch_size'], 
        shuffle=True, 
        num_workers=4, 
        pin_memory=True
    )

    # 7. Training Execution Loop
    print("Initiating ECS Training Sequence...")
    model.train()
    
    current_step = start_step
    try:
        for epoch in range(100): # Indefinite operational cycles
            for i, (x, y) in enumerate(loader):
                # Execute Training Step with Gradient Accumulation
                loss = trainer.train_step(x, y, i + 1)
                
                # Reporting
                if (i + 1) % t_config.get('accumulation_steps', 1) == 0:
                    current_step += 1
                    if current_step % 10 == 0:
                        print(f"Step: {current_step} | Loss: {loss:.4f} | Tokens: {current_step * m_cfg['block_size'] * t_cfg['batch_size']}")

                    # Persistence Cycle
                    if current_step % 500 == 0:
                        ckpt_manager.save(model, trainer.optimizer, current_step, loss, full_config)
    
    except KeyboardInterrupt:
        print("\nManual intervention detected. Archiving current manifold state...")
        ckpt_manager.save(model, trainer.optimizer, current_step, 0.0, full_config)
        print("System hibernated.")

if __name__ == "__main__":
    # Optimize CUDA execution for Extreme Context workloads
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    
    run_operational_cycle()